#ifndef DEEPSEEK_H
#define DEEPSEEK_H
#include "core.h"
#include "storage.h"
#include "provider.h"

#define DEEPSEEK_KEY_CAP 256
#define DEEPSEEK_MODEL_PRO 1
#define DEEPSEEK_MODEL_FLASH 2

typedef struct DeepSeekConfig {
    WCHAR api_key[DEEPSEEK_KEY_CAP];
    int model_kind;
} DeepSeekConfig;

int deepseek_has_saved_key(const StorageContext* st);
int deepseek_load_config(const StorageContext* st, DeepSeekConfig* cfg);
int deepseek_save_key(const StorageContext* st, LPCWSTR api_key, int model_kind);
int deepseek_clear_key(const StorageContext* st);
int deepseek_test_key(const StorageContext* st, LPCWSTR api_key, int* out_model_kind, DWORD* out_http_status);
int deepseek_predict_all(const StorageContext* st, FundStore* store, const MarketSnapshot* market);
/* Generic structured-JSON call used by postmortem/review modules. Returns the decoded
   assistant content object as UTF-8 allocated from the process heap. Caller frees with
   deepseek_free_json. This never exposes or logs the API key. */
int deepseek_call_json_object(const StorageContext* st, LPCWSTR api_key, int model_kind, const u16* fund_code, LPCWSTR log_module, const char* system_prompt, const char* user_content, int reasoning_high, int max_tokens, char** out_json, DWORD* out_len, DWORD* out_http_status);
void deepseek_free_json(char* p);
LPCWSTR deepseek_model_name_w(int model_kind);

#endif
