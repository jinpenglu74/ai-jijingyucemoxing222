#include "core.h"

int core_wlen(const u16* s) {
    int n = 0;
    if (!s) return 0;
    while (s[n]) n++;
    return n;
}

void core_wcopy(u16* dst, int cap, const u16* src) {
    int i = 0;
    if (!dst || cap <= 0) return;
    if (src) while (i < cap - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

int core_weq(const u16* a, const u16* b) {
    int i = 0;
    if (!a || !b) return 0;
    while (a[i] && b[i] && a[i] == b[i]) i++;
    return a[i] == b[i];
}

static void clear_bytes(void* p0, unsigned long long n) {
    unsigned char* p = (unsigned char*)p0;
    unsigned long long i;
    for (i = 0; i < n; ++i) p[i] = 0;
}

static u64 ev_fnv_byte(u64 h, unsigned char b) { return (h ^ (u64)b) * 1099511628211ULL; }
static u64 ev_fnv_bytes(u64 h, const void* p0, unsigned long long n) {
    const unsigned char* p=(const unsigned char*)p0; unsigned long long i;
    for(i=0;i<n;i++) h=ev_fnv_byte(h,p[i]);
    return h;
}
static u64 ev_fnv_u16str(u64 h, const u16* s) {
    int i=0; if(!s) return ev_fnv_byte(h,0);
    while(s[i]) { h=ev_fnv_bytes(h,&s[i],sizeof(u16)); i++; }
    {u16 z=0; h=ev_fnv_bytes(h,&z,sizeof(z));}
    return h;
}

u64 core_compute_evidence_hash(const FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count) {
    u64 h=1469598103934665603ULL; int i, n;
    if(!f) return 0;
    h=ev_fnv_u16str(h,f->code);
    h=ev_fnv_u16str(h,f->name);
    h=ev_fnv_u16str(h,f->fund_type);
    h=ev_fnv_bytes(h,&f->gate_status,sizeof(f->gate_status));
    h=ev_fnv_bytes(h,&f->data_completeness,sizeof(f->data_completeness));
    h=ev_fnv_bytes(h,&f->data_confidence,sizeof(f->data_confidence));
    h=ev_fnv_bytes(h,&f->nav_x10000,sizeof(f->nav_x10000));
    h=ev_fnv_u16str(h,f->nav_date);
    h=ev_fnv_bytes(h,&f->return_1d_x100,sizeof(f->return_1d_x100));
    h=ev_fnv_bytes(h,&f->return_5d_x100,sizeof(f->return_5d_x100));
    h=ev_fnv_bytes(h,&f->return_20d_x100,sizeof(f->return_20d_x100));
    h=ev_fnv_bytes(h,&f->return_60d_x100,sizeof(f->return_60d_x100));
    h=ev_fnv_bytes(h,&f->volatility_20d_x100,sizeof(f->volatility_20d_x100));
    h=ev_fnv_bytes(h,&f->max_drawdown_60d_x100,sizeof(f->max_drawdown_60d_x100));
    h=ev_fnv_bytes(h,&f->short_trend,sizeof(f->short_trend));
    h=ev_fnv_bytes(h,&f->medium_trend,sizeof(f->medium_trend));
    h=ev_fnv_bytes(h,&f->holdings_weighted_change_x100,sizeof(f->holdings_weighted_change_x100));
    h=ev_fnv_bytes(h,&f->holdings_positive_contribution_x100,sizeof(f->holdings_positive_contribution_x100));
    h=ev_fnv_bytes(h,&f->holdings_negative_contribution_x100,sizeof(f->holdings_negative_contribution_x100));
    h=ev_fnv_u16str(h,f->holdings_date);
    n=f->holding_count; if(n<0)n=0; if(n>HOLDING_MAX)n=HOLDING_MAX;
    h=ev_fnv_bytes(h,&n,sizeof(n));
    for(i=0;i<n;i++){
        h=ev_fnv_u16str(h,f->holdings[i].code);
        h=ev_fnv_u16str(h,f->holdings[i].name);
        h=ev_fnv_bytes(h,&f->holdings[i].weight_x100,sizeof(f->holdings[i].weight_x100));
        h=ev_fnv_bytes(h,&f->holdings[i].change_x100,sizeof(f->holdings[i].change_x100));
        h=ev_fnv_bytes(h,&f->holdings[i].quote_ok,sizeof(f->holdings[i].quote_ok));
    }
    if(market_count<0)market_count=0;
    if(market_count>7)market_count=7;
    for(i=0;i<market_count;i++){
        int ok=market_ok?market_ok[i]:0, ch=market_change_x100?market_change_x100[i]:0;
        h=ev_fnv_bytes(h,&ok,sizeof(ok));
        h=ev_fnv_bytes(h,&ch,sizeof(ch));
    }
    return h;
}


static int ev_abs_i(int v){return v<0?-v:v;}

void core_capture_prediction_baseline(FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count, u64 prediction_filetime) {
    PredictionEvidenceBaseline* b; int i,n;
    if(!f)return;
    b=&f->prediction_baseline;
    clear_bytes(b,(unsigned long long)sizeof(*b));
    b->initialized=1;
    b->prediction_filetime=prediction_filetime;
    core_wcopy(b->fund_name,FUND_NAME_CAP,f->name);
    core_wcopy(b->fund_type,FUND_META_CAP,f->fund_type);
    b->gate_status=f->gate_status;
    b->data_completeness=f->data_completeness;
    b->data_confidence=f->data_confidence;
    b->nav_x10000=f->nav_x10000;
    core_wcopy(b->nav_date,FUND_DATE_CAP,f->nav_date);
    b->return_1d_x100=f->return_1d_x100;
    b->return_5d_x100=f->return_5d_x100;
    b->return_20d_x100=f->return_20d_x100;
    b->return_60d_x100=f->return_60d_x100;
    b->volatility_20d_x100=f->volatility_20d_x100;
    b->max_drawdown_60d_x100=f->max_drawdown_60d_x100;
    b->short_trend=f->short_trend;
    b->medium_trend=f->medium_trend;
    core_wcopy(b->holdings_date,FUND_DATE_CAP,f->holdings_date);
    n=f->holding_count;if(n<0)n=0;if(n>HOLDING_MAX)n=HOLDING_MAX;b->holding_count=n;
    for(i=0;i<n;i++){
        core_wcopy(b->holdings[i].code,HOLDING_CODE_CAP,f->holdings[i].code);
        b->holdings[i].weight_x100=f->holdings[i].weight_x100;
        b->holdings[i].change_x100=f->holdings[i].change_x100;
        b->holdings[i].quote_ok=f->holdings[i].quote_ok;
    }
    b->holdings_weighted_change_x100=f->holdings_weighted_change_x100;
    b->market_avg_change_x100=f->market_avg_change_x100;
    if(market_count<0)market_count=0;
    if(market_count>7)market_count=7;
    for(i=0;i<market_count;i++){
        b->market_change_x100[i]=market_change_x100?market_change_x100[i]:0;
        b->market_ok[i]=market_ok?market_ok[i]:0;
    }
}

int core_prediction_change_reason(const FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count) {
    const PredictionEvidenceBaseline* b; int i,n;
    if(!f)return CACHE_CHANGE_BASELINE_MISSING;
    b=&f->prediction_baseline;
    if(!b->initialized)return CACHE_CHANGE_BASELINE_MISSING;
    if(!core_weq(b->fund_name,f->name)||!core_weq(b->fund_type,f->fund_type))return CACHE_CHANGE_FUND_META;
    if(b->nav_x10000!=f->nav_x10000||!core_weq(b->nav_date,f->nav_date))return CACHE_CHANGE_NAV;
    if(b->gate_status!=f->gate_status)return CACHE_CHANGE_GATE;
    if(ev_abs_i(b->data_completeness-f->data_completeness)>=CACHE_DATA_QUALITY_DELTA||ev_abs_i(b->data_confidence-f->data_confidence)>=CACHE_DATA_QUALITY_DELTA)return CACHE_CHANGE_DATA_QUALITY;
    if(b->return_1d_x100!=f->return_1d_x100||b->return_5d_x100!=f->return_5d_x100||b->return_20d_x100!=f->return_20d_x100||b->return_60d_x100!=f->return_60d_x100||b->volatility_20d_x100!=f->volatility_20d_x100||b->max_drawdown_60d_x100!=f->max_drawdown_60d_x100||b->short_trend!=f->short_trend||b->medium_trend!=f->medium_trend)return CACHE_CHANGE_QUANT;
    n=f->holding_count;if(n<0)n=0;if(n>HOLDING_MAX)n=HOLDING_MAX;
    if(!core_weq(b->holdings_date,f->holdings_date)||b->holding_count!=n)return CACHE_CHANGE_HOLDINGS_REPORT;
    for(i=0;i<n;i++){
        if(!core_weq(b->holdings[i].code,f->holdings[i].code)||b->holdings[i].weight_x100!=f->holdings[i].weight_x100)return CACHE_CHANGE_HOLDINGS_REPORT;
        if(b->holdings[i].quote_ok!=f->holdings[i].quote_ok)return CACHE_CHANGE_HOLDINGS_MARKET;
        if(f->holdings[i].quote_ok&&ev_abs_i(b->holdings[i].change_x100-f->holdings[i].change_x100)>=CACHE_HOLDING_CHANGE_THRESHOLD_X100)return CACHE_CHANGE_HOLDINGS_MARKET;
    }
    if(ev_abs_i(b->holdings_weighted_change_x100-f->holdings_weighted_change_x100)>=CACHE_HOLDING_WEIGHTED_THRESHOLD_X100)return CACHE_CHANGE_HOLDINGS_MARKET;
    if(market_count<0)market_count=0;
    if(market_count>7)market_count=7;
    for(i=0;i<market_count;i++){
        int ok=market_ok?market_ok[i]:0,ch=market_change_x100?market_change_x100[i]:0;
        if(b->market_ok[i]!=ok)return CACHE_CHANGE_PUBLIC_MARKET;
        if(ok&&ev_abs_i(b->market_change_x100[i]-ch)>=CACHE_MARKET_CHANGE_THRESHOLD_X100)return CACHE_CHANGE_PUBLIC_MARKET;
    }
    if(ev_abs_i(b->market_avg_change_x100-f->market_avg_change_x100)>=CACHE_MARKET_AVG_THRESHOLD_X100)return CACHE_CHANGE_PUBLIC_MARKET;
    return CACHE_CHANGE_NONE;
}

static void clear_fund(FundRecord* f) {
    clear_bytes(f, (unsigned long long)sizeof(FundRecord));
}

void core_clear_predictions(FundRecord* f) {
    int i,j;
    if (!f) return;
    for (i = 0; i < HORIZON_COUNT; ++i) {
        f->direction[i] = 0;
        f->probability[i] = 0;
        clear_bytes(&f->predictions[i], (unsigned long long)sizeof(PredictionHorizon));
        for(j=0;j<PRED_LIST_MAX;j++){
            f->predictions[i].positive[j][0]=0;
            f->predictions[i].negative[j][0]=0;
            f->predictions[i].drivers[j][0]=0;
        }
        for(j=0;j<PRED_UNCERTAINTY_MAX;j++)f->predictions[i].uncertainty[j][0]=0;
    }
    f->confidence = 0;
    f->prediction_status = PRED_STATUS_NONE;
    f->prediction_error = 0;
    f->prediction_model[0] = 0;
    f->prediction_time[0] = 0;
    f->prediction_snapshot_id[0] = 0;
    f->prediction_snapshot_hash = 0;
    f->prediction_evidence_hash = 0;
    f->prediction_prompt_version = 0;
    clear_bytes(&f->prediction_baseline, (unsigned long long)sizeof(f->prediction_baseline));
    core_wcopy(f->summary, FUND_SUMMARY_CAP, (const u16*)L"六周期AI预测待运行");
}

int core_validate_prediction_horizon(const PredictionHorizon* p) {
    int sum;
    if(!p||!p->valid)return 0;
    if(p->direction<PRED_DIR_DOWN||p->direction>PRED_DIR_UP)return 0;
    if(p->p_up<0||p->p_up>100||p->p_flat<0||p->p_flat>100||p->p_down<0||p->p_down>100)return 0;
    sum=p->p_up+p->p_flat+p->p_down;
    if(sum!=100)return 0;
    if(p->confidence<0||p->confidence>100)return 0;
    if(p->return_low_x100>p->return_high_x100)return 0;
    if(p->return_low_x100<-10000||p->return_high_x100>10000)return 0;
    if(p->direction==PRED_DIR_UP&&(p->p_up<p->p_flat||p->p_up<p->p_down))return 0;
    if(p->direction==PRED_DIR_DOWN&&(p->p_down<p->p_flat||p->p_down<p->p_up))return 0;
    if(p->direction==PRED_DIR_FLAT&&(p->p_flat<p->p_up||p->p_flat<p->p_down))return 0;
    if(!p->summary[0])return 0;
    return 1;
}

void core_clear_analysis(FundRecord* f) {
    if (!f) return;
    f->gate_status = GATE_UNKNOWN;
    f->data_completeness = 0;
    f->data_confidence = 0;
    f->factor_count = 0;
    f->volatility_20d_x100 = 0;
    f->max_drawdown_60d_x100 = 0;
    f->holdings_weighted_change_x100 = 0;
    f->holdings_positive_contribution_x100 = 0;
    f->holdings_negative_contribution_x100 = 0;
    f->holdings_quoted_count = 0;
    f->holdings_concentration_x100 = 0;
    f->market_avg_change_x100 = 0;
    f->short_trend = TREND_FLAT;
    f->medium_trend = TREND_FLAT;
    f->latest_snapshot_id[0] = 0;
    f->latest_snapshot_relpath[0] = 0;
    f->latest_snapshot_time[0] = 0;
    f->latest_snapshot_filetime = 0;
    f->latest_snapshot_hash = 0;
    f->latest_evidence_hash = 0;
}

int core_code_is_valid(const u16* code) {
    int i;
    if (!code) return 0;
    for (i = 0; i < 6; ++i) {
        if (code[i] < (u16)'0' || code[i] > (u16)'9') return 0;
    }
    return code[6] == 0;
}

void core_init_default(FundStore* s) {
    clear_bytes(s, (unsigned long long)sizeof(FundStore));
    s->count = 0;
    s->selected = -1;
}

int core_find_fund(const FundStore* s, const u16* code) {
    int i;
    if (!s || !code) return -1;
    for (i = 0; i < s->count; ++i) if (core_weq(s->funds[i].code, code)) return i;
    return -1;
}

int core_add_fund(FundStore* s, const u16* code, const u16* name) {
    FundRecord* f;
    if (!s || !code || !code[0]) return -1;
    if (!core_code_is_valid(code)) return -4;
    if (s->count >= MAX_FUNDS) return -2;
    if (core_find_fund(s, code) >= 0) return -3;
    f = &s->funds[s->count];
    clear_fund(f);
    core_wcopy(f->code, FUND_CODE_CAP, code);
    core_wcopy(f->name, FUND_NAME_CAP, (name && name[0]) ? name : (const u16*)L"等待识别基金名称");
    f->data_status = DATA_PENDING;
    core_clear_predictions(f);
    core_clear_analysis(f);
    s->count++;
    s->selected = s->count - 1;
    return s->selected;
}

int core_delete_fund(FundStore* s, int index) {
    int i;
    if (!s || index < 0 || index >= s->count) return 0;
    for (i = index; i < s->count - 1; ++i) s->funds[i] = s->funds[i + 1];
    s->count--;
    if (s->count <= 0) s->selected = -1;
    else if (s->selected >= s->count) s->selected = s->count - 1;
    return 1;
}

void core_mark_all_legacy_real(FundStore* s) {
    int i;
    if (!s) return;
    for (i = 0; i < s->count; ++i) {
        s->funds[i].is_demo = 0;
        s->funds[i].data_status = DATA_PENDING;
        s->funds[i].last_error = 0;
        s->funds[i].nav_x10000 = 0;
        s->funds[i].estimate_x10000 = 0;
        s->funds[i].estimate_change_x100 = 0;
        s->funds[i].holding_count = 0;
        s->funds[i].history_points = 0;
        s->funds[i].last_sync_filetime = 0;
        s->funds[i].holdings_sync_filetime = 0;
        core_clear_predictions(&s->funds[i]);
        core_clear_analysis(&s->funds[i]);
    }
}

static int pct_between(int now, int old) {
    if (old <= 0) return 0;
    return (int)(((long long)(now - old) * 10000LL) / old);
}

static u64 isqrt_u64(u64 x) {
    u64 op = x, res = 0, one = (u64)1 << 62;
    while (one > op) one >>= 2;
    while (one != 0) {
        if (op >= res + one) {
            op -= res + one;
            res = (res >> 1) + one;
        } else res >>= 1;
        one >>= 2;
    }
    return res;
}

static int calc_volatility(const NavPoint* p, int n, int lookback) {
    int start, i, m = 0;
    long long sum = 0, varsum = 0, mean;
    if (!p || n < 3) return 0;
    start = n - lookback - 1;
    if (start < 0) start = 0;
    for (i = start + 1; i < n; ++i) {
        int r = pct_between(p[i].nav_x10000, p[i - 1].nav_x10000);
        sum += r; m++;
    }
    if (m < 2) return 0;
    mean = sum / m;
    for (i = start + 1; i < n; ++i) {
        long long r = pct_between(p[i].nav_x10000, p[i - 1].nav_x10000);
        long long d = r - mean;
        varsum += d * d;
    }
    return (int)isqrt_u64((u64)(varsum / m));
}

static int calc_drawdown(const NavPoint* p, int n, int lookback) {
    int start, i, peak, worst = 0;
    if (!p || n <= 0) return 0;
    start = n - lookback;
    if (start < 0) start = 0;
    peak = p[start].nav_x10000;
    for (i = start; i < n; ++i) {
        int dd;
        if (p[i].nav_x10000 > peak) peak = p[i].nav_x10000;
        if (peak <= 0) continue;
        dd = pct_between(p[i].nav_x10000, peak);
        if (dd < worst) worst = dd;
    }
    return worst;
}

static int trend_from_return(int v, int threshold) {
    if (v >= threshold) return TREND_UP;
    if (v <= -threshold) return TREND_DOWN;
    return TREND_FLAT;
}

void core_compute_analysis(FundRecord* f, const NavPoint* p, int n, const int* market_change_x100, const int* market_ok, int market_count) {
    int i, score = 0, conf, q = 0, market_good = 0, market_sum = 0;
    long long weighted = 0, pos = 0, neg = 0;
    if (!f) return;

    f->history_points = n;
    if (n > 0) {
        int last = n - 1;
        if (f->nav_x10000 <= 0) f->nav_x10000 = p[last].nav_x10000;
        f->return_1d_x100 = (n >= 2) ? pct_between(p[last].nav_x10000, p[last - 1].nav_x10000) : 0;
        f->return_5d_x100 = (n >= 6) ? pct_between(p[last].nav_x10000, p[last - 5].nav_x10000) : 0;
        f->return_20d_x100 = (n >= 21) ? pct_between(p[last].nav_x10000, p[last - 20].nav_x10000) : 0;
        f->return_60d_x100 = (n >= 61) ? pct_between(p[last].nav_x10000, p[last - 60].nav_x10000) : 0;
    }

    f->volatility_20d_x100 = calc_volatility(p, n, 20);
    f->max_drawdown_60d_x100 = calc_drawdown(p, n, 61);
    f->short_trend = trend_from_return(f->return_5d_x100, 50);
    if (f->return_20d_x100 >= 100 && f->return_60d_x100 >= 0) f->medium_trend = TREND_UP;
    else if (f->return_20d_x100 <= -100 && f->return_60d_x100 <= 0) f->medium_trend = TREND_DOWN;
    else f->medium_trend = TREND_FLAT;

    f->holdings_quoted_count = 0;
    f->holdings_concentration_x100 = 0;
    for (i = 0; i < f->holding_count && i < HOLDING_MAX; ++i) {
        int c;
        f->holdings_concentration_x100 += f->holdings[i].weight_x100;
        if (!f->holdings[i].quote_ok) continue;
        f->holdings_quoted_count++;
        c = (int)(((long long)f->holdings[i].weight_x100 * f->holdings[i].change_x100) / 10000LL);
        weighted += c;
        if (c > 0) pos += c;
        else if (c < 0) neg += c;
    }
    f->holdings_weighted_change_x100 = (int)weighted;
    f->holdings_positive_contribution_x100 = (int)pos;
    f->holdings_negative_contribution_x100 = (int)neg;

    if (market_change_x100 && market_ok) {
        for (i = 0; i < market_count; ++i) if (market_ok[i]) { market_good++; market_sum += market_change_x100[i]; }
    }
    f->market_avg_change_x100 = market_good ? market_sum / market_good : 0;

    if (f->nav_x10000 > 0) score += 15;
    if (n >= 61) score += 20; else if (n >= 21) score += 15; else if (n > 0) score += 5;
    if (f->holding_count > 0) score += 15;
    if (f->holding_count > 0) score += (f->holdings_quoted_count * 15) / f->holding_count;
    if (market_count > 0) score += (market_good * 15) / market_count;
    if (f->name[0] && f->fund_type[0]) score += 5;
    if (f->nav_date[0]) score += 5;
    if (f->holdings_date[0]) score += 5;
    if (score > 100) score = 100;
    f->data_completeness = score;

    conf = score;
    if (f->data_status == DATA_STALE) conf -= 10;
    else if (f->data_status == DATA_ERROR) conf -= 30;
    if (f->holding_count > 0 && f->holdings_quoted_count * 2 < f->holding_count) conf -= 8;
    if (conf < 0) conf = 0;
    if (conf > 100) conf = 100;
    f->data_confidence = conf;

    if (n >= 2) q++;
    if (n >= 6) q++;
    if (n >= 21) { q += 2; if (f->volatility_20d_x100 >= 0) q++; }
    if (n >= 61) { q += 2; }
    if (f->holding_count > 0) { q++; if (f->holdings_quoted_count > 0) q += 3; }
    if (market_good > 0) q += 2;
    f->factor_count = q;

    if (f->nav_x10000 <= 0 || n < 21) f->gate_status = GATE_BLOCKED;
    else if (score >= 80 && market_good >= ((market_count >= 5) ? 5 : market_count) && f->holding_count > 0 && f->holdings_quoted_count * 2 >= f->holding_count) f->gate_status = GATE_READY;
    else f->gate_status = GATE_PARTIAL;
}

void core_compute_layout(int width, int height, int dpi, int detail_open, LayoutInfo* out) {
    int scale_num = dpi > 0 ? dpi : 96;
    int sidebar = (width < (1050 * scale_num / 96)) ? (62 * scale_num / 96) : (150 * scale_num / 96);
    int right = 0;
    int overlay = 0;
    int header = 52 * scale_num / 96;
    int footer = 28 * scale_num / 96;
    if (detail_open) {
        if (width >= (1220 * scale_num / 96)) right = 400 * scale_num / 96;
        else overlay = 1;
    }
    out->width = width;
    out->height = height;
    out->dpi = scale_num;
    out->sidebar_w = sidebar;
    out->header_h = header;
    out->footer_h = footer;
    out->right_panel_w = right;
    out->content_x = sidebar + 12 * scale_num / 96;
    out->content_w = width - out->content_x - right - 12 * scale_num / 96;
    if (out->content_w < 200) out->content_w = 200;
    out->compact_sidebar = sidebar < 100 * scale_num / 96;
    out->overlay_detail = overlay;
    out->show_reason_col = out->content_w >= 920 * scale_num / 96;
    out->show_bottom_cards = height >= 720 * scale_num / 96;
}
