#ifndef CORE_H
#define CORE_H

#define APP_SCHEMA_VERSION 6
#define APP_VERSION_MAJOR 0
#define APP_VERSION_MINOR 6
#define MAX_FUNDS 64
#define HORIZON_COUNT 6
#define FUND_CODE_CAP 16
#define FUND_NAME_CAP 64
#define FUND_SUMMARY_CAP 192
#define FUND_DATE_CAP 16
#define FUND_TIME_CAP 32
#define FUND_META_CAP 64
#define FUND_BENCHMARK_CAP 160
#define HOLDING_MAX 10
#define HOLDING_NAME_CAP 48
#define HOLDING_CODE_CAP 16
#define NAV_MAX_POINTS 8192
#define SNAPSHOT_ID_CAP 96
#define SNAPSHOT_PATH_CAP 192
#define PRED_REASON_CAP 192
#define PRED_ITEM_CAP 96
#define PRED_LIST_MAX 3
#define PRED_UNCERTAINTY_MAX 2
#define PRED_MODEL_CAP 48

#define DATA_PENDING 0
#define DATA_SYNCING 1
#define DATA_FRESH 2
#define DATA_STALE 3
#define DATA_ERROR 4

#define GATE_UNKNOWN 0
#define GATE_READY 1
#define GATE_PARTIAL 2
#define GATE_BLOCKED 3

#define TREND_DOWN -1
#define TREND_FLAT 0
#define TREND_UP 1

#define PRED_DIR_DOWN -1
#define PRED_DIR_FLAT 0
#define PRED_DIR_UP 1

#define PRED_STATUS_NONE 0
#define PRED_STATUS_OK 1
#define PRED_STATUS_ERROR 2
#define PRED_STATUS_BLOCKED 3
#define PRED_STATUS_NO_KEY 4

#define CACHE_CHANGE_NONE 0
#define CACHE_CHANGE_BASELINE_MISSING 1
#define CACHE_CHANGE_FUND_META 2
#define CACHE_CHANGE_NAV 3
#define CACHE_CHANGE_HOLDINGS_REPORT 4
#define CACHE_CHANGE_GATE 5
#define CACHE_CHANGE_QUANT 6
#define CACHE_CHANGE_DATA_QUALITY 7
#define CACHE_CHANGE_HOLDINGS_MARKET 8
#define CACHE_CHANGE_PUBLIC_MARKET 9

#define CACHE_DATA_QUALITY_DELTA 5
#define CACHE_HOLDING_CHANGE_THRESHOLD_X100 30
#define CACHE_HOLDING_WEIGHTED_THRESHOLD_X100 5
#define CACHE_MARKET_CHANGE_THRESHOLD_X100 20
#define CACHE_MARKET_AVG_THRESHOLD_X100 10
#define CACHE_MIN_REFRESH_SECONDS 600

typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned long long u64;

typedef struct HoldingRecord {
    u16 code[HOLDING_CODE_CAP];
    u16 name[HOLDING_NAME_CAP];
    int weight_x100;
    int change_x100;
    int quote_ok;
} HoldingRecord;

typedef struct PredictionHorizon {
    int valid;
    int direction;
    int p_up;
    int p_flat;
    int p_down;
    int return_low_x100;
    int return_high_x100;
    int confidence;
    u16 summary[PRED_REASON_CAP];
    u16 positive[PRED_LIST_MAX][PRED_ITEM_CAP];
    u16 negative[PRED_LIST_MAX][PRED_ITEM_CAP];
    u16 uncertainty[PRED_UNCERTAINTY_MAX][PRED_ITEM_CAP];
    u16 drivers[PRED_LIST_MAX][PRED_ITEM_CAP];
} PredictionHorizon;

typedef struct PredictionHoldingBaseline {
    u16 code[HOLDING_CODE_CAP];
    int weight_x100;
    int change_x100;
    int quote_ok;
} PredictionHoldingBaseline;

typedef struct PredictionEvidenceBaseline {
    int initialized;
    u64 prediction_filetime;
    u16 fund_name[FUND_NAME_CAP];
    u16 fund_type[FUND_META_CAP];
    int gate_status;
    int data_completeness;
    int data_confidence;
    int nav_x10000;
    u16 nav_date[FUND_DATE_CAP];
    int return_1d_x100;
    int return_5d_x100;
    int return_20d_x100;
    int return_60d_x100;
    int volatility_20d_x100;
    int max_drawdown_60d_x100;
    int short_trend;
    int medium_trend;
    u16 holdings_date[FUND_DATE_CAP];
    int holding_count;
    PredictionHoldingBaseline holdings[HOLDING_MAX];
    int holdings_weighted_change_x100;
    int market_avg_change_x100;
    int market_change_x100[7];
    int market_ok[7];
} PredictionEvidenceBaseline;

typedef struct FundRecord {
    u16 code[FUND_CODE_CAP];
    u16 name[FUND_NAME_CAP];

    int is_demo;
    int data_status;
    int last_error;

    int nav_x10000;
    int estimate_x10000;
    int estimate_change_x100;
    u16 nav_date[FUND_DATE_CAP];
    u16 estimate_time[FUND_TIME_CAP];

    u16 fund_type[FUND_META_CAP];
    u16 fund_company[FUND_META_CAP];
    u16 fund_manager[FUND_META_CAP];
    u16 established_date[FUND_DATE_CAP];
    u16 benchmark[FUND_BENCHMARK_CAP];
    u64 basic_sync_filetime;

    int return_1d_x100;
    int return_5d_x100;
    int return_20d_x100;
    int return_60d_x100;
    int history_points;

    u16 holdings_date[FUND_DATE_CAP];
    HoldingRecord holdings[HOLDING_MAX];
    int holding_count;

    u64 last_sync_filetime;
    u64 holdings_sync_filetime;

    /* Compact prediction surface retained for the table. */
    int direction[HORIZON_COUNT];
    int probability[HORIZON_COUNT];
    int confidence;
    u16 summary[FUND_SUMMARY_CAP];

    /* Quantitative evidence / Data Gate / immutable World Snapshot. */
    int gate_status;
    int data_completeness;
    int data_confidence;
    int factor_count;
    int volatility_20d_x100;
    int max_drawdown_60d_x100;
    int holdings_weighted_change_x100;
    int holdings_positive_contribution_x100;
    int holdings_negative_contribution_x100;
    int holdings_quoted_count;
    int holdings_concentration_x100;
    int market_avg_change_x100;
    int short_trend;
    int medium_trend;
    u16 latest_snapshot_id[SNAPSHOT_ID_CAP];
    u16 latest_snapshot_relpath[SNAPSHOT_PATH_CAP];
    u16 latest_snapshot_time[FUND_TIME_CAP];
    u64 latest_snapshot_filetime;
    u64 latest_snapshot_hash;

    /* V0.4 DeepSeek six-horizon result. The snapshot and model are frozen with it. */
    PredictionHorizon predictions[HORIZON_COUNT];
    int prediction_status;
    int prediction_error;
    u16 prediction_model[PRED_MODEL_CAP];
    u16 prediction_time[FUND_TIME_CAP];
    u16 prediction_snapshot_id[SNAPSHOT_ID_CAP];
    u64 prediction_snapshot_hash;

    /* V0.4.2 semantic evidence cache. Raw World Snapshot may change while the actual
       DeepSeek evidence stays identical; these fields keep those concerns separate. */
    u64 latest_evidence_hash;
    u64 prediction_evidence_hash;
    int prediction_prompt_version;

    /* V0.4.2.1 material-change cache baseline. Tiny live-market ticks can alter
       the raw evidence while the validated prediction remains reusable. */
    PredictionEvidenceBaseline prediction_baseline;
} FundRecord;

typedef struct FundStore {
    FundRecord funds[MAX_FUNDS];
    int count;
    int selected;
} FundStore;

typedef struct NavPoint {
    int yyyymmdd;
    int nav_x10000;
    int return_x100;
} NavPoint;

typedef struct LayoutInfo {
    int width;
    int height;
    int dpi;
    int sidebar_w;
    int header_h;
    int footer_h;
    int right_panel_w;
    int content_x;
    int content_w;
    int compact_sidebar;
    int overlay_detail;
    int show_reason_col;
    int show_bottom_cards;
} LayoutInfo;

int core_wlen(const u16* s);
void core_wcopy(u16* dst, int cap, const u16* src);
int core_weq(const u16* a, const u16* b);
void core_init_default(FundStore* s);
int core_add_fund(FundStore* s, const u16* code, const u16* name);
int core_delete_fund(FundStore* s, int index);
int core_find_fund(const FundStore* s, const u16* code);
void core_compute_layout(int width, int height, int dpi, int detail_open, LayoutInfo* out);
void core_clear_predictions(FundRecord* f);
void core_clear_analysis(FundRecord* f);
void core_compute_analysis(FundRecord* f, const NavPoint* p, int n, const int* market_change_x100, const int* market_ok, int market_count);
void core_mark_all_legacy_real(FundStore* s);
int core_code_is_valid(const u16* code);
int core_validate_prediction_horizon(const PredictionHorizon* p);
u64 core_compute_evidence_hash(const FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count);
void core_capture_prediction_baseline(FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count, u64 prediction_filetime);
int core_prediction_change_reason(const FundRecord* f, const int* market_change_x100, const int* market_ok, int market_count);

#endif
