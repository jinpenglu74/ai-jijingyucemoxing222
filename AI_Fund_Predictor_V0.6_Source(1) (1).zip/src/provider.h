#ifndef PROVIDER_H
#define PROVIDER_H
#include "core.h"
#include "storage.h"

#define MARKET_COUNT 7

typedef struct MarketQuote {
    int ok;
    int price_x10000;
    int change_x100;
} MarketQuote;

typedef struct MarketSnapshot {
    MarketQuote items[MARKET_COUNT];
    u64 synced_filetime;
    int ok_count;
} MarketSnapshot;

/* order: 上证, 深证, 创业板, 沪深300, 恒生, 恒生科技, 纳斯达克 */
int provider_sync_all(const StorageContext* storage, FundStore* store, MarketSnapshot* market, int force_holdings);
u64 provider_now_filetime(void);

#endif
