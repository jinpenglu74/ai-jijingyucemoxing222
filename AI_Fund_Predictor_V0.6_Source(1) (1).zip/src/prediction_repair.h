#ifndef PREDICTION_REPAIR_H
#define PREDICTION_REPAIR_H
#include "core.h"

#define PRED_REPAIR_PROB_NORMALIZED 1
#define PRED_REPAIR_DIRECTION_FIXED 2
#define PRED_REPAIR_RANGE_SWAPPED 4
#define PRED_REPAIR_CONFIDENCE_CLAMPED 8

/* Repairs only mechanically recoverable inconsistencies. Missing semantic fields
   are never synthesized here and must still be rejected by the caller. */
int prediction_repair_horizon(PredictionHorizon* p, int* out_flags);

#endif
