#include "snapshot.h"

#define SNAP_MAGIC0 'A'
#define SNAP_MAGIC1 'I'
#define SNAP_MAGIC2 'F'
#define SNAP_MAGIC3 'W'
#define SNAP_MAGIC4 'S'
#define SNAP_MAGIC5 '0'
#define SNAP_MAGIC6 '3'
#define SNAP_MAGIC7 0

typedef struct WorldSnapshotV1 {
    BYTE magic[8];
    DWORD schema;
    DWORD record_size;
    u64 created_filetime;
    u16 snapshot_id[SNAPSHOT_ID_CAP];
    FundRecord fund;
    MarketSnapshot market;
    int nav_count;
    NavPoint nav_tail[SNAPSHOT_NAV_TAIL];
} WorldSnapshotV1;

static int wlen_s(const WCHAR* s){int n=0;while(s&&s[n])n++;return n;}
static void wcopy_s(WCHAR* d,int cap,const WCHAR* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void wcat_s(WCHAR* d,int cap,const WCHAR* s){int n=wlen_s(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static void wcat_u16_s(WCHAR* d,int cap,const u16* s){int n=wlen_s(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=(WCHAR)s[i++];d[n]=0;}
static void clear_s(void* p0,unsigned long long n){unsigned char* p=(unsigned char*)p0;unsigned long long i;for(i=0;i<n;i++)p[i]=0;}
static void copy_s(void* d0,const void* s0,unsigned long long n){unsigned char* d=(unsigned char*)d0;const unsigned char* s=(const unsigned char*)s0;unsigned long long i;for(i=0;i<n;i++)d[i]=s[i];}
static void int_s(int v,WCHAR* out,int cap){WCHAR t[24];unsigned int x;int n=0,i=0;if(cap<=0)return;if(v<0){out[i++]=L'-';x=(unsigned int)(-(long long)v);}else x=(unsigned int)v;if(x==0)t[n++]=L'0';while(x&&n<23){t[n++]=(WCHAR)(L'0'+x%10);x/=10;}while(n&&i<cap-1)out[i++]=t[--n];out[i]=0;}
static void pad2_s(WCHAR* d,int cap,int v){WCHAR x[3];x[0]=(WCHAR)(L'0'+(v/10)%10);x[1]=(WCHAR)(L'0'+v%10);x[2]=0;wcat_s(d,cap,x);}
static void pad3_s(WCHAR* d,int cap,int v){WCHAR x[4];x[0]=(WCHAR)(L'0'+(v/100)%10);x[1]=(WCHAR)(L'0'+(v/10)%10);x[2]=(WCHAR)(L'0'+v%10);x[3]=0;wcat_s(d,cap,x);}
static void pad4_s(WCHAR* d,int cap,int v){WCHAR x[5];x[0]=(WCHAR)(L'0'+(v/1000)%10);x[1]=(WCHAR)(L'0'+(v/100)%10);x[2]=(WCHAR)(L'0'+(v/10)%10);x[3]=(WCHAR)(L'0'+v%10);x[4]=0;wcat_s(d,cap,x);}

static u64 fnv_byte(u64 h,unsigned char b){return (h^(u64)b)*1099511628211ULL;}
static u64 fnv_bytes(u64 h,const void* p0,unsigned long long n){const unsigned char* p=(const unsigned char*)p0;unsigned long long i;for(i=0;i<n;i++)h=fnv_byte(h,p[i]);return h;}
static u64 snapshot_hash(const FundRecord* f,const MarketSnapshot* m,const NavPoint* nav,int nav_count){
    u64 h=1469598103934665603ULL;int i,start;
    h=fnv_bytes(h,f->code,sizeof(f->code));
    h=fnv_bytes(h,&f->nav_x10000,sizeof(f->nav_x10000));
    h=fnv_bytes(h,&f->estimate_x10000,sizeof(f->estimate_x10000));
    h=fnv_bytes(h,&f->estimate_change_x100,sizeof(f->estimate_change_x100));
    h=fnv_bytes(h,f->nav_date,sizeof(f->nav_date));
    h=fnv_bytes(h,f->estimate_time,sizeof(f->estimate_time));
    h=fnv_bytes(h,f->holdings_date,sizeof(f->holdings_date));
    h=fnv_bytes(h,&f->holding_count,sizeof(f->holding_count));
    for(i=0;i<f->holding_count&&i<HOLDING_MAX;i++){
        h=fnv_bytes(h,f->holdings[i].code,sizeof(f->holdings[i].code));
        h=fnv_bytes(h,&f->holdings[i].weight_x100,sizeof(int));
        h=fnv_bytes(h,&f->holdings[i].change_x100,sizeof(int));
        h=fnv_bytes(h,&f->holdings[i].quote_ok,sizeof(int));
    }
    if(m){h=fnv_bytes(h,&m->ok_count,sizeof(m->ok_count));for(i=0;i<MARKET_COUNT;i++)h=fnv_bytes(h,&m->items[i],sizeof(MarketQuote));}
    start=nav_count-SNAPSHOT_NAV_TAIL;if(start<0)start=0;
    for(i=start;i<nav_count;i++)h=fnv_bytes(h,&nav[i],sizeof(NavPoint));
    return h;
}

/* Hash exactly the substantive fields sent to DeepSeek. Deliberately excludes
   snapshot id/time, raw market prices, intraday estimate timestamps and other
   metadata that do not participate in model reasoning. */
static u64 evidence_hash(const FundRecord* f,const MarketSnapshot* m){
    int changes[MARKET_COUNT],oks[MARKET_COUNT],i;
    for(i=0;i<MARKET_COUNT;i++){changes[i]=m?m->items[i].change_x100:0;oks[i]=m?m->items[i].ok:0;}
    return core_compute_evidence_hash(f,changes,oks,MARKET_COUNT);
}

static void make_date_dir(const StorageContext* st,const SYSTEMTIME* tm,WCHAR* daily,int cap,WCHAR* dayname,int daycap){
    dayname[0]=0;pad4_s(dayname,daycap,tm->wYear);pad2_s(dayname,daycap,tm->wMonth);pad2_s(dayname,daycap,tm->wDay);
    wcopy_s(daily,cap,st->snapshot_dir);wcat_s(daily,cap,L"\\");wcat_s(daily,cap,dayname);
    if(!storage_path_exists(daily))CreateDirectoryW(daily,NULL);
}

static void make_snapshot_id(const FundRecord* f,const SYSTEMTIME* tm,int suffix,WCHAR* id,int cap){
    WCHAR n[16];id[0]=0;wcat_s(id,cap,L"WS-");wcat_u16_s(id,cap,f->code);wcat_s(id,cap,L"-");pad4_s(id,cap,tm->wYear);pad2_s(id,cap,tm->wMonth);pad2_s(id,cap,tm->wDay);wcat_s(id,cap,L"-");pad2_s(id,cap,tm->wHour);pad2_s(id,cap,tm->wMinute);pad2_s(id,cap,tm->wSecond);wcat_s(id,cap,L"-");pad3_s(id,cap,tm->wMilliseconds);if(suffix>0){wcat_s(id,cap,L"-");int_s(suffix,n,16);wcat_s(id,cap,n);}}

static void log_snapshot(const StorageContext* st,const FundRecord* f,LPCWSTR result,LPCWSTR id){WCHAR msg[256];WCHAR n[24];wcopy_s(msg,256,result);if(id&&id[0]){wcat_s(msg,256,L" id=");wcat_s(msg,256,id);}wcat_s(msg,256,L" completeness=");int_s(f->data_completeness,n,24);wcat_s(msg,256,n);wcat_s(msg,256,L" confidence=");int_s(f->data_confidence,n,24);wcat_s(msg,256,n);storage_log_ex(st,L"INFO",L"SNAPSHOT",f->code,msg);}

int snapshot_capture_if_changed(const StorageContext* storage,FundRecord* fund,const MarketSnapshot* market,const NavPoint* nav,int nav_count){
    u64 hash,ehash;SYSTEMTIME tm;FILETIME ft;WCHAR daily[DATA_ROOT_CAP],day[16],id[SNAPSHOT_ID_CAP],path[DATA_ROOT_CAP+SNAPSHOT_PATH_CAP],rel[SNAPSHOT_PATH_CAP];int attempt,start,count,i;HANDLE h;DWORD written=0;WorldSnapshotV1* snap;
    if(!storage||!fund||!market||!nav||nav_count<=0)return 0;
    ehash=evidence_hash(fund,market);
    fund->latest_evidence_hash=ehash;
    hash=snapshot_hash(fund,market,nav,nav_count);
    if(fund->latest_snapshot_hash==hash&&fund->latest_snapshot_id[0]){log_snapshot(storage,fund,L"REUSED raw snapshot unchanged",(WCHAR*)fund->latest_snapshot_id);return 2;}
    GetLocalTime(&tm);GetSystemTimeAsFileTime(&ft);make_date_dir(storage,&tm,daily,DATA_ROOT_CAP,day,16);
    for(attempt=0;attempt<10;attempt++){
        make_snapshot_id(fund,&tm,attempt,id,SNAPSHOT_ID_CAP);
        wcopy_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,daily);wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,L"\\");wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,id);wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,L".wsnap");
        h=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
        if(h!=INVALID_HANDLE_VALUE)break;
    }
    if(attempt>=10){storage_log_ex(storage,L"ERROR",L"SNAPSHOT",fund->code,L"创建不可变快照文件失败");return 0;}
    snap=(WorldSnapshotV1*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(WorldSnapshotV1));if(!snap){CloseHandle(h);storage_log_ex(storage,L"ERROR",L"SNAPSHOT",fund->code,L"快照内存分配失败");return 0;}clear_s(snap,sizeof(WorldSnapshotV1));snap->magic[0]=SNAP_MAGIC0;snap->magic[1]=SNAP_MAGIC1;snap->magic[2]=SNAP_MAGIC2;snap->magic[3]=SNAP_MAGIC3;snap->magic[4]=SNAP_MAGIC4;snap->magic[5]=SNAP_MAGIC5;snap->magic[6]=SNAP_MAGIC6;snap->magic[7]=SNAP_MAGIC7;snap->schema=1;snap->record_size=(DWORD)sizeof(WorldSnapshotV1);snap->created_filetime=((u64)ft.dwHighDateTime<<32)|(u64)ft.dwLowDateTime;core_wcopy(snap->snapshot_id,SNAPSHOT_ID_CAP,(u16*)id);copy_s(&snap->fund,fund,sizeof(FundRecord));core_wcopy(snap->fund.latest_snapshot_id,SNAPSHOT_ID_CAP,(u16*)id);copy_s(&snap->market,market,sizeof(MarketSnapshot));start=nav_count-SNAPSHOT_NAV_TAIL;if(start<0)start=0;count=nav_count-start;snap->nav_count=count;for(i=0;i<count;i++)snap->nav_tail[i]=nav[start+i];
    if(!WriteFile(h,snap,(DWORD)sizeof(WorldSnapshotV1),&written,NULL)||written!=(DWORD)sizeof(WorldSnapshotV1)){HeapFree(GetProcessHeap(),0,snap);CloseHandle(h);storage_log_ex(storage,L"ERROR",L"SNAPSHOT",fund->code,L"写入不可变快照失败");return 0;}CloseHandle(h);
    rel[0]=0;wcat_s(rel,SNAPSHOT_PATH_CAP,day);wcat_s(rel,SNAPSHOT_PATH_CAP,L"\\");wcat_s(rel,SNAPSHOT_PATH_CAP,id);wcat_s(rel,SNAPSHOT_PATH_CAP,L".wsnap");core_wcopy(fund->latest_snapshot_id,SNAPSHOT_ID_CAP,(u16*)id);core_wcopy(fund->latest_snapshot_relpath,SNAPSHOT_PATH_CAP,(u16*)rel);fund->latest_snapshot_time[0]=0;pad4_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wYear);wcat_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,L"-");pad2_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wMonth);wcat_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,L"-");pad2_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wDay);wcat_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,L" ");pad2_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wHour);wcat_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,L":");pad2_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wMinute);wcat_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,L":");pad2_s((WCHAR*)fund->latest_snapshot_time,FUND_TIME_CAP,tm.wSecond);fund->latest_snapshot_filetime=snap->created_filetime;fund->latest_snapshot_hash=hash;HeapFree(GetProcessHeap(),0,snap);log_snapshot(storage,fund,L"CREATED raw snapshot changed",id);return 1;
}


static int id_eq_s(const u16* a,const u16* b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==b[i];}
int snapshot_load_frozen(const StorageContext* storage,const u16* prediction_time,const u16* snapshot_id,FundRecord* out_fund,MarketSnapshot* out_market,NavPoint* out_nav,int max_nav,int* out_nav_count){
    WCHAR path[DATA_ROOT_CAP+SNAPSHOT_PATH_CAP],day[16];HANDLE h;DWORD n=0;WorldSnapshotV1* snap;int i,count;
    if(out_nav_count)*out_nav_count=0;if(!storage||!prediction_time||!snapshot_id||!snapshot_id[0]||!out_fund||!out_market)return 0;
    {int k=0,dash=0,start=-1;while(snapshot_id[k]){if(snapshot_id[k]=='-'){dash++;if(dash==2){start=k+1;break;}}k++;}if(start>=0){int ok=1,j;for(j=0;j<8;j++)if(!(snapshot_id[start+j]>='0'&&snapshot_id[start+j]<='9'))ok=0;if(ok){for(j=0;j<8;j++)day[j]=(WCHAR)snapshot_id[start+j];day[8]=0;}else start=-1;}if(start<0){if(!(prediction_time[0]>='0'&&prediction_time[0]<='9'&&prediction_time[1]>='0'&&prediction_time[1]<='9'&&prediction_time[2]>='0'&&prediction_time[2]<='9'&&prediction_time[3]>='0'&&prediction_time[3]<='9'))return 0;day[0]=(WCHAR)prediction_time[0];day[1]=(WCHAR)prediction_time[1];day[2]=(WCHAR)prediction_time[2];day[3]=(WCHAR)prediction_time[3];if(prediction_time[4]=='-'){day[4]=(WCHAR)prediction_time[5];day[5]=(WCHAR)prediction_time[6];day[6]=(WCHAR)prediction_time[8];day[7]=(WCHAR)prediction_time[9];}else{day[4]=(WCHAR)prediction_time[4];day[5]=(WCHAR)prediction_time[5];day[6]=(WCHAR)prediction_time[6];day[7]=(WCHAR)prediction_time[7];}day[8]=0;}}
    wcopy_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,storage->snapshot_dir);wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,L"\\");wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,day);wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,L"\\");wcat_u16_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,snapshot_id);wcat_s(path,DATA_ROOT_CAP+SNAPSHOT_PATH_CAP,L".wsnap");
    h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    snap=(WorldSnapshotV1*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(WorldSnapshotV1));if(!snap){CloseHandle(h);return 0;}
    if(!ReadFile(h,snap,(DWORD)sizeof(WorldSnapshotV1),&n,NULL)||n!=(DWORD)sizeof(WorldSnapshotV1)){HeapFree(GetProcessHeap(),0,snap);CloseHandle(h);return 0;}CloseHandle(h);
    if(snap->magic[0]!=SNAP_MAGIC0||snap->magic[1]!=SNAP_MAGIC1||snap->magic[2]!=SNAP_MAGIC2||snap->magic[3]!=SNAP_MAGIC3||snap->magic[4]!=SNAP_MAGIC4||snap->magic[5]!=SNAP_MAGIC5||snap->magic[6]!=SNAP_MAGIC6||snap->schema!=1||snap->record_size!=(DWORD)sizeof(WorldSnapshotV1)||!id_eq_s(snap->snapshot_id,snapshot_id)){HeapFree(GetProcessHeap(),0,snap);return 0;}
    copy_s(out_fund,&snap->fund,sizeof(FundRecord));copy_s(out_market,&snap->market,sizeof(MarketSnapshot));count=snap->nav_count;if(count<0)count=0;if(count>SNAPSHOT_NAV_TAIL)count=SNAPSHOT_NAV_TAIL;if(out_nav&&max_nav>0){if(count>max_nav)count=max_nav;for(i=0;i<count;i++)out_nav[i]=snap->nav_tail[i];}else count=0;if(out_nav_count)*out_nav_count=count;HeapFree(GetProcessHeap(),0,snap);return 1;
}
