#include "storage.h"

#define STORE_MAGIC0 'A'
#define STORE_MAGIC1 'I'
#define STORE_MAGIC2 'F'
#define STORE_MAGIC3 'P'
#define STORE_MAGIC4 'V'
#define STORE_MAGIC5 '0'
#define STORE_MAGIC6 '1'
#define STORE_MAGIC7 0

#define NAV_MAGIC0 'A'
#define NAV_MAGIC1 'I'
#define NAV_MAGIC2 'N'
#define NAV_MAGIC3 'A'
#define NAV_MAGIC4 'V'
#define NAV_MAGIC5 '0'
#define NAV_MAGIC6 '2'
#define NAV_MAGIC7 0

typedef struct StoreHeader {
    BYTE magic[8];
    DWORD schema;
    DWORD count;
    DWORD record_size;
} StoreHeader;

typedef struct NavHeader {
    BYTE magic[8];
    DWORD schema;
    DWORD count;
    DWORD record_size;
} NavHeader;

typedef struct LegacyFundRecordV1 {
    u16 code[16];
    u16 name[64];
    int is_demo;
    int direction[6];
    int probability[6];
    int confidence;
    u16 summary[160];
} LegacyFundRecordV1;

typedef struct LegacyFundRecordV2 {
    u16 code[FUND_CODE_CAP];
    u16 name[FUND_NAME_CAP];
    int is_demo;
    int data_status;
    int last_error;
    int nav_x10000;
    int estimate_x10000;
    int estimate_change_x100;
    u16 nav_date[FUND_DATE_CAP];
    u16 estimate_time[FUND_TIME_CAP];
    u16 fund_type[FUND_META_CAP];
    u16 fund_company[FUND_META_CAP];
    u16 fund_manager[FUND_META_CAP];
    u16 established_date[FUND_DATE_CAP];
    u16 benchmark[FUND_BENCHMARK_CAP];
    u64 basic_sync_filetime;
    int return_1d_x100;
    int return_5d_x100;
    int return_20d_x100;
    int return_60d_x100;
    int history_points;
    u16 holdings_date[FUND_DATE_CAP];
    HoldingRecord holdings[HOLDING_MAX];
    int holding_count;
    u64 last_sync_filetime;
    u64 holdings_sync_filetime;
    int direction[HORIZON_COUNT];
    int probability[HORIZON_COUNT];
    int confidence;
    u16 summary[FUND_SUMMARY_CAP];
} LegacyFundRecordV2;

typedef struct LegacyFundRecordV3 {
    u16 code[FUND_CODE_CAP];
    u16 name[FUND_NAME_CAP];
    int is_demo;
    int data_status;
    int last_error;
    int nav_x10000;
    int estimate_x10000;
    int estimate_change_x100;
    u16 nav_date[FUND_DATE_CAP];
    u16 estimate_time[FUND_TIME_CAP];
    u16 fund_type[FUND_META_CAP];
    u16 fund_company[FUND_META_CAP];
    u16 fund_manager[FUND_META_CAP];
    u16 established_date[FUND_DATE_CAP];
    u16 benchmark[FUND_BENCHMARK_CAP];
    u64 basic_sync_filetime;
    int return_1d_x100;
    int return_5d_x100;
    int return_20d_x100;
    int return_60d_x100;
    int history_points;
    u16 holdings_date[FUND_DATE_CAP];
    HoldingRecord holdings[HOLDING_MAX];
    int holding_count;
    u64 last_sync_filetime;
    u64 holdings_sync_filetime;
    int direction[HORIZON_COUNT];
    int probability[HORIZON_COUNT];
    int confidence;
    u16 summary[FUND_SUMMARY_CAP];
    int gate_status;
    int data_completeness;
    int data_confidence;
    int factor_count;
    int volatility_20d_x100;
    int max_drawdown_60d_x100;
    int holdings_weighted_change_x100;
    int holdings_positive_contribution_x100;
    int holdings_negative_contribution_x100;
    int holdings_quoted_count;
    int holdings_concentration_x100;
    int market_avg_change_x100;
    int short_trend;
    int medium_trend;
    u16 latest_snapshot_id[SNAPSHOT_ID_CAP];
    u16 latest_snapshot_relpath[SNAPSHOT_PATH_CAP];
    u16 latest_snapshot_time[FUND_TIME_CAP];
    u64 latest_snapshot_filetime;
    u64 latest_snapshot_hash;
} LegacyFundRecordV3;

static void copy_mem2(void* d0,const void* s0,unsigned long long n){unsigned char* d=(unsigned char*)d0;const unsigned char* s=(const unsigned char*)s0;unsigned long long i;for(i=0;i<n;i++)d[i]=s[i];}

static int wlen2(const WCHAR* s) { int n=0; while (s && s[n]) n++; return n; }
static void wcopy2(WCHAR* d,int cap,const WCHAR* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void wcat2(WCHAR* d,int cap,const WCHAR* s){int n=wlen2(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static void clear_mem(void* p0,unsigned long long n){unsigned char* p=(unsigned char*)p0;unsigned long long i;for(i=0;i<n;i++)p[i]=0;}
static HANDLE g_log_mutex=NULL;
static void log_lock(void){if(g_log_mutex)WaitForSingleObject(g_log_mutex,INFINITE);}
static void log_unlock(void){if(g_log_mutex)ReleaseMutex(g_log_mutex);}
static void wcat_int2(WCHAR* d,int cap,int v){WCHAR t[32];unsigned int uv;int n=0,i;if(v<0){wcat2(d,cap,L"-");uv=(unsigned int)(-(long long)v);}else uv=(unsigned int)v;if(uv==0)t[n++]=L'0';while(uv&&n<31){t[n++]=(WCHAR)(L'0'+uv%10);uv/=10;}for(i=n-1;i>=0;i--){WCHAR one[2]={t[i],0};wcat2(d,cap,one);}}

int storage_path_exists(const WCHAR* p) { return GetFileAttributesW(p) != INVALID_FILE_ATTRIBUTES; }
static void ensure_dir(const WCHAR* p) { if (!storage_path_exists(p)) CreateDirectoryW(p,NULL); }
static void build_path(WCHAR* out,int cap,const WCHAR* root,const WCHAR* suffix){wcopy2(out,cap,root);wcat2(out,cap,suffix);}

static void write_ascii_file(const WCHAR* path,const char* text) {
    HANDLE h = CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    DWORD n=0, len=0;
    if (h==INVALID_HANDLE_VALUE) return;
    while(text[len]) len++;
    WriteFile(h,text,len,&n,NULL);
    CloseHandle(h);
}

void storage_build_fund_path(WCHAR* out, int cap, const WCHAR* dir, const u16* fund_code, const WCHAR* suffix) {
    int i=0,n;
    wcopy2(out,cap,dir);
    wcat2(out,cap,L"\\");
    n=wlen2(out);
    while(fund_code && fund_code[i] && n<cap-1) out[n++]=(WCHAR)fund_code[i++];
    out[n]=0;
    if(suffix)wcat2(out,cap,suffix);
}

int storage_init(StorageContext* ctx) {
    WCHAR p[DATA_ROOT_CAP];
    if (!ctx) return 0;
    clear_mem(ctx,sizeof(*ctx));
    if(!g_log_mutex) g_log_mutex=CreateMutexW(NULL,FALSE,NULL);
    ctx->using_d_drive = (GetDriveTypeW(L"D:\\") == DRIVE_FIXED);
    if (ctx->using_d_drive) wcopy2(ctx->root,DATA_ROOT_CAP,L"D:\\AI基金预测");
    else wcopy2(ctx->root,DATA_ROOT_CAP,L"C:\\AI基金预测");
    ensure_dir(ctx->root);

    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\data"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\data\\nav"); ensure_dir(p); wcopy2(ctx->nav_dir,DATA_ROOT_CAP,p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\data\\holdings"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\snapshots"); ensure_dir(p); wcopy2(ctx->snapshot_dir,DATA_ROOT_CAP,p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\indexes"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\backup"); ensure_dir(p); wcopy2(ctx->backup_dir,DATA_ROOT_CAP,p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\logs"); ensure_dir(p);
    build_path(ctx->export_dir,DATA_ROOT_CAP,ctx->root,L"\\logs\\exports"); ensure_dir(ctx->export_dir);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\config"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\runtime"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\market"); ensure_dir(p); wcopy2(ctx->market_cache_dir,DATA_ROOT_CAP,p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\news"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\events"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\funds"); ensure_dir(p); wcopy2(ctx->raw_fund_cache_dir,DATA_ROOT_CAP,p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\macro"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\fx"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\commodities"); ensure_dir(p);
    build_path(p,DATA_ROOT_CAP,ctx->root,L"\\cache\\ai"); ensure_dir(p);

    build_path(ctx->funds_path,DATA_ROOT_CAP,ctx->root,L"\\config\\funds.bin");
    build_path(ctx->provider_path,DATA_ROOT_CAP,ctx->root,L"\\config\\provider.dat");
    build_path(ctx->prediction_archive_path,DATA_ROOT_CAP,ctx->root,L"\\data\\prediction_archive_v1.bin");
    build_path(ctx->judgment_path,DATA_ROOT_CAP,ctx->root,L"\\data\\judgments_v1.bin");
    build_path(ctx->review_path,DATA_ROOT_CAP,ctx->root,L"\\data\\reviews_v1.bin");
    build_path(ctx->log_path,DATA_ROOT_CAP,ctx->root,L"\\logs\\app.log");
    build_path(ctx->previous_log_path,DATA_ROOT_CAP,ctx->root,L"\\logs\\app_previous.log");
    build_path(ctx->schema_path,DATA_ROOT_CAP,ctx->root,L"\\data\\schema_version.txt");
    if(storage_path_exists(ctx->log_path)) CopyFileW(ctx->log_path,ctx->previous_log_path,FALSE);
    storage_clear_log(ctx);
    storage_log_ex(ctx,L"INFO",L"SYSTEM",NULL,L"V0.6 AI复盘基础版会话开始");
    storage_log_ex(ctx,L"INFO",L"STORAGE",NULL,ctx->using_d_drive?L"持久化目录已初始化：D盘":L"D盘不可用，已回退到C盘");
    return storage_path_exists(ctx->root);
}

static void append2(WCHAR* out,int cap,const WCHAR* s){wcat2(out,cap,s);}
static void pad2(WCHAR* out,int cap,int v){WCHAR one[3];one[0]=(WCHAR)(L'0'+((v/10)%10));one[1]=(WCHAR)(L'0'+(v%10));one[2]=0;wcat2(out,cap,one);}
static void pad3(WCHAR* out,int cap,int v){WCHAR one[4];one[0]=(WCHAR)(L'0'+((v/100)%10));one[1]=(WCHAR)(L'0'+((v/10)%10));one[2]=(WCHAR)(L'0'+(v%10));one[3]=0;wcat2(out,cap,one);}

void storage_log_ex(const StorageContext* ctx, LPCWSTR level, LPCWSTR module, const u16* fund_code, LPCWSTR msg) {
    HANDLE h;DWORD n=0,pos;SYSTEMTIME st;WCHAR line[1024];WCHAR bom=0xFEFF;int i;
    if(!ctx||!msg)return;
    line[0]=0;GetLocalTime(&st);
    append2(line,1024,L"[");pad2(line,1024,st.wHour);append2(line,1024,L":");pad2(line,1024,st.wMinute);append2(line,1024,L":");pad2(line,1024,st.wSecond);append2(line,1024,L".");pad3(line,1024,st.wMilliseconds);append2(line,1024,L"]");
    append2(line,1024,L"[");append2(line,1024,level?level:L"INFO");append2(line,1024,L"]");
    append2(line,1024,L"[");append2(line,1024,module?module:L"APP");append2(line,1024,L"]");
    if(fund_code&&fund_code[0]){append2(line,1024,L"[");for(i=0;fund_code[i]&&wlen2(line)<1022;i++){WCHAR one[2]={(WCHAR)fund_code[i],0};append2(line,1024,one);}append2(line,1024,L"]");}
    append2(line,1024,L" ");append2(line,1024,msg);append2(line,1024,L"\r\n");
    log_lock();
    h=CreateFileW(ctx->log_path,GENERIC_WRITE|GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h!=INVALID_HANDLE_VALUE){pos=SetFilePointer(h,0,NULL,FILE_END);if(pos==0)WriteFile(h,&bom,(DWORD)sizeof(WCHAR),&n,NULL);WriteFile(h,line,(DWORD)(wlen2(line)*sizeof(WCHAR)),&n,NULL);CloseHandle(h);}
    log_unlock();
}

void storage_log(const StorageContext* ctx, LPCWSTR msg) { storage_log_ex(ctx,L"INFO",L"APP",NULL,msg); }

int storage_clear_log(const StorageContext* ctx){HANDLE h;DWORD n=0;WCHAR bom=0xFEFF;if(!ctx)return 0;log_lock();h=CreateFileW(ctx->log_path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE){log_unlock();return 0;}WriteFile(h,&bom,(DWORD)sizeof(WCHAR),&n,NULL);CloseHandle(h);log_unlock();return 1;}

int storage_read_log_alloc(const StorageContext* ctx,WCHAR** out_text,DWORD* out_chars){HANDLE h;DWORD bytes,n=0;WCHAR* mem;if(out_text)*out_text=NULL;if(out_chars)*out_chars=0;if(!ctx||!out_text)return 0;log_lock();h=CreateFileW(ctx->log_path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE){log_unlock();return 0;}bytes=SetFilePointer(h,0,NULL,FILE_END);SetFilePointer(h,0,NULL,FILE_BEGIN);if(bytes<2){CloseHandle(h);log_unlock();return 0;}mem=(WCHAR*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,(SIZE_T)bytes+sizeof(WCHAR));if(!mem){CloseHandle(h);log_unlock();return 0;}if(!ReadFile(h,mem,bytes,&n,NULL)||n!=bytes){HeapFree(GetProcessHeap(),0,mem);CloseHandle(h);log_unlock();return 0;}CloseHandle(h);log_unlock();if(mem[0]==0xFEFF){DWORD chars=(bytes/2)-1;for(n=0;n<chars;n++)mem[n]=mem[n+1];mem[chars]=0;if(out_chars)*out_chars=chars;}else{DWORD chars=bytes/2;mem[chars]=0;if(out_chars)*out_chars=chars;}*out_text=mem;return 1;}

int storage_read_log_tail(const StorageContext* ctx,WCHAR* out,int cap){WCHAR* all;DWORD chars=0,start=0,i,lines=0;if(!out||cap<=0){return 0;}out[0]=0;if(!storage_read_log_alloc(ctx,&all,&chars))return 0;if(chars>0){for(i=chars;i>0;i--){if(all[i-1]==L'\n'){lines++;if(lines>=18){start=i;break;}}}if((int)(chars-start)>=cap)start=chars-(DWORD)(cap-1);for(i=0;start+i<chars&&i<(DWORD)(cap-1);i++)out[i]=all[start+i];out[i]=0;}HeapFree(GetProcessHeap(),0,all);return 1;}

int storage_export_log(const StorageContext* ctx,WCHAR* out_path,int cap){SYSTEMTIME st;WCHAR name[128];if(!ctx||!out_path||cap<=0)return 0;GetLocalTime(&st);name[0]=0;wcat2(name,128,L"\\AI基金预测_运行日志_");wcat_int2(name,128,st.wYear);wcat2(name,128,L"-");pad2(name,128,st.wMonth);wcat2(name,128,L"-");pad2(name,128,st.wDay);wcat2(name,128,L"_");pad2(name,128,st.wHour);pad2(name,128,st.wMinute);pad2(name,128,st.wSecond);wcat2(name,128,L".txt");wcopy2(out_path,cap,ctx->export_dir);wcat2(out_path,cap,name);return CopyFileW(ctx->log_path,out_path,FALSE)!=0;}

static int magic_ok(const StoreHeader* h){
    return h->magic[0]==STORE_MAGIC0&&h->magic[1]==STORE_MAGIC1&&h->magic[2]==STORE_MAGIC2&&h->magic[3]==STORE_MAGIC3&&
           h->magic[4]==STORE_MAGIC4&&h->magic[5]==STORE_MAGIC5&&h->magic[6]==STORE_MAGIC6;
}

static int nav_magic_ok(const NavHeader* h){
    return h->magic[0]==NAV_MAGIC0&&h->magic[1]==NAV_MAGIC1&&h->magic[2]==NAV_MAGIC2&&h->magic[3]==NAV_MAGIC3&&
           h->magic[4]==NAV_MAGIC4&&h->magic[5]==NAV_MAGIC5&&h->magic[6]==NAV_MAGIC6;
}

static void make_store_header(StoreHeader* hd,DWORD count){
    hd->magic[0]=STORE_MAGIC0;hd->magic[1]=STORE_MAGIC1;hd->magic[2]=STORE_MAGIC2;hd->magic[3]=STORE_MAGIC3;
    hd->magic[4]=STORE_MAGIC4;hd->magic[5]=STORE_MAGIC5;hd->magic[6]=STORE_MAGIC6;hd->magic[7]=STORE_MAGIC7;
    hd->schema=APP_SCHEMA_VERSION;hd->count=count;hd->record_size=(DWORD)sizeof(FundRecord);
}

int storage_save_funds(const StorageContext* ctx, const FundStore* store) {
    HANDLE h;
    StoreHeader hd;
    DWORD n=0;
    WCHAR tmp[DATA_ROOT_CAP];
    if(!ctx||!store) return 0;
    make_store_header(&hd,(DWORD)store->count);
    wcopy2(tmp,DATA_ROOT_CAP,ctx->funds_path);wcat2(tmp,DATA_ROOT_CAP,L".tmp");
    h=CreateFileW(tmp,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    if(!WriteFile(h,&hd,(DWORD)sizeof(hd),&n,NULL)||n!=(DWORD)sizeof(hd)){CloseHandle(h);return 0;}
    if(store->count>0){
        DWORD bytes=(DWORD)(sizeof(FundRecord)*store->count);
        if(!WriteFile(h,store->funds,bytes,&n,NULL)||n!=bytes){CloseHandle(h);return 0;}
    }
    CloseHandle(h);
    if(!MoveFileExW(tmp,ctx->funds_path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))return 0;
    write_ascii_file(ctx->schema_path,"6\r\n");
    storage_log(ctx,L"fund store saved v6");
    return 1;
}

static int migrate_v5(const StorageContext* ctx,HANDLE h,const StoreHeader* hd,FundStore* store){
    unsigned char* old;DWORD n=0,bytes;int i;WCHAR bak[DATA_ROOT_CAP];
    if(hd->count>MAX_FUNDS||hd->record_size==0||hd->record_size>sizeof(FundRecord))return 0;
    bytes=(DWORD)(hd->record_size*hd->count);
    old=(unsigned char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes?bytes:1);
    if(!old)return 0;
    if(bytes&&(!ReadFile(h,old,bytes,&n,NULL)||n!=bytes)){HeapFree(GetProcessHeap(),0,old);return 0;}
    core_init_default(store);store->count=(int)hd->count;store->selected=store->count?0:-1;
    for(i=0;i<store->count;i++){
        FundRecord* dst=&store->funds[i];
        clear_mem(dst,sizeof(*dst));
        copy_mem2(dst,old+((unsigned long long)i*hd->record_size),hd->record_size);
        clear_mem(&dst->prediction_baseline,sizeof(dst->prediction_baseline));
    }
    HeapFree(GetProcessHeap(),0,old);
    build_path(bak,DATA_ROOT_CAP,ctx->backup_dir,L"\\funds_v5_before_v0421.bin");
    CopyFileW(ctx->funds_path,bak,FALSE);
    storage_log(ctx,L"migrated V0.4.2 fund store to V0.4.2.1; predictions preserved, material-change baseline will initialize once");
    return 1;
}

static int migrate_v4(const StorageContext* ctx,HANDLE h,const StoreHeader* hd,FundStore* store){
    unsigned char* old;DWORD n=0,bytes;int i;WCHAR bak[DATA_ROOT_CAP];
    if(hd->count>MAX_FUNDS||hd->record_size==0||hd->record_size>sizeof(FundRecord))return 0;
    bytes=(DWORD)(hd->record_size*hd->count);
    old=(unsigned char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes?bytes:1);
    if(!old)return 0;
    if(bytes&&(!ReadFile(h,old,bytes,&n,NULL)||n!=bytes)){HeapFree(GetProcessHeap(),0,old);return 0;}
    core_init_default(store);store->count=(int)hd->count;store->selected=store->count?0:-1;
    for(i=0;i<store->count;i++){
        FundRecord* dst=&store->funds[i];
        clear_mem(dst,sizeof(*dst));
        copy_mem2(dst,old+((unsigned long long)i*hd->record_size),hd->record_size);
        dst->latest_evidence_hash=0;
        dst->prediction_evidence_hash=0;
        dst->prediction_prompt_version=0;
    }
    HeapFree(GetProcessHeap(),0,old);
    build_path(bak,DATA_ROOT_CAP,ctx->backup_dir,L"\\funds_v4_before_v042.bin");
    CopyFileW(ctx->funds_path,bak,FALSE);
    storage_log(ctx,L"migrated V0.4/V0.4.1 fund store to V0.4.2; predictions preserved, semantic evidence fingerprint will initialize once");
    return 1;
}

static int migrate_v3(const StorageContext* ctx,HANDLE h,const StoreHeader* hd,FundStore* store){
    LegacyFundRecordV3* old;DWORD n=0,bytes;int i;WCHAR bak[DATA_ROOT_CAP];
    if(hd->count>MAX_FUNDS||hd->record_size!=(DWORD)sizeof(LegacyFundRecordV3))return 0;
    bytes=(DWORD)(sizeof(LegacyFundRecordV3)*hd->count);
    old=(LegacyFundRecordV3*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes?bytes:1);
    if(!old)return 0;
    if(bytes&&(!ReadFile(h,old,bytes,&n,NULL)||n!=bytes)){HeapFree(GetProcessHeap(),0,old);return 0;}
    core_init_default(store);store->count=(int)hd->count;store->selected=store->count?0:-1;
    for(i=0;i<store->count;i++){
        FundRecord* dst=&store->funds[i];
        clear_mem(dst,sizeof(*dst));
        copy_mem2(dst,&old[i],sizeof(LegacyFundRecordV3));
        core_clear_predictions(dst);
    }
    HeapFree(GetProcessHeap(),0,old);
    build_path(bak,DATA_ROOT_CAP,ctx->backup_dir,L"\\funds_v3_before_v04.bin");
    CopyFileW(ctx->funds_path,bak,FALSE);
    storage_log(ctx,L"migrated V0.3/V0.3.1 fund store to V0.4; real data and snapshots preserved");
    return 1;
}

static int migrate_v2(const StorageContext* ctx,HANDLE h,const StoreHeader* hd,FundStore* store){
    LegacyFundRecordV2* old;DWORD n=0,bytes;int i;WCHAR bak[DATA_ROOT_CAP];
    if(hd->count>MAX_FUNDS||hd->record_size!=(DWORD)sizeof(LegacyFundRecordV2))return 0;
    bytes=(DWORD)(sizeof(LegacyFundRecordV2)*hd->count);
    old=(LegacyFundRecordV2*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes?bytes:1);
    if(!old)return 0;
    if(bytes&&(!ReadFile(h,old,bytes,&n,NULL)||n!=bytes)){HeapFree(GetProcessHeap(),0,old);return 0;}
    core_init_default(store);store->count=(int)hd->count;store->selected=store->count?0:-1;
    for(i=0;i<store->count;i++){
        FundRecord* dst=&store->funds[i];
        clear_mem(dst,sizeof(*dst));
        copy_mem2(dst,&old[i],sizeof(LegacyFundRecordV2));
        core_clear_analysis(dst);
        core_clear_predictions(dst);
    }
    HeapFree(GetProcessHeap(),0,old);
    build_path(bak,DATA_ROOT_CAP,ctx->backup_dir,L"\\funds_v2_before_v03.bin");
    CopyFileW(ctx->funds_path,bak,FALSE);
    storage_log(ctx,L"migrated V0.2/V0.2.1 fund store to V0.3; historical real data preserved");
    return 1;
}

static int migrate_v1(const StorageContext* ctx,HANDLE h,const StoreHeader* hd,FundStore* store){
    LegacyFundRecordV1* old;DWORD n=0,bytes;int i,j;WCHAR bak[DATA_ROOT_CAP];
    if(hd->count>MAX_FUNDS||hd->record_size!=(DWORD)sizeof(LegacyFundRecordV1))return 0;
    bytes=(DWORD)(sizeof(LegacyFundRecordV1)*hd->count);
    old=(LegacyFundRecordV1*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,bytes?bytes:1);
    if(!old)return 0;
    if(bytes&&(!ReadFile(h,old,bytes,&n,NULL)||n!=bytes)){HeapFree(GetProcessHeap(),0,old);return 0;}
    core_init_default(store);
    /* V0.1 shipped with built-in demo rows. They are not user assets and must not
       silently become tracked funds after upgrading to the real-data build.
       Preserve only funds explicitly added by the user (is_demo == 0). */
    for(i=0;i<(int)hd->count;i++){
        FundRecord* dst;
        if(old[i].is_demo) continue;
        if(store->count>=MAX_FUNDS) break;
        dst=&store->funds[store->count++];
        core_wcopy(dst->code,FUND_CODE_CAP,old[i].code);
        core_wcopy(dst->name,FUND_NAME_CAP,old[i].name);
        dst->is_demo=0;
        dst->data_status=DATA_PENDING;
        for(j=0;j<HORIZON_COUNT;j++){dst->direction[j]=0;dst->probability[j]=0;}
        dst->confidence=0;
        core_wcopy(dst->summary,FUND_SUMMARY_CAP,(const u16*)L"V0.1自建基金已迁移，等待同步真实数据");
    }
    store->selected=store->count?0:-1;
    HeapFree(GetProcessHeap(),0,old);
    build_path(bak,DATA_ROOT_CAP,ctx->backup_dir,L"\\funds_v1_before_v02.bin");
    CopyFileW(ctx->funds_path,bak,FALSE);
    storage_log(ctx,L"migrated V0.1 user-added funds to V0.2; demo rows skipped");
    return 1;
}

int storage_load_funds(const StorageContext* ctx, FundStore* store) {
    HANDLE h;
    StoreHeader hd;
    DWORD n=0, bytes;
    if(!ctx||!store) return 0;
    h=CreateFileW(ctx->funds_path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE){
        core_init_default(store);
        storage_save_funds(ctx,store);
        storage_log(ctx,L"created empty V0.5 fund store");
        return 1;
    }
    if(!ReadFile(h,&hd,(DWORD)sizeof(hd),&n,NULL)||n!=(DWORD)sizeof(hd)||!magic_ok(&hd)||hd.count>MAX_FUNDS){
        CloseHandle(h);core_init_default(store);storage_log(ctx,L"fund store invalid; original preserved");return 0;
    }
    if(hd.schema==1){
        int ok=migrate_v1(ctx,h,&hd,store);CloseHandle(h);if(ok)storage_save_funds(ctx,store);return ok;
    }
    if(hd.schema==2){
        int ok=migrate_v2(ctx,h,&hd,store);CloseHandle(h);if(ok)storage_save_funds(ctx,store);return ok;
    }
    if(hd.schema==3){
        int ok=migrate_v3(ctx,h,&hd,store);CloseHandle(h);if(ok)storage_save_funds(ctx,store);return ok;
    }
    if(hd.schema==4){
        int ok=migrate_v4(ctx,h,&hd,store);CloseHandle(h);if(ok)storage_save_funds(ctx,store);return ok;
    }
    if(hd.schema==5){
        int ok=migrate_v5(ctx,h,&hd,store);CloseHandle(h);if(ok)storage_save_funds(ctx,store);return ok;
    }
    if(hd.schema!=APP_SCHEMA_VERSION||hd.record_size!=(DWORD)sizeof(FundRecord)){
        CloseHandle(h);core_init_default(store);storage_log(ctx,L"fund store incompatible; original preserved");return 0;
    }
    core_init_default(store);store->count=(int)hd.count;store->selected=store->count?0:-1;
    if(store->count>0){
        bytes=(DWORD)(sizeof(FundRecord)*store->count);
        if(!ReadFile(h,store->funds,bytes,&n,NULL)||n!=bytes){CloseHandle(h);core_init_default(store);return 0;}
    }
    CloseHandle(h);storage_log(ctx,L"fund store loaded v6");return 1;
}

int storage_save_nav_points(const StorageContext* ctx,const u16* fund_code,const NavPoint* points,int count){
    WCHAR path[DATA_ROOT_CAP],tmp[DATA_ROOT_CAP];HANDLE h;DWORD n=0;NavHeader hd;
    if(!ctx||!fund_code||!points||count<0||count>NAV_MAX_POINTS)return 0;
    storage_build_fund_path(path,DATA_ROOT_CAP,ctx->nav_dir,fund_code,L".bin");
    wcopy2(tmp,DATA_ROOT_CAP,path);wcat2(tmp,DATA_ROOT_CAP,L".tmp");
    hd.magic[0]=NAV_MAGIC0;hd.magic[1]=NAV_MAGIC1;hd.magic[2]=NAV_MAGIC2;hd.magic[3]=NAV_MAGIC3;hd.magic[4]=NAV_MAGIC4;hd.magic[5]=NAV_MAGIC5;hd.magic[6]=NAV_MAGIC6;hd.magic[7]=0;
    hd.schema=2;hd.count=(DWORD)count;hd.record_size=(DWORD)sizeof(NavPoint);
    h=CreateFileW(tmp,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    if(!WriteFile(h,&hd,sizeof(hd),&n,NULL)||n!=sizeof(hd)){CloseHandle(h);return 0;}
    if(count>0){DWORD bytes=(DWORD)(sizeof(NavPoint)*count);if(!WriteFile(h,points,bytes,&n,NULL)||n!=bytes){CloseHandle(h);return 0;}}
    CloseHandle(h);return MoveFileExW(tmp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
}

int storage_load_nav_points(const StorageContext* ctx,const u16* fund_code,NavPoint* out,int max_points){
    WCHAR path[DATA_ROOT_CAP];HANDLE h;DWORD n=0,bytes;NavHeader hd;int count;
    if(!ctx||!fund_code||!out||max_points<=0)return 0;
    storage_build_fund_path(path,DATA_ROOT_CAP,ctx->nav_dir,fund_code,L".bin");
    h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    if(!ReadFile(h,&hd,sizeof(hd),&n,NULL)||n!=sizeof(hd)||!nav_magic_ok(&hd)||hd.schema!=2||hd.record_size!=sizeof(NavPoint)){CloseHandle(h);return 0;}
    count=(int)hd.count;if(count>max_points)count=max_points;bytes=(DWORD)(sizeof(NavPoint)*count);
    if(count>0&&(!ReadFile(h,out,bytes,&n,NULL)||n!=bytes)){CloseHandle(h);return 0;}CloseHandle(h);return count;
}

int storage_write_raw_cache(const StorageContext* ctx,const u16* fund_code,const WCHAR* suffix,const char* data,DWORD len){
    WCHAR path[DATA_ROOT_CAP];HANDLE h;DWORD n=0;if(!ctx||!fund_code||!suffix||!data)return 0;
    storage_build_fund_path(path,DATA_ROOT_CAP,ctx->raw_fund_cache_dir,fund_code,suffix);
    h=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    if(!WriteFile(h,data,len,&n,NULL)||n!=len){CloseHandle(h);return 0;}CloseHandle(h);return 1;
}

int storage_read_raw_cache(const StorageContext* ctx,const u16* fund_code,const WCHAR* suffix,char* out,DWORD cap,DWORD* out_len){
    WCHAR path[DATA_ROOT_CAP];HANDLE h;DWORD n=0;if(out_len)*out_len=0;if(!ctx||!fund_code||!suffix||!out||cap<2)return 0;
    storage_build_fund_path(path,DATA_ROOT_CAP,ctx->raw_fund_cache_dir,fund_code,suffix);
    h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    if(!ReadFile(h,out,cap-1,&n,NULL)){CloseHandle(h);return 0;}CloseHandle(h);out[n]=0;if(out_len)*out_len=n;return 1;
}


int storage_write_named_cache(const WCHAR* dir,const WCHAR* name,const char* data,DWORD len){
    WCHAR path[DATA_ROOT_CAP];HANDLE h;DWORD n=0;
    if(!dir||!name||!data)return 0;
    wcopy2(path,DATA_ROOT_CAP,dir);wcat2(path,DATA_ROOT_CAP,L"\\");wcat2(path,DATA_ROOT_CAP,name);
    h=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;
    if(!WriteFile(h,data,len,&n,NULL)||n!=len){CloseHandle(h);return 0;}CloseHandle(h);return 1;
}
