#ifndef REVIEW_LOGIC_H
#define REVIEW_LOGIC_H

#define REVIEW_QUALITY_UNSUPPORTED 0
#define REVIEW_QUALITY_PARTIAL 1
#define REVIEW_QUALITY_SUPPORTED 2

#define REVIEW_GRADE_A 1
#define REVIEW_GRADE_B 2
#define REVIEW_GRADE_C 3
#define REVIEW_GRADE_D 4

int review_quality_from_ascii(const char* s);
int review_compute_grade(int direction_correct,int reasoning_quality);
int review_is_lucky_hit(int direction_correct,int reasoning_quality);

#endif
