#ifndef STORAGE_H
#define STORAGE_H
#include "winmini.h"
#include "core.h"

#define DATA_ROOT_CAP 260

typedef struct StorageContext {
    WCHAR root[DATA_ROOT_CAP];
    WCHAR funds_path[DATA_ROOT_CAP];
    WCHAR log_path[DATA_ROOT_CAP];
    WCHAR previous_log_path[DATA_ROOT_CAP];
    WCHAR export_dir[DATA_ROOT_CAP];
    WCHAR schema_path[DATA_ROOT_CAP];
    WCHAR nav_dir[DATA_ROOT_CAP];
    WCHAR raw_fund_cache_dir[DATA_ROOT_CAP];
    WCHAR market_cache_dir[DATA_ROOT_CAP];
    WCHAR backup_dir[DATA_ROOT_CAP];
    WCHAR snapshot_dir[DATA_ROOT_CAP];
    WCHAR provider_path[DATA_ROOT_CAP];
    WCHAR ai_cache_dir[DATA_ROOT_CAP];
    WCHAR prediction_archive_path[DATA_ROOT_CAP];
    WCHAR judgment_path[DATA_ROOT_CAP];
    WCHAR review_path[DATA_ROOT_CAP];
    int using_d_drive;
    int migrated_v1;
    int migrated_v2;
} StorageContext;

int storage_init(StorageContext* ctx);
int storage_load_funds(const StorageContext* ctx, FundStore* store);
int storage_save_funds(const StorageContext* ctx, const FundStore* store);
void storage_log(const StorageContext* ctx, LPCWSTR msg);
void storage_log_ex(const StorageContext* ctx, LPCWSTR level, LPCWSTR module, const u16* fund_code, LPCWSTR msg);
int storage_clear_log(const StorageContext* ctx);
int storage_read_log_alloc(const StorageContext* ctx, WCHAR** out_text, DWORD* out_chars);
int storage_read_log_tail(const StorageContext* ctx, WCHAR* out, int cap);
int storage_export_log(const StorageContext* ctx, WCHAR* out_path, int cap);
int storage_load_nav_points(const StorageContext* ctx, const u16* fund_code, NavPoint* out, int max_points);
int storage_save_nav_points(const StorageContext* ctx, const u16* fund_code, const NavPoint* points, int count);
int storage_write_raw_cache(const StorageContext* ctx, const u16* fund_code, const WCHAR* suffix, const char* data, DWORD len);
int storage_write_named_cache(const WCHAR* dir, const WCHAR* name, const char* data, DWORD len);
int storage_read_raw_cache(const StorageContext* ctx, const u16* fund_code, const WCHAR* suffix, char* out, DWORD cap, DWORD* out_len);
int storage_path_exists(const WCHAR* path);
void storage_build_fund_path(WCHAR* out, int cap, const WCHAR* dir, const u16* fund_code, const WCHAR* suffix);

#endif
