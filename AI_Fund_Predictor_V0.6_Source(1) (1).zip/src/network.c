#include "network.h"

static void clear_mem(void* p0, unsigned long long n) { unsigned char* p=(unsigned char*)p0; unsigned long long i; for(i=0;i<n;i++)p[i]=0; }
static DWORD slen_n(const char* s){DWORD n=0;while(s&&s[n])n++;return n;}

void net_free(NetResponse* r){if(!r)return;if(r->data)HeapFree(GetProcessHeap(),0,r->data);clear_mem(r,sizeof(*r));}

static int read_response(HINTERNET request,DWORD max_bytes,NetResponse* out){HANDLE heap=GetProcessHeap();char* buf=NULL;DWORD cap=0,used=0,size=sizeof(DWORD),idx=0,status=0;int success=0;
    if(WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,NULL,&status,&size,&idx))out->http_status=status;
    cap=65536;if(cap>max_bytes)cap=max_bytes;buf=(char*)HeapAlloc(heap,0,(SIZE_T)cap+1);if(!buf)goto done;
    for(;;){DWORD avail=0,want,got=0;if(!WinHttpQueryDataAvailable(request,&avail))goto done;if(avail==0)break;if(used>=max_bytes)goto done;want=avail;if(want>max_bytes-used)want=max_bytes-used;if(used+want+1>cap){DWORD newcap=cap;while(newcap<used+want+1&&newcap<max_bytes){DWORD next=newcap*2;if(next<newcap||next>max_bytes)next=max_bytes;newcap=next;}if(newcap<used+want+1)goto done;buf=(char*)HeapReAlloc(heap,0,buf,(SIZE_T)newcap+1);if(!buf)goto done;cap=newcap;}if(!WinHttpReadData(request,buf+used,want,&got))goto done;if(!got)break;used+=got;}
    buf[used]=0;out->data=buf;out->len=used;out->ok=(out->http_status>=200&&out->http_status<300);buf=NULL;success=1;
done:if(buf)HeapFree(heap,0,buf);return success;}

static int request_common(LPCWSTR method,LPCWSTR host,LPCWSTR path,LPCWSTR headers,const char* body,DWORD body_len,DWORD max_bytes,NetResponse* out){HINTERNET session=NULL,connect=NULL,request=NULL;int success=0;if(!out||!host||!path||max_bytes<1024)return 0;clear_mem(out,sizeof(*out));
    session=WinHttpOpen(L"AI Fund Predictor/0.6",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,NULL,NULL,0);if(!session)goto done;WinHttpSetTimeouts(session,10000,10000,60000,60000);connect=WinHttpConnect(session,host,INTERNET_DEFAULT_HTTPS_PORT,0);if(!connect)goto done;request=WinHttpOpenRequest(connect,method,path,NULL,NULL,NULL,WINHTTP_FLAG_SECURE);if(!request)goto done;
    if(!WinHttpSendRequest(request,headers,headers?(DWORD)-1L:0,(LPVOID)body,body?body_len:0,body?body_len:0,0))goto done;if(!WinHttpReceiveResponse(request,NULL))goto done;if(!read_response(request,max_bytes,out))goto done;success=1;
done:if(!success)out->win_error=GetLastError();if(request)WinHttpCloseHandle(request);if(connect)WinHttpCloseHandle(connect);if(session)WinHttpCloseHandle(session);return success;}

int net_http_get(LPCWSTR host,LPCWSTR path,LPCWSTR headers,DWORD max_bytes,NetResponse* out){return request_common(L"GET",host,path,headers,NULL,0,max_bytes,out);}
int net_http_post_json(LPCWSTR host,LPCWSTR path,LPCWSTR headers,const char* body,DWORD body_len,DWORD max_bytes,NetResponse* out){if(body&&body_len==0)body_len=slen_n(body);return request_common(L"POST",host,path,headers,body,body_len,max_bytes,out);}
