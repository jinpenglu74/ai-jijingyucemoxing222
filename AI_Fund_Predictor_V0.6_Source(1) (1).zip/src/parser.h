#ifndef PARSER_H
#define PARSER_H

#define PARSED_NAME_CAP 256
#define PARSED_HOLDING_MAX 10

typedef struct FundGzParsed {
    char code[16];
    char name[PARSED_NAME_CAP];
    char nav_date[16];
    char estimate_time[32];
    int nav_x10000;
    int estimate_x10000;
    int estimate_change_x100;
    int ok;
} FundGzParsed;


typedef struct FundCurrentParsed {
    char code[16];
    char name[PARSED_NAME_CAP];
    char nav_date[16];
    char estimate_time[32];
    int nav_x10000;
    int nav_change_x100;
    int estimate_x10000;
    int estimate_change_x100;
    int ok;
} FundCurrentParsed;


typedef struct FundBasicParsed {
    char code[16];
    char name[PARSED_NAME_CAP];
    char fund_type[PARSED_NAME_CAP];
    char fund_company[PARSED_NAME_CAP];
    char fund_manager[PARSED_NAME_CAP];
    char established_date[16];
    char benchmark[512];
    int ok;
} FundBasicParsed;

typedef struct ParsedNavPoint {
    int yyyymmdd;
    int nav_x10000;
    int return_x100;
} ParsedNavPoint;

typedef struct ParsedHolding {
    char code[16];
    char name[PARSED_NAME_CAP];
    int weight_x100;
} ParsedHolding;

int parser_decimal_scaled(const char* s, int scale_digits, int* out);
int parser_fundgz(const char* text, FundGzParsed* out);
int parser_mnfinfo_find(const char* text, const char* code, FundCurrentParsed* out);
int parser_basic_info(const char* text, FundBasicParsed* out);
int parser_ping_name(const char* text, char* out_name, int cap);
int parser_ping_nav(const char* text, ParsedNavPoint* out, int max_points);
int parser_f10_latest_nav(const char* text, ParsedNavPoint* out, int max_points);
int parser_holdings(const char* text, ParsedHolding* out, int max_holdings, char* cutoff_date, int cutoff_cap);
int parser_date_to_int(const char* s);
int parser_unix_ms_to_date(long long ms);
int parser_tencent_simple_percent(const char* text, const char* symbol, int* out_change_x100, int* out_price_x10000);
int parser_tencent_full_percent(const char* text, const char* symbol, int* out_change_x100, int* out_price_x10000);

#endif
