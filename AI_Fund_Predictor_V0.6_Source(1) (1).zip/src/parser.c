#include "parser.h"

static int slen(const char* s) {
    int n = 0;
    if (!s) return 0;
    while (s[n]) n++;
    return n;
}

static int is_digit(char c) { return c >= '0' && c <= '9'; }

static int starts(const char* s, const char* p) {
    int i = 0;
    if (!s || !p) return 0;
    while (p[i]) {
        if (s[i] != p[i]) return 0;
        i++;
    }
    return 1;
}

static const char* find_s(const char* s, const char* p) {
    int i, j;
    if (!s || !p || !p[0]) return s;
    for (i = 0; s[i]; i++) {
        for (j = 0; p[j] && s[i + j] == p[j]; j++) {}
        if (!p[j]) return s + i;
    }
    return 0;
}

static const char* find_n(const char* s, const char* end, const char* p) {
    const char* q = s;
    int plen = slen(p);
    if (!s || !end || !p || !plen) return 0;
    while (q + plen <= end) {
        int j = 0;
        while (j < plen && q[j] == p[j]) j++;
        if (j == plen) return q;
        q++;
    }
    return 0;
}

static void clear_mem(void* p0, unsigned long long n) {
    unsigned char* p = (unsigned char*)p0;
    unsigned long long i;
    for (i = 0; i < n; i++) p[i] = 0;
}

static void copy_cap(char* d, int cap, const char* s, int n) {
    int i = 0;
    if (!d || cap <= 0) return;
    if (n < 0) n = slen(s);
    while (s && i < n && i < cap - 1) {
        d[i] = s[i];
        i++;
    }
    d[i] = 0;
}

static int atoi_simple(const char* s) {
    int v = 0, neg = 0;
    if (!s) return 0;
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
    if (*s == '-') {
        neg = 1;
        s++;
    }
    while (is_digit(*s)) {
        v = v * 10 + (*s - '0');
        s++;
    }
    return neg ? -v : v;
}

static long long atoll_simple(const char* s) {
    long long v = 0;
    int neg = 0;
    if (!s) return 0;
    if (*s == '-') {
        neg = 1;
        s++;
    }
    while (is_digit(*s)) {
        v = v * 10 + (*s - '0');
        s++;
    }
    return neg ? -v : v;
}

int parser_decimal_scaled(const char* s, int scale_digits, int* out) {
    long long whole = 0, frac = 0, mul = 1;
    int neg = 0, d = 0, seen = 0;
    if (!s || !out || scale_digits < 0 || scale_digits > 6) return 0;
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n' || *s == '"') s++;
    if (*s == '-') {
        neg = 1;
        s++;
    } else if (*s == '+') {
        s++;
    }
    while (is_digit(*s)) {
        whole = whole * 10 + (*s - '0');
        s++;
        seen = 1;
    }
    if (*s == '.') {
        s++;
        while (is_digit(*s) && d < scale_digits) {
            frac = frac * 10 + (*s - '0');
            mul *= 10;
            d++;
            s++;
            seen = 1;
        }
        while (d < scale_digits) {
            frac *= 10;
            mul *= 10;
            d++;
        }
    } else {
        for (d = 0; d < scale_digits; d++) mul *= 10;
    }
    if (!seen) return 0;
    *out = (int)((whole * mul + frac) * (neg ? -1 : 1));
    return 1;
}

static int extract_quoted_after(const char* text, const char* key, char* out, int cap) {
    const char* p = find_s(text, key);
    const char* q;
    int n = 0;
    if (!p) return 0;
    p += slen(key);
    while (*p && *p != '"') p++;
    if (*p != '"') return 0;
    p++;
    q = p;
    while (*q) {
        if (*q == '"' && (q == p || q[-1] != '\\')) break;
        q++;
    }
    if (*q != '"') return 0;
    while (p < q && n < cap - 1) {
        if (*p == '\\' && p + 1 < q && (p[1] == '"' || p[1] == '\\' || p[1] == '/')) p++;
        out[n++] = *p++;
    }
    out[n] = 0;
    return 1;
}


static int json_value_between(const char* start, const char* end, const char* key, char* out, int cap) {
    const char* p = find_n(start, end, key);
    int n = 0;
    if (!p || !out || cap <= 0) return 0;
    p += slen(key);
    while (p < end && (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' || *p == ':')) p++;
    if (p >= end) return 0;
    if (*p == '"') {
        p++;
        while (p < end && *p != '"' && n < cap - 1) {
            if (*p == '\\' && p + 1 < end && (p[1] == '"' || p[1] == '\\' || p[1] == '/')) p++;
            out[n++] = *p++;
        }
    } else {
        while (p < end && *p != ',' && *p != '}' && *p != '\r' && *p != '\n' && n < cap - 1) out[n++] = *p++;
        while (n > 0 && (out[n-1] == ' ' || out[n-1] == '\t')) n--;
        if (n == 4 && out[0] == 'n' && out[1] == 'u' && out[2] == 'l' && out[3] == 'l') n = 0;
    }
    out[n] = 0;
    return n > 0;
}

int parser_mnfinfo_find(const char* text, const char* code, FundCurrentParsed* out) {
    char needle[48], tmp[64];
    int n = 0, i = 0;
    const char* hit;
    const char* obj_start;
    const char* obj_end;
    if (!text || !code || !out) return 0;
    clear_mem(out, sizeof(*out));
    needle[n++]='"'; needle[n++]='F'; needle[n++]='C'; needle[n++]='O'; needle[n++]='D'; needle[n++]='E'; needle[n++]='"'; needle[n++]=':'; needle[n++]='"';
    while (code[i] && n < 40) needle[n++]=code[i++];
    needle[n++]='"'; needle[n]=0;
    hit = find_s(text, needle);
    if (!hit) return 0;
    obj_start = hit;
    while (obj_start > text && *obj_start != '{') obj_start--;
    if (*obj_start != '{') obj_start = hit;
    obj_end = find_s(hit, "}");
    if (!obj_end) obj_end = text + slen(text);
    json_value_between(obj_start,obj_end,"\"FCODE\"",out->code,sizeof(out->code));
    json_value_between(obj_start,obj_end,"\"SHORTNAME\"",out->name,sizeof(out->name));
    json_value_between(obj_start,obj_end,"\"PDATE\"",out->nav_date,sizeof(out->nav_date));
    if (json_value_between(obj_start,obj_end,"\"NAV\"",tmp,sizeof(tmp))) parser_decimal_scaled(tmp,4,&out->nav_x10000);
    if (json_value_between(obj_start,obj_end,"\"NAVCHGRT\"",tmp,sizeof(tmp))) parser_decimal_scaled(tmp,2,&out->nav_change_x100);
    if (json_value_between(obj_start,obj_end,"\"GSZ\"",tmp,sizeof(tmp))) parser_decimal_scaled(tmp,4,&out->estimate_x10000);
    if (json_value_between(obj_start,obj_end,"\"GSZZL\"",tmp,sizeof(tmp))) parser_decimal_scaled(tmp,2,&out->estimate_change_x100);
    /* Expansion.GZTIME is outside each object; best-effort parse from the whole payload. */
    if (!extract_quoted_after(text,"\"GZTIME\":",out->estimate_time,sizeof(out->estimate_time))) out->estimate_time[0]=0;
    out->ok = out->code[0] && out->name[0] && out->nav_x10000 > 0;
    return out->ok;
}

int parser_basic_info(const char* text, FundBasicParsed* out) {
    if (!text || !out) return 0;
    clear_mem(out, sizeof(*out));
    /* FundMNNBasicInformation has historically exposed these stable identity keys.
       BENCH/PERFCMP and JJJL are best-effort because not every fund type returns them. */
    extract_quoted_after(text, "\"FCODE\":", out->code, sizeof(out->code));
    extract_quoted_after(text, "\"SHORTNAME\":", out->name, sizeof(out->name));
    extract_quoted_after(text, "\"FTYPE\":", out->fund_type, sizeof(out->fund_type));
    extract_quoted_after(text, "\"JJGS\":", out->fund_company, sizeof(out->fund_company));
    extract_quoted_after(text, "\"JJJL\":", out->fund_manager, sizeof(out->fund_manager));
    extract_quoted_after(text, "\"ESTABDATE\":", out->established_date, sizeof(out->established_date));
    if (!extract_quoted_after(text, "\"BENCH\":", out->benchmark, sizeof(out->benchmark)))
        extract_quoted_after(text, "\"PERFCMP\":", out->benchmark, sizeof(out->benchmark));
    out->ok = out->code[0] && out->name[0];
    return out->ok;
}

int parser_fundgz(const char* text, FundGzParsed* out) {
    char tmp[64];
    if (!text || !out) return 0;
    clear_mem(out, sizeof(*out));
    if (!find_s(text, "jsonpgz(")) return 0;
    extract_quoted_after(text, "\"fundcode\":", out->code, sizeof(out->code));
    extract_quoted_after(text, "\"name\":", out->name, sizeof(out->name));
    if (!extract_quoted_after(text, "\"jzrq\":", out->nav_date, sizeof(out->nav_date))) out->nav_date[0] = 0;
    if (!extract_quoted_after(text, "\"gztime\":", out->estimate_time, sizeof(out->estimate_time))) out->estimate_time[0] = 0;
    if (extract_quoted_after(text, "\"dwjz\":", tmp, sizeof(tmp))) parser_decimal_scaled(tmp, 4, &out->nav_x10000);
    if (extract_quoted_after(text, "\"gsz\":", tmp, sizeof(tmp))) parser_decimal_scaled(tmp, 4, &out->estimate_x10000);
    if (extract_quoted_after(text, "\"gszzl\":", tmp, sizeof(tmp))) parser_decimal_scaled(tmp, 2, &out->estimate_change_x100);
    out->ok = out->code[0] && out->name[0] && (out->nav_x10000 > 0 || out->estimate_x10000 > 0);
    return out->ok;
}

int parser_ping_name(const char* text, char* out_name, int cap) {
    const char* p = find_s(text, "var fS_name");
    const char* q;
    int n = 0;
    if (!p || !out_name || cap <= 0) return 0;
    p = find_s(p, "=");
    if (!p) return 0;
    p++;
    while (*p && *p != '"') p++;
    if (*p != '"') return 0;
    p++;
    q = p;
    while (*q && *q != '"') q++;
    if (*q != '"') return 0;
    while (p < q && n < cap - 1) out_name[n++] = *p++;
    out_name[n] = 0;
    return n > 0;
}

int parser_unix_ms_to_date(long long ms) {
    long long z = ms / 86400000LL;
    long long era, doe, yoe, y, doy, mp;
    int m, day;
    z += 719468;
    era = (z >= 0 ? z : z - 146096) / 146097;
    doe = z - era * 146097;
    yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    y = yoe + era * 400;
    doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    mp = (5 * doy + 2) / 153;
    day = (int)(doy - (153 * mp + 2) / 5 + 1);
    m = (int)(mp + (mp < 10 ? 3 : -9));
    y += (m <= 2);
    return (int)y * 10000 + m * 100 + day;
}

int parser_ping_nav(const char* text, ParsedNavPoint* out, int max_points) {
    const char* p = find_s(text, "var Data_netWorthTrend");
    const char* end;
    int count = 0;
    if (!p || !out || max_points <= 0) return 0;
    p = find_s(p, "[");
    if (!p) return 0;
    end = find_s(p, "];");
    if (!end) end = text + slen(text);
    while (p < end && count < max_points) {
        const char* x = find_n(p, end, "\"x\":");
        const char* y;
        const char* r;
        const char* obj_end;
        long long ms;
        int nv = 0, rv = 0;
        if (!x) break;
        x += 4;
        ms = atoll_simple(x);
        y = find_n(x, end, "\"y\":");
        if (!y) break;
        y += 4;
        if (!parser_decimal_scaled(y, 4, &nv)) {
            p = x;
            continue;
        }
        obj_end = find_n(y, end, "}");
        r = find_n(y, obj_end ? obj_end : end, "\"equityReturn\":");
        if (r) {
            r += 15;
            parser_decimal_scaled(r, 2, &rv);
        }
        out[count].yyyymmdd = parser_unix_ms_to_date(ms);
        out[count].nav_x10000 = nv;
        out[count].return_x100 = rv;
        count++;
        p = obj_end ? obj_end + 1 : y + 1;
    }
    return count;
}

int parser_date_to_int(const char* s) {
    int y, m, d;
    if (!s || !is_digit(s[0])) return 0;
    y = atoi_simple(s);
    while (is_digit(*s)) s++;
    if (*s == '-' || *s == '/') s++;
    m = atoi_simple(s);
    while (is_digit(*s)) s++;
    if (*s == '-' || *s == '/') s++;
    d = atoi_simple(s);
    if (y < 1900 || m < 1 || m > 12 || d < 1 || d > 31) return 0;
    return y * 10000 + m * 100 + d;
}

int parser_f10_latest_nav(const char* text, ParsedNavPoint* out, int max_points) {
    const char* p = text;
    int count = 0;
    if (!text || !out || max_points <= 0) return 0;
    while ((p = find_s(p, "\"FSRQ\":\"")) != 0 && count < max_points) {
        char date[16], nav[32], ret[32];
        const char* obj_end = find_s(p, "}");
        const char* q;
        int n = 0;
        p += 8;
        while (*p && *p != '"' && n < 15) date[n++] = *p++;
        date[n] = 0;
        if (!obj_end) break;
        q = find_n(p, obj_end, "\"DWJZ\":\"");
        if (!q) {
            p = obj_end + 1;
            continue;
        }
        q += 8;
        n = 0;
        while (q < obj_end && *q != '"' && n < 31) nav[n++] = *q++;
        nav[n] = 0;
        q = find_n(p, obj_end, "\"JZZZL\":\"");
        ret[0] = 0;
        if (q) {
            q += 9;
            n = 0;
            while (q < obj_end && *q != '"' && n < 31) ret[n++] = *q++;
            ret[n] = 0;
        }
        out[count].yyyymmdd = parser_date_to_int(date);
        parser_decimal_scaled(nav, 4, &out[count].nav_x10000);
        if (ret[0]) parser_decimal_scaled(ret, 2, &out[count].return_x100);
        else out[count].return_x100 = 0;
        if (out[count].yyyymmdd && out[count].nav_x10000 > 0) count++;
        p = obj_end + 1;
    }
    return count;
}

static int visible_text(const char* a, const char* b, char* out, int cap) {
    int n = 0, in_tag = 0;
    const char* p = a;
    while (p < b && n < cap - 1) {
        char c = *p++;
        if (c == '<') {
            in_tag = 1;
            continue;
        }
        if (c == '>' && in_tag) {
            in_tag = 0;
            continue;
        }
        if (in_tag) continue;
        if (c == '\\' && p < b && (*p == '"' || *p == '\\' || *p == '/')) c = *p++;
        if (c == '&') {
            if (p + 5 <= b && starts(p, "nbsp;")) {
                p += 5;
                c = ' ';
            } else if (p + 4 <= b && starts(p, "amp;")) {
                p += 4;
                c = '&';
            }
        }
        if (c == '\r' || c == '\n' || c == '\t') c = ' ';
        if (c == ' ' && n > 0 && out[n - 1] == ' ') continue;
        out[n++] = c;
    }
    while (n > 0 && out[n - 1] == ' ') n--;
    out[n] = 0;
    return n;
}

static int text_is_code(const char* s) {
    int n = 0;
    if (!s) return 0;
    while (s[n] && is_digit(s[n])) n++;
    return s[n] == 0 && (n == 5 || n == 6);
}

static int has_percent(const char* s) {
    while (s && *s) {
        if (*s == '%') return 1;
        s++;
    }
    return 0;
}

static int text_is_numberish(const char* s) {
    int has = 0;
    if (!s || !*s) return 0;
    if (*s == '+' || *s == '-') s++;
    while (*s) {
        if (is_digit(*s)) {
            has = 1;
            s++;
            continue;
        }
        if (*s == '.' || *s == ',' || *s == '%' || *s == ' ') {
            s++;
            continue;
        }
        return 0;
    }
    return has;
}

static void find_cutoff(const char* text, char* out, int cap) {
    int i;
    if (!out || cap <= 0) return;
    out[0] = 0;
    if (!text) return;
    for (i = 0; text[i]; i++) {
        if (text[i] == '2' && text[i + 1] == '0' && is_digit(text[i + 2]) && is_digit(text[i + 3]) &&
            text[i + 4] == '-' && is_digit(text[i + 5]) && is_digit(text[i + 6]) && text[i + 7] == '-' &&
            is_digit(text[i + 8]) && is_digit(text[i + 9])) {
            copy_cap(out, cap, text + i, 10);
            return;
        }
    }
}

int parser_holdings(const char* text, ParsedHolding* out, int max_holdings, char* cutoff_date, int cutoff_cap) {
    const char* p = text;
    int count = 0;
    if (!text || !out || max_holdings <= 0) return 0;
    if (cutoff_date) find_cutoff(text, cutoff_date, cutoff_cap);
    while ((p = find_s(p, "<tr")) != 0 && count < max_holdings) {
        const char* row_end = find_s(p, "</tr>");
        const char* q;
        char cells[16][192];
        int nc = 0, i, code_i = -1, name_i = -1, weight_i = -1;
        if (!row_end) break;
        q = p;
        while (nc < 16 && (q = find_n(q, row_end, "<td")) != 0) {
            const char* gt = find_n(q, row_end, ">");
            const char* tdend;
            if (!gt) break;
            gt++;
            tdend = find_n(gt, row_end, "</td>");
            if (!tdend) break;
            visible_text(gt, tdend, cells[nc], 192);
            nc++;
            q = tdend + 5;
        }
        for (i = 0; i < nc; i++) {
            if (code_i < 0 && text_is_code(cells[i])) code_i = i;
        }
        if (code_i >= 0) {
            for (i = code_i + 1; i < nc; i++) {
                if (cells[i][0] && !text_is_numberish(cells[i]) && !has_percent(cells[i])) {
                    name_i = i;
                    break;
                }
            }
            for (i = nc - 1; i >= 0; i--) {
                if (has_percent(cells[i])) {
                    weight_i = i;
                    break;
                }
            }
        }
        if (code_i >= 0 && name_i >= 0 && weight_i >= 0) {
            int w = 0;
            copy_cap(out[count].code, sizeof(out[count].code), cells[code_i], -1);
            copy_cap(out[count].name, sizeof(out[count].name), cells[name_i], -1);
            parser_decimal_scaled(cells[weight_i], 2, &w);
            out[count].weight_x100 = w;
            if (w > 0) count++;
        }
        p = row_end + 5;
    }
    return count;
}

static int field_between_tildes(const char* start, int wanted, char* out, int cap) {
    int idx = 0, n = 0;
    const char* p = start;
    while (*p && *p != '"') {
        if (idx == wanted) {
            while (*p && *p != '~' && *p != '"' && n < cap - 1) out[n++] = *p++;
            out[n] = 0;
            return 1;
        }
        while (*p && *p != '~' && *p != '"') p++;
        if (*p == '~') {
            idx++;
            p++;
        } else {
            break;
        }
    }
    out[0] = 0;
    return 0;
}

int parser_tencent_simple_percent(const char* text, const char* symbol, int* out_change_x100, int* out_price_x10000) {
    char key[64], tmp[64];
    int k = 0, i = 0;
    const char* p;
    if (!text || !symbol || !out_change_x100 || !out_price_x10000) return 0;
    key[k++] = 'v'; key[k++] = '_'; key[k++] = 's'; key[k++] = '_';
    while (symbol[i] && k < 58) key[k++] = symbol[i++];
    key[k++] = '='; key[k++] = '"'; key[k] = 0;
    p = find_s(text, key);
    if (!p) return 0;
    p += slen(key);
    if (!field_between_tildes(p, 3, tmp, sizeof(tmp)) || !parser_decimal_scaled(tmp, 4, out_price_x10000)) return 0;
    if (!field_between_tildes(p, 5, tmp, sizeof(tmp)) || !parser_decimal_scaled(tmp, 2, out_change_x100)) return 0;
    return 1;
}


int parser_tencent_full_percent(const char* text, const char* symbol, int* out_change_x100, int* out_price_x10000) {
    char key[64], tmp[64];
    int k = 0, i = 0;
    const char* p;
    if (!text || !symbol || !out_change_x100 || !out_price_x10000) return 0;
    key[k++] = 'v'; key[k++] = '_';
    while (symbol[i] && k < 58) key[k++] = symbol[i++];
    key[k++] = '='; key[k++] = '"'; key[k] = 0;
    p = find_s(text, key);
    if (!p) return 0;
    p += slen(key);
    if (!field_between_tildes(p, 3, tmp, sizeof(tmp)) || !parser_decimal_scaled(tmp, 4, out_price_x10000)) return 0;
    if (!field_between_tildes(p, 32, tmp, sizeof(tmp)) || !parser_decimal_scaled(tmp, 2, out_change_x100)) return 0;
    return 1;
}
