#include "prediction_input.h"
#include "snapshot.h"

static int wlen_p(const WCHAR* s){int n=0;while(s&&s[n])n++;return n;}
static void wcopy_p(WCHAR* d,int cap,const WCHAR* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void wcat_p(WCHAR* d,int cap,const WCHAR* s){int n=wlen_p(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static void int_p(int v,WCHAR* out,int cap){WCHAR t[24];unsigned int x;int n=0,i=0;if(v<0){out[i++]=L'-';x=(unsigned int)(-(long long)v);}else x=(unsigned int)v;if(x==0)t[n++]=L'0';while(x&&n<23){t[n++]=(WCHAR)(L'0'+x%10);x/=10;}while(n&&i<cap-1)out[i++]=t[--n];out[i]=0;}
static LPCWSTR gate_p(int g){return g==GATE_READY?L"READY":(g==GATE_PARTIAL?L"PARTIAL":(g==GATE_BLOCKED?L"BLOCKED":L"UNKNOWN"));}

static void log_metrics(const StorageContext* st,const FundRecord* f){WCHAR m[384],n[32];wcopy_p(m,384,L"returns 1d/5d/20d/60d=");int_p(f->return_1d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L"/");int_p(f->return_5d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L"/");int_p(f->return_20d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L"/");int_p(f->return_60d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L" vol20=");int_p(f->volatility_20d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L" maxdd60=");int_p(f->max_drawdown_60d_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L" holding_weighted=");int_p(f->holdings_weighted_change_x100,n,32);wcat_p(m,384,n);wcat_p(m,384,L" market_avg=");int_p(f->market_avg_change_x100,n,32);wcat_p(m,384,n);storage_log_ex(st,L"INFO",L"QUANT",f->code,m);}
static void log_gate(const StorageContext* st,const FundRecord* f){WCHAR m[256],n[24];wcopy_p(m,256,L"gate=");wcat_p(m,256,gate_p(f->gate_status));wcat_p(m,256,L" completeness=");int_p(f->data_completeness,n,24);wcat_p(m,256,n);wcat_p(m,256,L" confidence=");int_p(f->data_confidence,n,24);wcat_p(m,256,n);wcat_p(m,256,L" factors=");int_p(f->factor_count,n,24);wcat_p(m,256,n);wcat_p(m,256,L" holdings_quote=");int_p(f->holdings_quoted_count,n,24);wcat_p(m,256,n);wcat_p(m,256,L"/");int_p(f->holding_count,n,24);wcat_p(m,256,n);storage_log_ex(st,f->gate_status==GATE_BLOCKED?L"WARN":L"INFO",L"DATA_GATE",f->code,m);}

int prediction_prepare_all(const StorageContext* storage,FundStore* store,const MarketSnapshot* market){
    NavPoint* nav;int i,j,ready=0,changes[MARKET_COUNT],oks[MARKET_COUNT];
    if(!storage||!store||!market)return 0;
    for(j=0;j<MARKET_COUNT;j++){changes[j]=market->items[j].change_x100;oks[j]=market->items[j].ok;}
    nav=(NavPoint*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(NavPoint)*NAV_MAX_POINTS);if(!nav){storage_log_ex(storage,L"ERROR",L"PRED_INPUT",NULL,L"预测输入内存分配失败");return 0;}
    for(i=0;i<store->count;i++){
        FundRecord* f=&store->funds[i];int n=storage_load_nav_points(storage,f->code,nav,NAV_MAX_POINTS);int sr;
        core_compute_analysis(f,nav,n,changes,oks,MARKET_COUNT);log_metrics(storage,f);log_gate(storage,f);
        if(f->gate_status==GATE_READY)ready++;
        if(n>0){sr=snapshot_capture_if_changed(storage,f,market,nav,n);if(!sr&&f->gate_status!=GATE_BLOCKED)storage_log_ex(storage,L"WARN",L"PRED_INPUT",f->code,L"统计因子已生成，但World Snapshot创建失败");}
        else storage_log_ex(storage,L"WARN",L"SNAPSHOT",f->code,L"无历史净值，跳过World Snapshot");
        if(f->prediction_status==PRED_STATUS_OK){
            storage_log_ex(storage,L"INFO",L"PRED_INPUT",f->code,L"保留当前已校验DeepSeek预测，交由material-change缓存判定是否需要刷新");
        }else if(f->gate_status==GATE_READY){
            core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"预测输入 READY：等待DeepSeek六周期预测");
        }else if(f->gate_status==GATE_PARTIAL){
            core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"预测输入 PARTIAL：允许AI预测但必须降低置信度");
        }else {
            f->prediction_status=PRED_STATUS_BLOCKED;
            core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"预测输入 BLOCKED：关键数据不足，禁止生成AI涨跌预测");
        }
    }
    HeapFree(GetProcessHeap(),0,nav);storage_log_ex(storage,L"INFO",L"PRED_INPUT",NULL,L"V0.5预测输入准备完成");return ready;
}
