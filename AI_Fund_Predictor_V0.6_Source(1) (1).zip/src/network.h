#ifndef NETWORK_H
#define NETWORK_H
#include "winmini.h"

typedef HANDLE HINTERNET;
typedef WORD INTERNET_PORT;

#define INTERNET_DEFAULT_HTTPS_PORT 443
#define WINHTTP_ACCESS_TYPE_DEFAULT_PROXY 0
#define WINHTTP_FLAG_SECURE 0x00800000
#define WINHTTP_QUERY_STATUS_CODE 19
#define WINHTTP_QUERY_FLAG_NUMBER 0x20000000

__declspec(dllimport) HINTERNET WINAPI WinHttpOpen(LPCWSTR,DWORD,LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) HINTERNET WINAPI WinHttpConnect(HINTERNET,LPCWSTR,INTERNET_PORT,DWORD);
__declspec(dllimport) HINTERNET WINAPI WinHttpOpenRequest(HINTERNET,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR*,DWORD);
__declspec(dllimport) BOOL WINAPI WinHttpSendRequest(HINTERNET,LPCWSTR,DWORD,LPVOID,DWORD,DWORD,ULONG_PTR);
__declspec(dllimport) BOOL WINAPI WinHttpReceiveResponse(HINTERNET,LPVOID);
__declspec(dllimport) BOOL WINAPI WinHttpQueryDataAvailable(HINTERNET,DWORD*);
__declspec(dllimport) BOOL WINAPI WinHttpReadData(HINTERNET,LPVOID,DWORD,DWORD*);
__declspec(dllimport) BOOL WINAPI WinHttpCloseHandle(HINTERNET);
__declspec(dllimport) BOOL WINAPI WinHttpSetTimeouts(HINTERNET,int,int,int,int);
__declspec(dllimport) BOOL WINAPI WinHttpQueryHeaders(HINTERNET,DWORD,LPCWSTR,LPVOID,DWORD*,DWORD*);

typedef struct NetResponse {
    char* data;
    DWORD len;
    int ok;
    DWORD win_error;
    DWORD http_status;
} NetResponse;

int net_http_get(LPCWSTR host, LPCWSTR path, LPCWSTR headers, DWORD max_bytes, NetResponse* out);
int net_http_post_json(LPCWSTR host, LPCWSTR path, LPCWSTR headers, const char* body, DWORD body_len, DWORD max_bytes, NetResponse* out);
void net_free(NetResponse* r);

#endif
