#ifndef REVIEW_H
#define REVIEW_H
#include "archive.h"
#include "snapshot.h"
#include "deepseek.h"
#include "review_logic.h"

#define REVIEW_TEXT_CAP 224
#define REVIEW_ITEM_CAP 128
#define REVIEW_LIST_MAX 3
#define REVIEW_LOAD_MAX 64
#define REVIEW_PROMPT_VERSION 1

typedef struct AIReviewRecord {
    u16 prediction_id[ARCHIVE_ID_CAP];
    u16 fund_code[FUND_CODE_CAP];
    u16 fund_name[FUND_NAME_CAP];
    int horizon;
    int direction_correct;
    int range_hit;
    int actual_return_x100;
    int predicted_direction;
    int actual_direction;
    int brier_x10000;
    int reasoning_quality;
    int evidence_score;
    int review_confidence;
    int grade;
    int lucky_hit;
    int snapshot_loaded;
    int prompt_version;
    u16 model[PRED_MODEL_CAP];
    u16 reviewed_time[FUND_TIME_CAP];
    u16 summary[REVIEW_TEXT_CAP];
    u16 supported[REVIEW_LIST_MAX][REVIEW_ITEM_CAP];
    u16 weak[REVIEW_LIST_MAX][REVIEW_ITEM_CAP];
    u16 missed[REVIEW_LIST_MAX][REVIEW_ITEM_CAP];
    u16 lesson[REVIEW_TEXT_CAP];
    u16 reusable_rule[REVIEW_TEXT_CAP];
} AIReviewRecord;

typedef struct ReviewStats {
    int review_count;
    int pending_count;
    int grade_a;
    int grade_b;
    int grade_c;
    int grade_d;
    int lucky_hits;
} ReviewStats;

int review_run(const StorageContext* st,int* scanned_judgments,int* existing_reviews,int* new_reviews,int* failed_reviews);
int review_load_latest(const StorageContext* st,AIReviewRecord* out,int max_records);
int review_get_stats(const StorageContext* st,ReviewStats* out);
const WCHAR* review_grade_name(int grade);
const WCHAR* review_quality_name(int quality);

#endif
