#include "deepseek.h"
#include "network.h"
#include "prediction_repair.h"

#define CFG_MAGIC0 'A'
#define CFG_MAGIC1 'I'
#define CFG_MAGIC2 'D'
#define CFG_MAGIC3 'S'
#define CFG_MAGIC4 'K'
#define CFG_MAGIC5 '0'
#define CFG_MAGIC6 '4'
#define CFG_MAGIC7 0
#define CFG_MAX_BLOB 4096
#define BODY_CAP 65536
#define RESPONSE_CAP (1024*1024)
#define INNER_CAP 131072
#define PREDICTION_PROMPT_VERSION 1
#define DEEPSEEK_MAX_CONCURRENCY 3

typedef struct ProviderHeader { BYTE magic[8]; DWORD version; DWORD model_kind; DWORD blob_len; } ProviderHeader;

typedef struct Buf { char* p; DWORD cap; DWORD n; int ok; } Buf;

static int slen_d(const char* s){int n=0;while(s&&s[n])n++;return n;}
static int wlen_d(const WCHAR* s){int n=0;while(s&&s[n])n++;return n;}
static void clear_d(void* p0,unsigned long long n){unsigned char* p=(unsigned char*)p0;unsigned long long i;for(i=0;i<n;i++)p[i]=0;}
static void copy_d(void* d0,const void* s0,unsigned long long n){unsigned char* d=(unsigned char*)d0;const unsigned char* s=(const unsigned char*)s0;unsigned long long i;for(i=0;i<n;i++)d[i]=s[i];}
static void wcopy_d(WCHAR* d,int cap,const WCHAR* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void wcat_d(WCHAR* d,int cap,const WCHAR* s){int n=wlen_d(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static void int_w(int v,WCHAR* out,int cap){WCHAR t[32];unsigned int x;int n=0,i=0;if(v<0){if(i<cap-1)out[i++]=L'-';x=(unsigned int)(-(long long)v);}else x=(unsigned int)v;if(x==0)t[n++]=L'0';while(x&&n<31){t[n++]=(WCHAR)(L'0'+x%10);x/=10;}while(n&&i<cap-1)out[i++]=t[--n];out[i]=0;}
static void log_num(const StorageContext* st,LPCWSTR level,LPCWSTR module,const u16* code,LPCWSTR prefix,int v){WCHAR m[192],n[32];wcopy_d(m,192,prefix);int_w(v,n,32);wcat_d(m,192,n);storage_log_ex(st,level,module,code,m);}

LPCWSTR deepseek_model_name_w(int model_kind){return model_kind==DEEPSEEK_MODEL_FLASH?L"deepseek-flash":L"deepseek-v4-pro";}
static const char* model_name_a(int model_kind){return model_kind==DEEPSEEK_MODEL_FLASH?"deepseek-flash":"deepseek-v4-pro";}

static int cfg_magic(const ProviderHeader* h){return h&&h->magic[0]==CFG_MAGIC0&&h->magic[1]==CFG_MAGIC1&&h->magic[2]==CFG_MAGIC2&&h->magic[3]==CFG_MAGIC3&&h->magic[4]==CFG_MAGIC4&&h->magic[5]==CFG_MAGIC5&&h->magic[6]==CFG_MAGIC6;}
int deepseek_has_saved_key(const StorageContext* st){return st&&GetFileAttributesW(st->provider_path)!=INVALID_FILE_ATTRIBUTES;}

int deepseek_save_key(const StorageContext* st,LPCWSTR api_key,int model_kind){
    DATA_BLOB inb,outb;ProviderHeader hd;HANDLE h;DWORD wr=0;int chars;WCHAR msg[256],n[32];
    if(!st||!api_key||!api_key[0])return 0;
    if(!st->provider_path[0]){storage_log_ex(st,L"ERROR",L"DEEPSEEK_CONFIG",NULL,L"API Key保存失败：provider_path未初始化");return 0;}
    chars=wlen_d(api_key)+1;if(chars<=1||chars>DEEPSEEK_KEY_CAP)return 0;
    inb.cbData=(DWORD)(chars*sizeof(WCHAR));inb.pbData=(BYTE*)api_key;clear_d(&outb,sizeof(outb));
    if(!CryptProtectData(&inb,L"AI基金预测 DeepSeek API",NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&outb)){
        wcopy_d(msg,256,L"API Key DPAPI加密失败 win_error=");int_w((int)GetLastError(),n,32);wcat_d(msg,256,n);storage_log_ex(st,L"ERROR",L"DEEPSEEK_CONFIG",NULL,msg);return 0;
    }
    if(outb.cbData>CFG_MAX_BLOB){LocalFree(outb.pbData);storage_log_ex(st,L"ERROR",L"DEEPSEEK_CONFIG",NULL,L"API Key加密结果异常：长度超过限制");return 0;}
    clear_d(&hd,sizeof(hd));hd.magic[0]=CFG_MAGIC0;hd.magic[1]=CFG_MAGIC1;hd.magic[2]=CFG_MAGIC2;hd.magic[3]=CFG_MAGIC3;hd.magic[4]=CFG_MAGIC4;hd.magic[5]=CFG_MAGIC5;hd.magic[6]=CFG_MAGIC6;hd.magic[7]=0;hd.version=1;hd.model_kind=(DWORD)(model_kind?model_kind:DEEPSEEK_MODEL_PRO);hd.blob_len=outb.cbData;
    h=CreateFileW(st->provider_path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE){wcopy_d(msg,256,L"API Key配置文件创建失败 win_error=");int_w((int)GetLastError(),n,32);wcat_d(msg,256,n);storage_log_ex(st,L"ERROR",L"DEEPSEEK_CONFIG",NULL,msg);LocalFree(outb.pbData);return 0;}
    if(!WriteFile(h,&hd,sizeof(hd),&wr,NULL)||wr!=sizeof(hd)||!WriteFile(h,outb.pbData,outb.cbData,&wr,NULL)||wr!=outb.cbData){DWORD e=GetLastError();CloseHandle(h);LocalFree(outb.pbData);wcopy_d(msg,256,L"API Key配置文件写入失败 win_error=");int_w((int)e,n,32);wcat_d(msg,256,n);storage_log_ex(st,L"ERROR",L"DEEPSEEK_CONFIG",NULL,msg);return 0;}
    CloseHandle(h);LocalFree(outb.pbData);storage_log_ex(st,L"INFO",L"DEEPSEEK_CONFIG",NULL,L"API Key已使用Windows DPAPI加密保存到config\\provider.dat，日志不记录密钥");return 1;
}

int deepseek_load_config(const StorageContext* st,DeepSeekConfig* cfg){ProviderHeader hd;BYTE* enc;DWORD rd=0;HANDLE h;DATA_BLOB inb,outb;int ok=0;if(!st||!cfg)return 0;clear_d(cfg,sizeof(*cfg));h=CreateFileW(st->provider_path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;if(!ReadFile(h,&hd,sizeof(hd),&rd,NULL)||rd!=sizeof(hd)||!cfg_magic(&hd)||hd.blob_len==0||hd.blob_len>CFG_MAX_BLOB){CloseHandle(h);return 0;}enc=(BYTE*)HeapAlloc(GetProcessHeap(),0,hd.blob_len);if(!enc){CloseHandle(h);return 0;}if(!ReadFile(h,enc,hd.blob_len,&rd,NULL)||rd!=hd.blob_len){HeapFree(GetProcessHeap(),0,enc);CloseHandle(h);return 0;}CloseHandle(h);inb.cbData=hd.blob_len;inb.pbData=enc;clear_d(&outb,sizeof(outb));if(CryptUnprotectData(&inb,NULL,NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&outb)){if(outb.cbData>=sizeof(WCHAR)&&outb.cbData<=DEEPSEEK_KEY_CAP*sizeof(WCHAR)){copy_d(cfg->api_key,outb.pbData,outb.cbData);cfg->api_key[DEEPSEEK_KEY_CAP-1]=0;cfg->model_kind=(hd.model_kind==DEEPSEEK_MODEL_FLASH)?DEEPSEEK_MODEL_FLASH:DEEPSEEK_MODEL_PRO;ok=cfg->api_key[0]!=0;}LocalFree(outb.pbData);}HeapFree(GetProcessHeap(),0,enc);return ok;}

int deepseek_clear_key(const StorageContext* st){HANDLE h;if(!st)return 0;h=CreateFileW(st->provider_path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return 0;CloseHandle(h);storage_log_ex(st,L"INFO",L"DEEPSEEK_CONFIG",NULL,L"已清除本机保存的DeepSeek API Key");return 1;}

static void binit(Buf* b,DWORD cap){b->p=(char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,cap);b->cap=cap;b->n=0;b->ok=b->p?1:0;}
static void bfree(Buf* b){if(b&&b->p)HeapFree(GetProcessHeap(),0,b->p);if(b)clear_d(b,sizeof(*b));}
static void bc(Buf* b,char c){if(!b||!b->ok)return;if(b->n+2>=b->cap){b->ok=0;return;}b->p[b->n++]=c;b->p[b->n]=0;}
static void bs(Buf* b,const char* s){int i=0;if(!b||!b->ok)return;while(s&&s[i])bc(b,s[i++]);}
static void bi(Buf* b,int v){char t[32];unsigned int x;int n=0;if(v<0){bc(b,'-');x=(unsigned int)(-(long long)v);}else x=(unsigned int)v;if(x==0)t[n++]='0';while(x&&n<31){t[n++]=(char)('0'+x%10);x/=10;}while(n)bc(b,t[--n]);}
static void json_ascii(Buf* b,const char* s){bc(b,'"');while(s&&*s){unsigned char c=(unsigned char)*s++;if(c=='"'||c=='\\'){bc(b,'\\');bc(b,(char)c);}else if(c=='\n'){bs(b,"\\n");}else if(c=='\r'){bs(b,"\\r");}else if(c=='\t'){bs(b,"\\t");}else bc(b,(char)c);}bc(b,'"');}
static void json_wide(Buf* b,const WCHAR* ws){int need,i;char* u;if(!ws){json_ascii(b,"");return;}need=WideCharToMultiByte(CP_UTF8,0,ws,-1,NULL,0,NULL,NULL);if(need<=0){json_ascii(b,"");return;}u=(char*)HeapAlloc(GetProcessHeap(),0,(SIZE_T)need);if(!u){b->ok=0;return;}WideCharToMultiByte(CP_UTF8,0,ws,-1,u,need,NULL,NULL);bc(b,'"');for(i=0;u[i];i++){unsigned char c=(unsigned char)u[i];if(c=='"'||c=='\\'){bc(b,'\\');bc(b,(char)c);}else if(c=='\n')bs(b,"\\n");else if(c=='\r')bs(b,"\\r");else if(c=='\t')bs(b,"\\t");else bc(b,(char)c);}bc(b,'"');HeapFree(GetProcessHeap(),0,u);}
static void key(Buf* b,const char* k){json_ascii(b,k);bc(b,':');}

static void append_holdings(Buf* b,const FundRecord* f){int i;bs(b,"[ ");for(i=0;i<f->holding_count&&i<HOLDING_MAX;i++){if(i)bc(b,',');bc(b,'{');key(b,"code");json_wide(b,(WCHAR*)f->holdings[i].code);bc(b,',');key(b,"name");json_wide(b,(WCHAR*)f->holdings[i].name);bc(b,',');key(b,"weight_x100");bi(b,f->holdings[i].weight_x100);bc(b,',');key(b,"change_x100");bi(b,f->holdings[i].change_x100);bc(b,',');key(b,"quote_ok");bi(b,f->holdings[i].quote_ok);bc(b,'}');}bc(b,']');}
static void append_market(Buf* b,const MarketSnapshot* m){int i;static const char* names[7]={"SSE","SZSE","CHINEXT","CSI300","HSI","HSTECH","NASDAQ"};bc(b,'{');for(i=0;i<MARKET_COUNT;i++){if(i)bc(b,',');key(b,names[i]);bc(b,'{');key(b,"ok");bi(b,m->items[i].ok);bc(b,',');key(b,"change_x100");bi(b,m->items[i].change_x100);bc(b,'}');}bc(b,'}');}

static void append_evidence(Buf* b,const FundRecord* f,const MarketSnapshot* m){bc(b,'{');key(b,"fund_code");json_wide(b,(WCHAR*)f->code);bc(b,',');key(b,"fund_name");json_wide(b,(WCHAR*)f->name);bc(b,',');key(b,"fund_type");json_wide(b,(WCHAR*)f->fund_type);bc(b,',');key(b,"data_gate");json_ascii(b,f->gate_status==GATE_READY?"READY":(f->gate_status==GATE_PARTIAL?"PARTIAL":"BLOCKED"));bc(b,',');key(b,"data_completeness");bi(b,f->data_completeness);bc(b,',');key(b,"data_confidence");bi(b,f->data_confidence);bc(b,',');key(b,"nav_x10000");bi(b,f->nav_x10000);bc(b,',');key(b,"nav_date");json_wide(b,(WCHAR*)f->nav_date);bc(b,',');key(b,"returns_x100");bc(b,'{');key(b,"d1");bi(b,f->return_1d_x100);bc(b,',');key(b,"d5");bi(b,f->return_5d_x100);bc(b,',');key(b,"d20");bi(b,f->return_20d_x100);bc(b,',');key(b,"d60");bi(b,f->return_60d_x100);bc(b,'}');bc(b,',');key(b,"volatility20_x100");bi(b,f->volatility_20d_x100);bc(b,',');key(b,"max_drawdown60_x100");bi(b,f->max_drawdown_60d_x100);bc(b,',');key(b,"short_trend");bi(b,f->short_trend);bc(b,',');key(b,"medium_trend");bi(b,f->medium_trend);bc(b,',');key(b,"holdings_weighted_change_x100");bi(b,f->holdings_weighted_change_x100);bc(b,',');key(b,"holdings_positive_contribution_x100");bi(b,f->holdings_positive_contribution_x100);bc(b,',');key(b,"holdings_negative_contribution_x100");bi(b,f->holdings_negative_contribution_x100);bc(b,',');key(b,"holdings_report_date");json_wide(b,(WCHAR*)f->holdings_date);bc(b,',');key(b,"holdings");append_holdings(b,f);bc(b,',');key(b,"market");append_market(b,m);bc(b,'}');}

static void build_body(Buf* b,const FundRecord* f,const MarketSnapshot* m,int model_kind){static const char* system_prompt="You are the forecasting engine of an AI fund research application. Use only the supplied snapshot evidence. Never invent missing facts. Forecast six horizons independently: TODAY, NEXT_DAY, THIS_WEEK, NEXT_WEEK, THIS_MONTH, NEXT_MONTH. This is probabilistic research, not investment advice. Return one valid JSON object only. All explanation text must be concise Simplified Chinese. For each horizon return direction UP/FLAT/DOWN, integer p_up/p_flat/p_down summing exactly 100, return_low_x100 and return_high_x100 where 100 means 1.00%, confidence 0-100, summary, positive array max 3, negative array max 3, uncertainty array max 2, drivers array max 3. Confidence must reflect data quality. Do not output chain-of-thought or reasoning_content in the final JSON.";
    bs(b,"{\"model\":");json_ascii(b,model_name_a(model_kind));bs(b,",\"messages\":[{\"role\":\"system\",\"content\":");json_ascii(b,system_prompt);bs(b,"},{\"role\":\"user\",\"content\":");
    /* Embed the evidence as JSON text in the user message so the model sees an exact machine-readable snapshot. */
    {Buf ev;binit(&ev,32768);append_evidence(&ev,f,m);if(!ev.ok){b->ok=0;bfree(&ev);return;}bs(&ev,"\nOUTPUT_SCHEMA={\"TODAY\":{...},\"NEXT_DAY\":{...},\"THIS_WEEK\":{...},\"NEXT_WEEK\":{...},\"THIS_MONTH\":{...},\"NEXT_MONTH\":{...}}");json_ascii(b,ev.p);bfree(&ev);}bs(b,"}],\"response_format\":{\"type\":\"json_object\"},\"reasoning_effort\":\"high\",\"max_tokens\":6000}");}

static void build_headers(LPCWSTR api_key,WCHAR* out,int cap){wcopy_d(out,cap,L"Authorization: Bearer ");wcat_d(out,cap,api_key);wcat_d(out,cap,L"\r\nContent-Type: application/json\r\nAccept: application/json\r\n");}

static int find_bytes(const char* s,const char* p){int i,j;if(!s||!p||!p[0])return -1;for(i=0;s[i];i++){for(j=0;p[j]&&s[i+j]==p[j];j++){}if(!p[j])return i;}return -1;}
static int eq_a(const char* a,const char* b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==0&&b[i]==0;}
static int lower_a(char c){return c>='A'&&c<='Z'?c+('a'-'A'):c;}
static int eq_ai(const char* a,const char* b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&lower_a(a[i])==lower_a(b[i]))i++;return a[i]==0&&b[i]==0;}
static int hexv(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
static void utf8_cp(Buf* b,unsigned int cp){if(cp<0x80)bc(b,(char)cp);else if(cp<0x800){bc(b,(char)(0xC0|(cp>>6)));bc(b,(char)(0x80|(cp&63)));}else{bc(b,(char)(0xE0|(cp>>12)));bc(b,(char)(0x80|((cp>>6)&63)));bc(b,(char)(0x80|(cp&63)));}}
static int copy_balanced_object(const char* p,char* out,int cap){int n=0,depth=0,instr=0,esc=0;if(!p||*p!='{'||!out||cap<3)return 0;for(;*p&&n<cap-1;p++){char c=*p;out[n++]=c;if(instr){if(esc)esc=0;else if(c=='\\')esc=1;else if(c=='"')instr=0;}else{if(c=='"')instr=1;else if(c=='{')depth++;else if(c=='}'){depth--;if(depth==0){out[n]=0;return 1;}}}}out[n]=0;return 0;}
static int decode_json_string(const char* p,char* out,int cap){int n=0;if(!p||*p!='"')return 0;p++;while(*p&&n<cap-1){char c=*p++;if(c=='"'){out[n]=0;return n>2;}if(c=='\\'){char e=*p++;if(!e)return 0;if(e=='n')c='\n';else if(e=='r')c='\r';else if(e=='t')c='\t';else if(e=='b')c='\b';else if(e=='f')c='\f';else if(e=='u'){int a=hexv(p[0]),b=hexv(p[1]),d=hexv(p[2]),e4=hexv(p[3]);Buf tmp;if(a<0||b<0||d<0||e4<0)return 0;tmp.p=out;tmp.cap=(DWORD)cap;tmp.n=(DWORD)n;tmp.ok=1;utf8_cp(&tmp,(unsigned int)((a<<12)|(b<<8)|(d<<4)|e4));n=(int)tmp.n;p+=4;continue;}else c=e;}out[n++]=c;}out[n]=0;return 0;}
static int extract_outer_content(const char* outer,char* out,int cap,int* repair_direct){const char* scan=outer;const char* hit;int off;if(repair_direct)*repair_direct=0;if(!outer||!out||cap<3)return 0;while((off=find_bytes(scan,"\"content\""))>=0){const char* p=scan+off+9;while(*p&&*p!=':')p++;if(*p==':'){p++;while(*p==' '||*p=='\r'||*p=='\n'||*p=='\t')p++;if(*p=='"'&&decode_json_string(p,out,cap))return 1;if(*p=='{'&&copy_balanced_object(p,out,cap)){if(repair_direct)*repair_direct=1;return 1;}}hit=scan+off+9;if(hit<=scan)break;scan=hit;}if(find_bytes(outer,"\"TODAY\"")>=0&&copy_balanced_object(outer,out,cap)){if(repair_direct)*repair_direct=1;return 1;}return 0;}

static const char* find_a(const char* s,const char* p){int x=find_bytes(s,p);return x<0?NULL:s+x;}
static const char* object_for(const char* json,const char* name,const char** end){char needle[64];int n=0,depth=0,instr=0,esc=0;const char* p;needle[n++]='"';while(*name&&n<60)needle[n++]=*name++;needle[n++]='"';needle[n]=0;p=find_a(json,needle);if(!p)return NULL;while(*p&&*p!='{')p++;if(*p!='{')return NULL;{const char* q=p;for(;*q;q++){char c=*q;if(instr){if(esc){esc=0;continue;}if(c=='\\'){esc=1;continue;}if(c=='"')instr=0;}else{if(c=='"')instr=1;else if(c=='{')depth++;else if(c=='}'){depth--;if(depth==0){if(end)*end=q+1;return p;}}}}}return NULL;}
static const char* object_for_aliases(const char* json,const char* const* names,int count,const char** end,int* alias_index){int i;const char* a;if(alias_index)*alias_index=-1;for(i=0;i<count;i++){a=object_for(json,names[i],end);if(a){if(alias_index)*alias_index=i;return a;}}return NULL;}
static const char* find_in(const char* a,const char* z,const char* needle){int len=slen_d(needle);const char* p=a;while(p&&p+len<=z){int i=0;while(i<len&&p[i]==needle[i])i++;if(i==len)return p;p++;}return NULL;}
static int get_int(const char* a,const char* z,const char* k,int* out){char needle[64];int n=0,neg=0,v=0,got=0,quoted=0;const char* p;needle[n++]='"';while(*k&&n<58)needle[n++]=*k++;needle[n++]='"';needle[n]=0;p=find_in(a,z,needle);if(!p)return 0;p+=n;while(p<z&&*p!=':')p++;if(p>=z)return 0;p++;while(p<z&&(*p==' '||*p=='\t'||*p=='\r'||*p=='\n'))p++;if(p<z&&*p=='"'){quoted=1;p++;}if(p<z&&*p=='+')p++;if(p<z&&*p=='-'){neg=1;p++;}while(p<z&&*p>='0'&&*p<='9'){v=v*10+(*p-'0');p++;got=1;}if(quoted&&p<z&&*p!='"'&&*p!='%'&&*p!=' '&&*p!='\t')return 0;if(!got)return 0;*out=neg?-v:v;return 1;}
static int get_int_any(const char* a,const char* z,const char* const* keys,int count,int* out){int i;for(i=0;i<count;i++)if(get_int(a,z,keys[i],out))return 1;return 0;}
static int get_str_utf8(const char* a,const char* z,const char* k,char* out,int cap){char needle[64];int n=0,o=0;const char* p;needle[n++]='"';while(*k&&n<58)needle[n++]=*k++;needle[n++]='"';needle[n]=0;p=find_in(a,z,needle);if(!p)return 0;p+=n;while(p<z&&*p!=':')p++;if(p>=z)return 0;p++;while(p<z&&(*p==' '||*p=='\t'||*p=='\r'||*p=='\n'))p++;if(p>=z||*p!='"')return 0;p++;while(p<z&&o<cap-1){char c=*p++;if(c=='"')break;if(c=='\\'&&p<z){char e=*p++;if(e=='n')c=' ';else if(e=='r'||e=='t')c=' ';else c=e;}out[o++]=c;}out[o]=0;return o>0;}
static int get_str_any(const char* a,const char* z,const char* const* keys,int count,char* out,int cap){int i;for(i=0;i<count;i++)if(get_str_utf8(a,z,keys[i],out,cap))return 1;return 0;}
static void utf8_to_w(const char* u,WCHAR* out,int cap){int n;if(!out||cap<=0)return;out[0]=0;if(!u)return;n=MultiByteToWideChar(CP_UTF8,0,u,-1,out,cap);if(n<=0)out[0]=0;else out[cap-1]=0;}
static int get_array_item(const char* a,const char* z,const char* k,int idx,char* out,int cap){char needle[64];int n=0,count=-1,o=0;const char* p;needle[n++]='"';while(*k&&n<58)needle[n++]=*k++;needle[n++]='"';needle[n]=0;p=find_in(a,z,needle);if(!p)return 0;p+=n;while(p<z&&*p!='[')p++;if(p>=z)return 0;p++;while(p<z&&*p!=']'){while(p<z&&(*p==' '||*p==','||*p=='\r'||*p=='\n'||*p=='\t'))p++;if(p>=z||*p==']')break;if(*p=='"'){count++;p++;o=0;while(p<z&&*p!='"'&&o<cap-1){char c=*p++;if(c=='\\'&&p<z)c=*p++;if(count==idx)out[o++]=c;}if(count==idx){out[o]=0;return o>0;}while(p<z&&*p!='"')p++;if(p<z)p++;}else{while(p<z&&*p!=','&&*p!=']')p++;}}return 0;}
static int direction_val(const char* s){if(!s)return 99;if(eq_ai(s,"UP")||eq_ai(s,"RISE")||eq_ai(s,"BULLISH")||eq_a(s,"上涨"))return PRED_DIR_UP;if(eq_ai(s,"DOWN")||eq_ai(s,"FALL")||eq_ai(s,"BEARISH")||eq_a(s,"下跌"))return PRED_DIR_DOWN;if(eq_ai(s,"FLAT")||eq_ai(s,"NEUTRAL")||eq_ai(s,"SIDEWAYS")||eq_a(s,"震荡")||eq_a(s,"横盘"))return PRED_DIR_FLAT;return 99;}

#define PARSE_OK 0
#define PARSE_MISSING_HORIZON 1
#define PARSE_MISSING_DIRECTION 2
#define PARSE_MISSING_PROB 3
#define PARSE_MISSING_RANGE 4
#define PARSE_MISSING_CONFIDENCE 5
#define PARSE_MISSING_SUMMARY 6
#define PARSE_UNREPAIRABLE_NUMERIC 7
#define PARSE_FINAL_VALIDATION 8

static LPCWSTR parse_reason_w(int r){switch(r){case PARSE_MISSING_HORIZON:return L"missing_horizon";case PARSE_MISSING_DIRECTION:return L"missing_direction";case PARSE_MISSING_PROB:return L"missing_probability";case PARSE_MISSING_RANGE:return L"missing_expected_range";case PARSE_MISSING_CONFIDENCE:return L"missing_confidence";case PARSE_MISSING_SUMMARY:return L"missing_summary";case PARSE_UNREPAIRABLE_NUMERIC:return L"numeric_inconsistency_unrepairable";case PARSE_FINAL_VALIDATION:return L"final_validation_failed";default:return L"unknown";}}
static void log_repair(const StorageContext* st,const u16* code,const char* horizon,LPCWSTR reason,LPCWSTR action){WCHAR h[48],m[320];utf8_to_w(horizon,h,48);wcopy_d(m,320,L"horizon=");wcat_d(m,320,h);wcat_d(m,320,L" reason=");wcat_d(m,320,reason);wcat_d(m,320,L" action=");wcat_d(m,320,action);wcat_d(m,320,L" result=PASS");storage_log_ex(st,L"INFO",L"JSON_REPAIR",code,m);}
static void log_reject(const StorageContext* st,const u16* code,const char* horizon,int reason){WCHAR h[48],m[320];utf8_to_w(horizon,h,48);wcopy_d(m,320,L"horizon=");wcat_d(m,320,h);wcat_d(m,320,L" reason=");wcat_d(m,320,parse_reason_w(reason));wcat_d(m,320,L" action=REJECT");storage_log_ex(st,L"ERROR",L"JSON_REPAIR",code,m);}

static int parse_horizon(const StorageContext* st,const u16* code,const char* inner,const char* canonical,const char* const* aliases,int alias_count,PredictionHorizon* h,int* fail_reason){
    static const char* direction_keys[]={"direction","trend"};static const char* up_keys[]={"p_up","up_probability","prob_up"};static const char* flat_keys[]={"p_flat","flat_probability","prob_flat"};static const char* down_keys[]={"p_down","down_probability","prob_down"};static const char* low_keys[]={"return_low_x100","expected_return_low_x100"};static const char* high_keys[]={"return_high_x100","expected_return_high_x100"};static const char* conf_keys[]={"confidence","confidence_score"};static const char* summary_keys[]={"summary","conclusion","reason"};
    const char* z;const char* a;char tmp[1024];int i,alias_idx=-1,flags=0,old_sum,old_dir,old_low,old_high,old_conf;
    if(fail_reason)*fail_reason=PARSE_OK;if(!h)return 0;clear_d(h,sizeof(*h));a=object_for_aliases(inner,aliases,alias_count,&z,&alias_idx);if(!a||!z){if(fail_reason)*fail_reason=PARSE_MISSING_HORIZON;return 0;}
    if(alias_idx>0)log_repair(st,code,canonical,L"horizon_alias",L"mapped_to_canonical");
    if(!get_str_any(a,z,direction_keys,2,tmp,sizeof(tmp))){if(fail_reason)*fail_reason=PARSE_MISSING_DIRECTION;return 0;}h->direction=direction_val(tmp);
    if(!get_int_any(a,z,up_keys,3,&h->p_up)||!get_int_any(a,z,flat_keys,3,&h->p_flat)||!get_int_any(a,z,down_keys,3,&h->p_down)){if(fail_reason)*fail_reason=PARSE_MISSING_PROB;return 0;}
    if(!get_int_any(a,z,low_keys,2,&h->return_low_x100)||!get_int_any(a,z,high_keys,2,&h->return_high_x100)){if(fail_reason)*fail_reason=PARSE_MISSING_RANGE;return 0;}
    if(!get_int_any(a,z,conf_keys,2,&h->confidence)){if(fail_reason)*fail_reason=PARSE_MISSING_CONFIDENCE;return 0;}
    if(!get_str_any(a,z,summary_keys,3,tmp,sizeof(tmp))){if(fail_reason)*fail_reason=PARSE_MISSING_SUMMARY;return 0;}utf8_to_w(tmp,(WCHAR*)h->summary,PRED_REASON_CAP);
    for(i=0;i<PRED_LIST_MAX;i++){if(get_array_item(a,z,"positive",i,tmp,sizeof(tmp)))utf8_to_w(tmp,(WCHAR*)h->positive[i],PRED_ITEM_CAP);if(get_array_item(a,z,"negative",i,tmp,sizeof(tmp)))utf8_to_w(tmp,(WCHAR*)h->negative[i],PRED_ITEM_CAP);if(get_array_item(a,z,"drivers",i,tmp,sizeof(tmp)))utf8_to_w(tmp,(WCHAR*)h->drivers[i],PRED_ITEM_CAP);}for(i=0;i<PRED_UNCERTAINTY_MAX;i++)if(get_array_item(a,z,"uncertainty",i,tmp,sizeof(tmp)))utf8_to_w(tmp,(WCHAR*)h->uncertainty[i],PRED_ITEM_CAP);
    h->valid=1;old_sum=h->p_up+h->p_flat+h->p_down;old_dir=h->direction;old_low=h->return_low_x100;old_high=h->return_high_x100;old_conf=h->confidence;
    if(!prediction_repair_horizon(h,&flags)){if(fail_reason)*fail_reason=PARSE_UNREPAIRABLE_NUMERIC;return 0;}
    if(flags&PRED_REPAIR_PROB_NORMALIZED){WCHAR r[96],n[32];wcopy_d(r,96,L"probability_sum_");int_w(old_sum,n,32);wcat_d(r,96,n);log_repair(st,code,canonical,r,L"normalized_to_100");}
    if(flags&PRED_REPAIR_DIRECTION_FIXED){(void)old_dir;log_repair(st,code,canonical,L"direction_probability_mismatch",L"aligned_to_unique_max_probability");}
    if(flags&PRED_REPAIR_RANGE_SWAPPED){(void)old_low;(void)old_high;log_repair(st,code,canonical,L"return_range_reversed",L"swapped_low_high");}
    if(flags&PRED_REPAIR_CONFIDENCE_CLAMPED){WCHAR r[96],n[32];wcopy_d(r,96,L"confidence_out_of_range_");int_w(old_conf,n,32);wcat_d(r,96,n);log_repair(st,code,canonical,r,L"clamped_to_0_100");}
    if(!core_validate_prediction_horizon(h)){if(fail_reason)*fail_reason=PARSE_FINAL_VALIDATION;return 0;}return 1;
}

static int parse_prediction(const StorageContext* st,const u16* code,const char* outer,PredictionHorizon out[HORIZON_COUNT],int* fail_horizon){
    static const char* a0[]={"TODAY","today","今天"};static const char* a1[]={"NEXT_DAY","NEXT_TRADING_DAY","TOMORROW","next_day","明日","明天"};static const char* a2[]={"THIS_WEEK","this_week","本周"};static const char* a3[]={"NEXT_WEEK","next_week","下周"};static const char* a4[]={"THIS_MONTH","this_month","本月"};static const char* a5[]={"NEXT_MONTH","next_month","下月"};
    static const char* canonical[6]={"TODAY","NEXT_DAY","THIS_WEEK","NEXT_WEEK","THIS_MONTH","NEXT_MONTH"};static const char* const* aliases[6]={a0,a1,a2,a3,a4,a5};static const int counts[6]={3,6,3,3,3,3};char* inner;int i,ok=1,direct=0,reason=0;if(fail_horizon)*fail_horizon=-1;inner=(char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,INNER_CAP);if(!inner)return 0;if(!extract_outer_content(outer,inner,INNER_CAP,&direct)){HeapFree(GetProcessHeap(),0,inner);if(fail_horizon)*fail_horizon=-2;storage_log_ex(st,L"ERROR",L"JSON_REPAIR",code,L"horizon=ALL reason=outer_content_unreadable action=REJECT");return 0;}if(direct)storage_log_ex(st,L"INFO",L"JSON_REPAIR",code,L"horizon=ALL reason=content_returned_as_object action=accepted_direct_object result=PASS");for(i=0;i<6;i++)if(!parse_horizon(st,code,inner,canonical[i],aliases[i],counts[i],&out[i],&reason)){ok=0;log_reject(st,code,canonical[i],reason);if(fail_horizon&&*fail_horizon<0)*fail_horizon=i;}HeapFree(GetProcessHeap(),0,inner);return ok;}

static int call_model(const StorageContext* st,LPCWSTR keyw,int model_kind,const FundRecord* f,const MarketSnapshot* m,PredictionHorizon out[6],DWORD* http_status){Buf body;WCHAR headers[DEEPSEEK_KEY_CAP+160];NetResponse r;int ok=0,fail_h=-1;binit(&body,BODY_CAP);build_body(&body,f,m,model_kind);if(!body.ok){bfree(&body);storage_log_ex(st,L"ERROR",L"DEEPSEEK_REQUEST",f?f->code:NULL,L"预测请求JSON构建失败");return 0;}build_headers(keyw,headers,DEEPSEEK_KEY_CAP+160);clear_d(&r,sizeof(r));{WCHAR msg[256],n[32];wcopy_d(msg,256,L"model=");wcat_d(msg,256,deepseek_model_name_w(model_kind));wcat_d(msg,256,L" snapshot=");wcat_d(msg,256,f&&f->latest_snapshot_id[0]?(WCHAR*)f->latest_snapshot_id:L"--");wcat_d(msg,256,L" gate=");wcat_d(msg,256,f&&f->gate_status==GATE_READY?L"READY":L"PARTIAL");wcat_d(msg,256,L" request_bytes=");int_w((int)body.n,n,32);wcat_d(msg,256,n);storage_log_ex(st,L"INFO",L"DEEPSEEK_REQUEST",f?f->code:NULL,msg);}if(!net_http_post_json(L"api.deepseek.com",L"/chat/completions",headers,body.p,body.n,RESPONSE_CAP,&r)){log_num(st,L"ERROR",L"DEEPSEEK",f?f->code:NULL,L"网络调用失败 win_error=",(int)r.win_error);goto done;}if(http_status)*http_status=r.http_status;{WCHAR msg[192],n[32];wcopy_d(msg,192,L"HTTP=");int_w((int)r.http_status,n,32);wcat_d(msg,192,n);wcat_d(msg,192,L" response_bytes=");int_w((int)r.len,n,32);wcat_d(msg,192,n);wcat_d(msg,192,L" model=");wcat_d(msg,192,deepseek_model_name_w(model_kind));storage_log_ex(st,(r.http_status>=200&&r.http_status<300)?L"INFO":L"ERROR",L"DEEPSEEK",f?f->code:NULL,msg);}if(!r.ok)goto done;if(!parse_prediction(st,f?f->code:NULL,r.data,out,&fail_h)){WCHAR msg[192],n[32];wcopy_d(msg,192,L"返回内容未通过六周期JSON结构/概率/方向一致性校验，未写入正式预测；fail_horizon=");int_w(fail_h,n,32);wcat_d(msg,192,n);storage_log_ex(st,L"ERROR",L"DEEPSEEK_JSON",f?f->code:NULL,msg);goto done;}storage_log_ex(st,L"INFO",L"DEEPSEEK_JSON",f?f->code:NULL,L"六周期JSON校验通过：6/6，概率和=100，方向与最高概率一致，字段完整");ok=1;done:net_free(&r);bfree(&body);return ok;}


int deepseek_call_json_object(const StorageContext* st,LPCWSTR api_key,int model_kind,const u16* fund_code,LPCWSTR log_module,const char* system_prompt,const char* user_content,int reasoning_high,int max_tokens,char** out_json,DWORD* out_len,DWORD* out_http_status){
    Buf body;WCHAR headers[DEEPSEEK_KEY_CAP+160];NetResponse r;char* inner=NULL;int direct=0,ok=0;DWORD cap=INNER_CAP;WCHAR msg[256],n[32];
    if(out_json)*out_json=NULL;if(out_len)*out_len=0;if(out_http_status)*out_http_status=0;
    if(!st||!api_key||!api_key[0]||!system_prompt||!user_content||!out_json)return 0;
    binit(&body,BODY_CAP);bs(&body,"{\"model\":");json_ascii(&body,model_name_a(model_kind));bs(&body,",\"messages\":[{\"role\":\"system\",\"content\":");json_ascii(&body,system_prompt);bs(&body,"},{\"role\":\"user\",\"content\":");json_ascii(&body,user_content);bs(&body,"}],\"response_format\":{\"type\":\"json_object\"},\"reasoning_effort\":");json_ascii(&body,reasoning_high?"high":"low");bs(&body,",\"max_tokens\":");bi(&body,max_tokens>0?max_tokens:2000);bc(&body,'}');
    if(!body.ok){bfree(&body);storage_log_ex(st,L"ERROR",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,L"结构化请求JSON构建失败");return 0;}
    build_headers(api_key,headers,DEEPSEEK_KEY_CAP+160);clear_d(&r,sizeof(r));
    wcopy_d(msg,256,L"REQUEST model=");wcat_d(msg,256,deepseek_model_name_w(model_kind));wcat_d(msg,256,L" request_bytes=");int_w((int)body.n,n,32);wcat_d(msg,256,n);storage_log_ex(st,L"INFO",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,msg);
    if(!net_http_post_json(L"api.deepseek.com",L"/chat/completions",headers,body.p,body.n,RESPONSE_CAP,&r)){wcopy_d(msg,256,L"网络调用失败 win_error=");int_w((int)r.win_error,n,32);wcat_d(msg,256,n);storage_log_ex(st,L"ERROR",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,msg);goto done;}
    if(out_http_status)*out_http_status=r.http_status;wcopy_d(msg,256,L"HTTP=");int_w((int)r.http_status,n,32);wcat_d(msg,256,n);wcat_d(msg,256,L" response_bytes=");int_w((int)r.len,n,32);wcat_d(msg,256,n);wcat_d(msg,256,L" model=");wcat_d(msg,256,deepseek_model_name_w(model_kind));storage_log_ex(st,r.ok?L"INFO":L"ERROR",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,msg);if(!r.ok)goto done;
    inner=(char*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,cap);if(!inner){storage_log_ex(st,L"ERROR",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,L"结构化响应内存分配失败");goto done;}
    if(!extract_outer_content(r.data,inner,(int)cap,&direct)){storage_log_ex(st,L"ERROR",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,L"无法提取assistant JSON content");goto done;}
    if(direct)storage_log_ex(st,L"INFO",log_module?log_module:L"DEEPSEEK_STRUCTURED",fund_code,L"assistant content以直接JSON对象返回，已兼容读取");
    *out_json=inner;inner=NULL;if(out_len)*out_len=(DWORD)slen_d(*out_json);ok=1;
done:if(inner)HeapFree(GetProcessHeap(),0,inner);net_free(&r);bfree(&body);return ok;
}
void deepseek_free_json(char* p){if(p)HeapFree(GetProcessHeap(),0,p);}

static int test_model(LPCWSTR api_key,int model_kind,DWORD* status){Buf b;WCHAR headers[DEEPSEEK_KEY_CAP+160];NetResponse r;int ok=0;binit(&b,4096);bs(&b,"{\"model\":");json_ascii(&b,model_name_a(model_kind));bs(&b,",\"messages\":[{\"role\":\"user\",\"content\":\"Return one JSON object exactly: {\\\"ok\\\":true}\"}],\"response_format\":{\"type\":\"json_object\"},\"reasoning_effort\":\"low\",\"max_tokens\":64}");if(!b.ok){bfree(&b);return 0;}build_headers(api_key,headers,DEEPSEEK_KEY_CAP+160);clear_d(&r,sizeof(r));if(net_http_post_json(L"api.deepseek.com",L"/chat/completions",headers,b.p,b.n,65536,&r)){if(status)*status=r.http_status;ok=r.ok&&r.data&&find_bytes(r.data,"\"content\"")>=0;}else if(status)*status=0;net_free(&r);bfree(&b);return ok;}

int deepseek_test_key(const StorageContext* st,LPCWSTR api_key,int* out_model_kind,DWORD* out_http_status){DWORD status=0;if(out_model_kind)*out_model_kind=0;if(out_http_status)*out_http_status=0;if(!api_key||wlen_d(api_key)<10)return 0;storage_log_ex(st,L"INFO",L"DEEPSEEK_TEST",NULL,L"开始测试DeepSeek API Key，优先V4-Pro，必要时自动回退V4-Flash");if(test_model(api_key,DEEPSEEK_MODEL_PRO,&status)){if(out_model_kind)*out_model_kind=DEEPSEEK_MODEL_PRO;if(out_http_status)*out_http_status=status;storage_log_ex(st,L"INFO",L"DEEPSEEK_TEST",NULL,L"DeepSeek V4-Pro连接测试成功");return 1;}if(status==401||status==403){if(out_http_status)*out_http_status=status;storage_log_ex(st,L"ERROR",L"DEEPSEEK_TEST",NULL,L"API鉴权失败，请检查Key是否正确或是否有权限");return 0;}if(test_model(api_key,DEEPSEEK_MODEL_FLASH,&status)){if(out_model_kind)*out_model_kind=DEEPSEEK_MODEL_FLASH;if(out_http_status)*out_http_status=status;storage_log_ex(st,L"INFO",L"DEEPSEEK_TEST",NULL,L"V4-Pro不可用，已自动选择V4-Flash并测试成功");return 1;}if(out_http_status)*out_http_status=status;storage_log_ex(st,L"ERROR",L"DEEPSEEK_TEST",NULL,L"DeepSeek连接测试失败");return 0;}

static void set_time(FundRecord* f){SYSTEMTIME tm;WCHAR n[8];GetLocalTime(&tm);f->prediction_time[0]=0;int_w(tm.wYear,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"-");if(tm.wMonth<10)wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"0");int_w(tm.wMonth,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"-");if(tm.wDay<10)wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"0");int_w(tm.wDay,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L" ");if(tm.wHour<10)wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"0");int_w(tm.wHour,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L":");if(tm.wMinute<10)wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"0");int_w(tm.wMinute,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L":");if(tm.wSecond<10)wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,L"0");int_w(tm.wSecond,n,8);wcat_d((WCHAR*)f->prediction_time,FUND_TIME_CAP,n);}

static u64 now_filetime_d(void){FILETIME ft;GetSystemTimeAsFileTime(&ft);return ((u64)ft.dwHighDateTime<<32)|(u64)ft.dwLowDateTime;}
static u64 age_seconds_d(u64 now,u64 then){if(!then||now<=then)return 0;return (now-then)/10000000ULL;}
static LPCWSTR cache_reason_d(int r){
    switch(r){
        case CACHE_CHANGE_BASELINE_MISSING:return L"baseline_uninitialized";
        case CACHE_CHANGE_FUND_META:return L"fund_meta_changed";
        case CACHE_CHANGE_NAV:return L"nav_changed";
        case CACHE_CHANGE_HOLDINGS_REPORT:return L"holdings_report_changed";
        case CACHE_CHANGE_GATE:return L"data_gate_changed";
        case CACHE_CHANGE_QUANT:return L"quant_factor_changed";
        case CACHE_CHANGE_DATA_QUALITY:return L"data_quality_changed";
        case CACHE_CHANGE_HOLDINGS_MARKET:return L"holdings_material_change";
        case CACHE_CHANGE_PUBLIC_MARKET:return L"market_material_change";
        default:return L"no_material_change";
    }
}
static int cache_reason_dynamic_d(int r){return r==CACHE_CHANGE_HOLDINGS_MARKET||r==CACHE_CHANGE_PUBLIC_MARKET;}
static void log_cache_age_d(const StorageContext* st,const u16* code,LPCWSTR prefix,u64 age,LPCWSTR reason){WCHAR m[320],n[32];wcopy_d(m,320,prefix);wcat_d(m,320,L" age_sec=");int_w((int)(age>2147483647ULL?2147483647ULL:age),n,32);wcat_d(m,320,n);if(reason&&reason[0]){wcat_d(m,320,L" deferred=");wcat_d(m,320,reason);}storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",code,m);}

typedef struct PredictionJob {
    const StorageContext* st;
    FundRecord* fund;
    const MarketSnapshot* market;
    DeepSeekConfig cfg;
    int market_changes[MARKET_COUNT];
    int market_oks[MARKET_COUNT];
    int queue_index;
    int success;
    int model_used;
    DWORD http_status;
} PredictionJob;

static void log_queue_d(const StorageContext* st,int queued,int cache_hits,int blocked,int concurrency){
    WCHAR m[256],n[32];
    wcopy_d(m,256,L"queued=");int_w(queued,n,32);wcat_d(m,256,n);
    wcat_d(m,256,L" cache_hit=");int_w(cache_hits,n,32);wcat_d(m,256,n);
    wcat_d(m,256,L" blocked=");int_w(blocked,n,32);wcat_d(m,256,n);
    wcat_d(m,256,L" max_concurrency=");int_w(concurrency,n,32);wcat_d(m,256,n);
    storage_log_ex(st,L"INFO",L"DEEPSEEK_QUEUE",NULL,m);
}

static DWORD WINAPI prediction_worker_d(LPVOID p0){
    PredictionJob* job=(PredictionJob*)p0;PredictionHorizon* pred;FundRecord* f;DWORD status=0;int h,ok,model_kind;u64 now;WCHAR m[160],n[32];
    if(!job||!job->st||!job->fund||!job->market)return 0;
    f=job->fund;model_kind=job->cfg.model_kind;
    wcopy_d(m,160,L"START queue_index=");int_w(job->queue_index,n,32);wcat_d(m,160,n);wcat_d(m,160,L" model=");wcat_d(m,160,deepseek_model_name_w(model_kind));
    storage_log_ex(job->st,L"INFO",L"DEEPSEEK_WORKER",f->code,m);
    pred=(PredictionHorizon*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(PredictionHorizon)*HORIZON_COUNT);
    if(!pred){storage_log_ex(job->st,L"ERROR",L"DEEPSEEK_WORKER",f->code,L"预测结果内存分配失败");return 0;}
    ok=call_model(job->st,job->cfg.api_key,model_kind,f,job->market,pred,&status);
    if(!ok&&status!=401&&status!=403&&model_kind==DEEPSEEK_MODEL_PRO){
        storage_log_ex(job->st,L"WARN",L"DEEPSEEK",f->code,L"V4-Pro本次调用失败，当前基金自动尝试V4-Flash一次");
        clear_d(pred,sizeof(PredictionHorizon)*HORIZON_COUNT);
        ok=call_model(job->st,job->cfg.api_key,DEEPSEEK_MODEL_FLASH,f,job->market,pred,&status);
        if(ok)model_kind=DEEPSEEK_MODEL_FLASH;
    }
    job->http_status=status;job->model_used=model_kind;
    if(!ok){
        f->prediction_status=PRED_STATUS_ERROR;f->prediction_error=(int)status;
        core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"DeepSeek预测失败：查看运行日志，不显示未经校验的结果");
        storage_log_ex(job->st,L"ERROR",L"DEEPSEEK_WORKER",f->code,L"END result=FAIL");
        HeapFree(GetProcessHeap(),0,pred);return 0;
    }
    for(h=0;h<HORIZON_COUNT;h++){
        if(pred[h].confidence>f->data_confidence)pred[h].confidence=f->data_confidence;
        f->predictions[h]=pred[h];f->direction[h]=pred[h].direction;
        f->probability[h]=(pred[h].direction==PRED_DIR_UP)?pred[h].p_up:((pred[h].direction==PRED_DIR_DOWN)?pred[h].p_down:pred[h].p_flat);
    }
    f->confidence=pred[0].confidence;f->prediction_status=PRED_STATUS_OK;f->prediction_error=0;
    core_wcopy(f->prediction_model,PRED_MODEL_CAP,(const u16*)deepseek_model_name_w(model_kind));
    set_time(f);core_wcopy(f->prediction_snapshot_id,SNAPSHOT_ID_CAP,f->latest_snapshot_id);
    f->prediction_snapshot_hash=f->latest_snapshot_hash;f->prediction_evidence_hash=f->latest_evidence_hash;f->prediction_prompt_version=PREDICTION_PROMPT_VERSION;
    now=now_filetime_d();core_capture_prediction_baseline(f,job->market_changes,job->market_oks,MARKET_COUNT,now);
    core_wcopy(f->summary,FUND_SUMMARY_CAP,pred[0].summary);
    storage_log_ex(job->st,L"INFO",L"PREDICTION_CACHE",f->code,L"BASELINE updated after validated prediction");
    storage_log_ex(job->st,L"INFO",L"PREDICTION",f->code,L"DeepSeek六周期真实预测已通过校验并写入当前基金状态");
    storage_log_ex(job->st,L"INFO",L"DEEPSEEK_WORKER",f->code,L"END result=OK");
    job->success=1;HeapFree(GetProcessHeap(),0,pred);return 0;
}

int deepseek_predict_all(const StorageContext* st,FundStore* store,const MarketSnapshot* market){
    DeepSeekConfig cfg;PredictionJob* jobs;HANDLE handles[DEEPSEEK_MAX_CONCURRENCY];int job_indices[DEEPSEEK_MAX_CONCURRENCY];
    int i,j,queued=0,success=0,cache_hits=0,blocked=0;int market_changes[MARKET_COUNT],market_oks[MARKET_COUNT];
    if(!st||!store||!market)return 0;
    jobs=(PredictionJob*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(PredictionJob)*MAX_FUNDS);
    if(!jobs){storage_log_ex(st,L"ERROR",L"DEEPSEEK_QUEUE",NULL,L"预测队列内存分配失败");return 0;}
    clear_d(handles,sizeof(handles));clear_d(job_indices,sizeof(job_indices));
    for(i=0;i<MARKET_COUNT;i++){market_changes[i]=market->items[i].change_x100;market_oks[i]=market->items[i].ok;}
    if(!deepseek_load_config(st,&cfg)){
        storage_log_ex(st,L"WARN",L"DEEPSEEK",NULL,L"未配置DeepSeek API Key：真实数据、Snapshot和统计因子保持可用，跳过AI预测");
        for(i=0;i<store->count;i++)if(store->funds[i].gate_status!=GATE_BLOCKED)store->funds[i].prediction_status=PRED_STATUS_NO_KEY;
        HeapFree(GetProcessHeap(),0,jobs);return 0;
    }
    for(i=0;i<store->count;i++){
        FundRecord* f=&store->funds[i];int reason=CACHE_CHANGE_NONE;u64 now,age=0;int needs_request=1;
        if(f->gate_status==GATE_BLOCKED){
            f->prediction_status=PRED_STATUS_BLOCKED;blocked++;
            storage_log_ex(st,L"WARN",L"DEEPSEEK",f->code,L"Data Gate=BLOCKED，禁止发送涨跌预测请求");
            continue;
        }
        if(f->prediction_status==PRED_STATUS_OK){
            if(f->prediction_prompt_version!=PREDICTION_PROMPT_VERSION){
                storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",f->code,L"MISS reason=prompt_version_changed");
            }else if(!core_weq(f->prediction_model,(const u16*)deepseek_model_name_w(cfg.model_kind))){
                storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",f->code,L"MISS reason=model_changed");
            }else{
                reason=core_prediction_change_reason(f,market_changes,market_oks,MARKET_COUNT);
                if(reason==CACHE_CHANGE_NONE){
                    if(f->prediction_evidence_hash==f->latest_evidence_hash&&f->prediction_evidence_hash!=0)
                        storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",f->code,L"HIT reason=raw_evidence_unchanged");
                    else
                        storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",f->code,L"HIT reason=no_material_change raw_evidence_changed=1");
                    storage_log_ex(st,L"INFO",L"DEEPSEEK",f->code,L"SKIPPED cache_hit，不占并发槽且不重复调用API");
                    success++;cache_hits++;needs_request=0;
                }else{
                    now=now_filetime_d();age=age_seconds_d(now,f->prediction_baseline.prediction_filetime);
                    if(cache_reason_dynamic_d(reason)&&f->prediction_baseline.prediction_filetime&&age<(u64)CACHE_MIN_REFRESH_SECONDS){
                        log_cache_age_d(st,f->code,L"HIT reason=min_refresh_interval",age,cache_reason_d(reason));
                        storage_log_ex(st,L"INFO",L"DEEPSEEK",f->code,L"SKIPPED cache_hit，动态行情达到阈值但处于最短刷新间隔，不占并发槽");
                        success++;cache_hits++;needs_request=0;
                    }else{
                        WCHAR m[256];wcopy_d(m,256,L"MISS reason=");wcat_d(m,256,cache_reason_d(reason));storage_log_ex(st,L"INFO",L"PREDICTION_CACHE",f->code,m);
                    }
                }
            }
        }
        if(!needs_request)continue;
        if(queued>=MAX_FUNDS){storage_log_ex(st,L"ERROR",L"DEEPSEEK_QUEUE",f->code,L"预测队列已满，跳过本次请求");continue;}
        jobs[queued].st=st;jobs[queued].fund=f;jobs[queued].market=market;jobs[queued].cfg=cfg;jobs[queued].queue_index=queued+1;
        for(j=0;j<MARKET_COUNT;j++){jobs[queued].market_changes[j]=market_changes[j];jobs[queued].market_oks[j]=market_oks[j];}
        queued++;
    }
    log_queue_d(st,queued,cache_hits,blocked,queued<DEEPSEEK_MAX_CONCURRENCY?queued:DEEPSEEK_MAX_CONCURRENCY);
    for(i=0;i<queued;i+=DEEPSEEK_MAX_CONCURRENCY){
        int batch=queued-i;if(batch>DEEPSEEK_MAX_CONCURRENCY)batch=DEEPSEEK_MAX_CONCURRENCY;
        WCHAR m[192],n[32];wcopy_d(m,192,L"START batch_first=");int_w(i+1,n,32);wcat_d(m,192,n);wcat_d(m,192,L" batch_size=");int_w(batch,n,32);wcat_d(m,192,n);storage_log_ex(st,L"INFO",L"DEEPSEEK_BATCH",NULL,m);
        for(j=0;j<batch;j++){
            DWORD tid=0;int qi=i+j;job_indices[j]=qi;
            handles[j]=CreateThread(NULL,0,prediction_worker_d,&jobs[qi],0,&tid);
            if(!handles[j]){
                WCHAR em[160],en[32];wcopy_d(em,160,L"CreateThread失败，当前任务降级为同步执行 win_error=");int_w((int)GetLastError(),en,32);wcat_d(em,160,en);storage_log_ex(st,L"WARN",L"DEEPSEEK_QUEUE",jobs[qi].fund->code,em);
            }
        }
        for(j=0;j<batch;j++)if(!handles[j])prediction_worker_d(&jobs[job_indices[j]]);
        for(j=0;j<batch;j++)if(handles[j]){WaitForSingleObject(handles[j],INFINITE);CloseHandle(handles[j]);handles[j]=NULL;}
        for(j=0;j<batch;j++)if(jobs[job_indices[j]].success)success++;
        wcopy_d(m,192,L"END batch_first=");int_w(i+1,n,32);wcat_d(m,192,n);wcat_d(m,192,L" batch_size=");int_w(batch,n,32);wcat_d(m,192,n);storage_log_ex(st,L"INFO",L"DEEPSEEK_BATCH",NULL,m);
    }
    {WCHAR m[256],n[32];wcopy_d(m,256,L"DONE queued=");int_w(queued,n,32);wcat_d(m,256,n);wcat_d(m,256,L" cache_hit=");int_w(cache_hits,n,32);wcat_d(m,256,n);wcat_d(m,256,L" blocked=");int_w(blocked,n,32);wcat_d(m,256,n);wcat_d(m,256,L" valid_total=");int_w(success,n,32);wcat_d(m,256,n);storage_log_ex(st,L"INFO",L"DEEPSEEK_QUEUE",NULL,m);}
    HeapFree(GetProcessHeap(),0,jobs);return success;
}
