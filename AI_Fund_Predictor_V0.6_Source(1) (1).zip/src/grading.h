#ifndef GRADING_H
#define GRADING_H
#include "core.h"

#define GRADE_PENDING 0
#define GRADE_DONE 1

int grading_parse_date_text(const u16* text, int* out_yyyymmdd);
int grading_add_days(int yyyymmdd, int delta);
int grading_weekday(int yyyymmdd); /* 1=Mon .. 7=Sun */
int grading_next_weekday(int yyyymmdd);
int grading_last_weekday_of_month(int yyyymmdd);
void grading_compute_windows(int prediction_date, int target_start[HORIZON_COUNT], int target_end[HORIZON_COUNT]);
int grading_return_x100(int base_nav_x10000, int target_nav_x10000);
int grading_actual_direction(int return_x100);
int grading_brier_x10000(int p_up, int p_flat, int p_down, int actual_direction);
int grading_confidence_error(int confidence, int direction_correct);

#endif
