#include "prediction_repair.h"

static int dir_prob(const PredictionHorizon* p,int d){
    if(d==PRED_DIR_UP)return p->p_up;
    if(d==PRED_DIR_DOWN)return p->p_down;
    if(d==PRED_DIR_FLAT)return p->p_flat;
    return -1;
}

static int max3(int a,int b,int c){int m=a;if(b>m)m=b;if(c>m)m=c;return m;}

int prediction_repair_horizon(PredictionHorizon* p,int* out_flags){
    int flags=0,sum,maxp,max_count,new_dir=-99,t;
    if(out_flags)*out_flags=0;
    if(!p)return 0;
    if(p->p_up<0||p->p_up>100||p->p_flat<0||p->p_flat>100||p->p_down<0||p->p_down>100)return 0;
    sum=p->p_up+p->p_flat+p->p_down;
    if(sum!=100){
        int up,flat,down;
        if(sum<95||sum>105||sum<=0)return 0;
        up=(p->p_up*100+sum/2)/sum;
        flat=(p->p_flat*100+sum/2)/sum;
        down=100-up-flat;
        if(up<0||up>100||flat<0||flat>100||down<0||down>100)return 0;
        p->p_up=up;p->p_flat=flat;p->p_down=down;flags|=PRED_REPAIR_PROB_NORMALIZED;
    }
    if(p->confidence<0||p->confidence>100){
        if(p->confidence<-5||p->confidence>105)return 0;
        if(p->confidence<0)p->confidence=0;else p->confidence=100;
        flags|=PRED_REPAIR_CONFIDENCE_CLAMPED;
    }
    if(p->return_low_x100<-10000||p->return_low_x100>10000||p->return_high_x100<-10000||p->return_high_x100>10000)return 0;
    if(p->return_low_x100>p->return_high_x100){t=p->return_low_x100;p->return_low_x100=p->return_high_x100;p->return_high_x100=t;flags|=PRED_REPAIR_RANGE_SWAPPED;}
    maxp=max3(p->p_up,p->p_flat,p->p_down);max_count=(p->p_up==maxp)+(p->p_flat==maxp)+(p->p_down==maxp);
    if(p->p_up==maxp)new_dir=PRED_DIR_UP;
    if(p->p_flat==maxp)new_dir=PRED_DIR_FLAT;
    if(p->p_down==maxp)new_dir=PRED_DIR_DOWN;
    if(p->direction<PRED_DIR_DOWN||p->direction>PRED_DIR_UP||dir_prob(p,p->direction)!=maxp){
        if(max_count!=1)return 0;
        p->direction=new_dir;flags|=PRED_REPAIR_DIRECTION_FIXED;
    }
    if(out_flags)*out_flags=flags;
    return 1;
}
