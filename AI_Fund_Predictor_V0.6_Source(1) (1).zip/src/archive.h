#ifndef ARCHIVE_H
#define ARCHIVE_H
#include "storage.h"
#include "grading.h"

#define ARCHIVE_ID_CAP 96
#define ARCHIVE_LOAD_MAX 64
#define JUDGMENT_RESULT_PENDING 0
#define JUDGMENT_RESULT_DONE 1

typedef struct PredictionArchiveRecord {
    u16 prediction_id[ARCHIVE_ID_CAP];
    u16 fund_code[FUND_CODE_CAP];
    u16 fund_name[FUND_NAME_CAP];
    u16 prediction_time[FUND_TIME_CAP];
    u16 snapshot_id[SNAPSHOT_ID_CAP];
    u16 model[PRED_MODEL_CAP];
    int prompt_version;
    u64 snapshot_hash;
    u64 evidence_hash;
    int data_completeness;
    int data_confidence;
    int base_nav_x10000;
    int base_nav_date;
    int target_start[HORIZON_COUNT];
    int target_end[HORIZON_COUNT];
    PredictionHorizon horizons[HORIZON_COUNT];
} PredictionArchiveRecord;

typedef struct JudgmentRecord {
    u16 prediction_id[ARCHIVE_ID_CAP];
    u16 fund_code[FUND_CODE_CAP];
    u16 fund_name[FUND_NAME_CAP];
    int horizon;
    int target_start;
    int target_end;
    int base_nav_x10000;
    int actual_nav_x10000;
    int actual_nav_date;
    int actual_return_x100;
    int predicted_direction;
    int actual_direction;
    int direction_correct;
    int range_hit;
    int brier_x10000;
    int confidence;
    int confidence_error;
    u16 graded_time[FUND_TIME_CAP];
} JudgmentRecord;

typedef struct ArchiveStats {
    int prediction_count;
    int judgment_count;
    int graded_direction_correct;
    int graded_range_hit;
    int pending_horizons;
} ArchiveStats;

int archive_sync_predictions(const StorageContext* st,const FundStore* store,int* appended,int* duplicates);
int archive_auto_grade(const StorageContext* st,int* scanned_predictions,int* matured_horizons,int* new_judgments);
int archive_load_latest_predictions(const StorageContext* st,PredictionArchiveRecord* out,int max_records);
int archive_find_prediction(const StorageContext* st,const u16* prediction_id,PredictionArchiveRecord* out);
int archive_load_latest_judgments(const StorageContext* st,JudgmentRecord* out,int max_records);
int archive_get_stats(const StorageContext* st,ArchiveStats* out);

#endif
