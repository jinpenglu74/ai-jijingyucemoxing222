#ifndef PREDICTION_INPUT_H
#define PREDICTION_INPUT_H
#include "core.h"
#include "storage.h"
#include "provider.h"

/* Builds deterministic local quantitative evidence + Data Gate and freezes
   immutable snapshots. Returns the number of funds that are READY. */
int prediction_prepare_all(const StorageContext* storage, FundStore* store, const MarketSnapshot* market);

#endif
