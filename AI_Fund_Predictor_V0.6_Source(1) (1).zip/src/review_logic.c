#include "review_logic.h"
static int low(char c){return c>='A'&&c<='Z'?c+('a'-'A'):c;}
static int eqi(const char* a,const char* b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&low(a[i])==low(b[i]))i++;return a[i]==0&&b[i]==0;}
int review_quality_from_ascii(const char* s){if(!s)return -1;if(eqi(s,"SUPPORTED")||eqi(s,"CORRECT")||eqi(s,"GOOD"))return REVIEW_QUALITY_SUPPORTED;if(eqi(s,"PARTIAL")||eqi(s,"MIXED"))return REVIEW_QUALITY_PARTIAL;if(eqi(s,"UNSUPPORTED")||eqi(s,"WRONG")||eqi(s,"POOR"))return REVIEW_QUALITY_UNSUPPORTED;return -1;}
int review_compute_grade(int direction_correct,int reasoning_quality){if(direction_correct)return reasoning_quality==REVIEW_QUALITY_SUPPORTED?REVIEW_GRADE_A:REVIEW_GRADE_B;return reasoning_quality>=REVIEW_QUALITY_PARTIAL?REVIEW_GRADE_C:REVIEW_GRADE_D;}
int review_is_lucky_hit(int direction_correct,int reasoning_quality){return direction_correct&&reasoning_quality==REVIEW_QUALITY_UNSUPPORTED;}
