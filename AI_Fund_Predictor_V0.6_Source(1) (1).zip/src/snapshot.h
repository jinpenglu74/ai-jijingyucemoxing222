#ifndef SNAPSHOT_H
#define SNAPSHOT_H
#include "winmini.h"
#include "core.h"
#include "storage.h"
#include "provider.h"

#define SNAPSHOT_NAV_TAIL 120

/* Returns 1 when a new immutable snapshot is created, 2 when the current
   evidence fingerprint matches the last snapshot, 0 on failure. */
int snapshot_capture_if_changed(const StorageContext* storage, FundRecord* fund, const MarketSnapshot* market, const NavPoint* nav, int nav_count);
/* Load the immutable prediction-time snapshot for postmortem review. prediction_time
   is used only to derive the YYYYMMDD directory; the snapshot id and file magic are
   still validated. Returns 1 on success. */
int snapshot_load_frozen(const StorageContext* storage, const u16* prediction_time, const u16* snapshot_id, FundRecord* out_fund, MarketSnapshot* out_market, NavPoint* out_nav, int max_nav, int* out_nav_count);

#endif
