#include "provider.h"
#include "network.h"
#include "parser.h"

#define MAX_HTTP_SMALL (1024U*1024U*2U)
#define MAX_HTTP_HISTORY (1024U*1024U*12U)
#define HOLDINGS_TTL_100NS (24ULL*60ULL*60ULL*10000000ULL)
#define BASIC_TTL_100NS (7ULL*24ULL*60ULL*60ULL*10000000ULL)
#define QUOTE_MAX 256

typedef struct QuoteEntry {
    char code[16];
    char symbol[24];
    int is_full;
    int ok;
    int price_x10000;
    int change_x100;
} QuoteEntry;

static int c_strlen(const char* s){int n=0;while(s&&s[n])n++;return n;}
static int c_streq(const char* a,const char* b){int i=0;if(!a||!b)return 0;while(a[i]&&b[i]&&a[i]==b[i])i++;return a[i]==b[i];}
static void c_copy(char* d,int cap,const char* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void c_cat(char* d,int cap,const char* s){int n=c_strlen(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static int w_len(const WCHAR* s){int n=0;while(s&&s[n])n++;return n;}
static void w_copy(WCHAR* d,int cap,const WCHAR* s){int i=0;if(!d||cap<=0)return;while(s&&s[i]&&i<cap-1){d[i]=s[i];i++;}d[i]=0;}
static void w_cat(WCHAR* d,int cap,const WCHAR* s){int n=w_len(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=s[i++];d[n]=0;}
static void w_cat_u16(WCHAR* d,int cap,const u16* s){int n=w_len(d),i=0;while(s&&s[i]&&n<cap-1)d[n++]=(WCHAR)s[i++];d[n]=0;}
static void w_cat_u64(WCHAR* d,int cap,u64 v){WCHAR tmp[32];int n=0,i; if(v==0){w_cat(d,cap,L"0");return;}while(v&&n<31){tmp[n++]=(WCHAR)(L'0'+(v%10));v/=10;}for(i=n-1;i>=0;i--){WCHAR one[2]={tmp[i],0};w_cat(d,cap,one);}}
static void ascii_from_u16(const u16* s,char* out,int cap){int i=0;if(!out||cap<=0)return;while(s&&s[i]&&i<cap-1){out[i]=(char)(s[i]&0x7f);i++;}out[i]=0;}
static int utf8_to_u16(const char* s,u16* out,int cap){int n;if(!s||!out||cap<=0)return 0;n=MultiByteToWideChar(CP_UTF8,0,s,-1,(WCHAR*)out,cap);if(n<=0){out[0]=0;return 0;}out[cap-1]=0;return 1;}
static void date_ascii_to_u16(const char* s,u16* out,int cap){int i=0;if(!out||cap<=0)return;while(s&&s[i]&&i<cap-1){out[i]=(u16)(unsigned char)s[i];i++;}out[i]=0;}
static void date_int_to_u16(int d,u16* out,int cap){if(!out||cap<11)return;out[0]=(u16)(L'0'+(d/10000000)%10);out[1]=(u16)(L'0'+(d/1000000)%10);out[2]=(u16)(L'0'+(d/100000)%10);out[3]=(u16)(L'0'+(d/10000)%10);out[4]=L'-';out[5]=(u16)(L'0'+(d/1000)%10);out[6]=(u16)(L'0'+(d/100)%10);out[7]=L'-';out[8]=(u16)(L'0'+(d/10)%10);out[9]=(u16)(L'0'+d%10);out[10]=0;}

u64 provider_now_filetime(void){FILETIME ft;GetSystemTimeAsFileTime(&ft);return ((u64)ft.dwHighDateTime<<32)|(u64)ft.dwLowDateTime;}

static void log_msg(const StorageContext* st,const WCHAR* level,const WCHAR* module,const u16* code,const WCHAR* msg){if(st)storage_log_ex(st,level,module,code,msg);} 
static void log_count(const StorageContext* st,const WCHAR* level,const WCHAR* module,const u16* code,const WCHAR* prefix,int v){WCHAR b[256];w_copy(b,256,prefix);w_cat_u64(b,256,(u64)(v<0?0:v));log_msg(st,level,module,code,b);} 
static int fetch(const StorageContext* st,const WCHAR* module,const u16* code,const WCHAR* host,const WCHAR* path,const WCHAR* headers,DWORD max_bytes,NetResponse* r){
    int ok=net_http_get(host,path,headers,max_bytes,r);WCHAR m[512];
    w_copy(m,512,L"host=");w_cat(m,512,host);w_cat(m,512,L" result=");w_cat(m,512,ok?L"OK":L"FAILED");
    if(ok){w_cat(m,512,L" bytes=");w_cat_u64(m,512,(u64)r->len);}else{w_cat(m,512,L" win_error=");w_cat_u64(m,512,(u64)r->win_error);}
    log_msg(st,ok?L"INFO":L"ERROR",module,code,m);return ok;
}


static int fetch_basic_info(const StorageContext* st,FundRecord* f,int force){
    u64 now=provider_now_filetime();WCHAR path[384];NetResponse r;FundBasicParsed p;
    if(!st||!f)return 0;
    if(!force&&f->fund_type[0]&&f->fund_company[0]&&f->basic_sync_filetime>0&&now>f->basic_sync_filetime&&now-f->basic_sync_filetime<BASIC_TTL_100NS){log_msg(st,L"INFO",L"FUND_BASIC",f->code,L"CACHE HIT 基础资料仍在有效期");return 1;}
    w_copy(path,384,L"/FundMNewApi/FundMNNBasicInformation?FCODE=");w_cat_u16(path,384,f->code);
    w_cat(path,384,L"&deviceid=AI_Fund_Predictor&plat=Android&product=EFund&version=6.3.8&appType=ttjj");
    if(!fetch(st,L"FUND_BASIC",f->code,L"fundmobapi.eastmoney.com",path,L"Referer: https://fund.eastmoney.com/\r\nUser-Agent: Mozilla/5.0\r\nAccept: application/json,text/plain,*/*\r\n",MAX_HTTP_SMALL,&r))return f->fund_type[0]||f->fund_company[0];
    storage_write_raw_cache(st,f->code,L".basic.json",r.data,r.len);
    if(parser_basic_info(r.data,&p)){
        if(p.name[0])utf8_to_u16(p.name,f->name,FUND_NAME_CAP);
        if(p.fund_type[0])utf8_to_u16(p.fund_type,f->fund_type,FUND_META_CAP);
        if(p.fund_company[0])utf8_to_u16(p.fund_company,f->fund_company,FUND_META_CAP);
        if(p.fund_manager[0])utf8_to_u16(p.fund_manager,f->fund_manager,FUND_META_CAP);
        if(p.established_date[0])date_ascii_to_u16(p.established_date,f->established_date,FUND_DATE_CAP);
        if(p.benchmark[0])utf8_to_u16(p.benchmark,f->benchmark,FUND_BENCHMARK_CAP);
        f->basic_sync_filetime=now;
        log_msg(st,L"INFO",L"FUND_BASIC",f->code,L"解析成功并写入基础资料");net_free(&r);return 1;
    }
    log_msg(st,L"WARN",L"FUND_BASIC",f->code,L"HTTP成功但基础资料解析失败，保留旧数据");net_free(&r);return f->fund_type[0]||f->fund_company[0];
}

static int fetch_fundgz(const StorageContext* st,FundRecord* f){
    WCHAR path[256];NetResponse r;FundGzParsed p;u64 tick=GetTickCount64();
    w_copy(path,256,L"/js/");w_cat_u16(path,256,f->code);w_cat(path,256,L".js?rt=");w_cat_u64(path,256,tick);
    if(!fetch(st,L"FUND_CURRENT",f->code,L"fundgz.1234567.com.cn",path,L"Referer: https://fund.eastmoney.com/\r\nAccept: */*\r\nCache-Control: no-cache\r\n",MAX_HTTP_SMALL,&r))return 0;
    storage_write_raw_cache(st,f->code,L".fundgz.txt",r.data,r.len);
    if(!parser_fundgz(r.data,&p)){log_msg(st,L"WARN",L"FUND_CURRENT",f->code,L"实时净值响应解析失败");net_free(&r);return 0;}
    utf8_to_u16(p.name,f->name,FUND_NAME_CAP);
    f->nav_x10000=p.nav_x10000;f->estimate_x10000=p.estimate_x10000;f->estimate_change_x100=p.estimate_change_x100;
    date_ascii_to_u16(p.nav_date,f->nav_date,FUND_DATE_CAP);date_ascii_to_u16(p.estimate_time,f->estimate_time,FUND_TIME_CAP);
    WCHAR m[256];w_copy(m,256,L"解析成功 nav_x10000=");w_cat_u64(m,256,(u64)(f->nav_x10000<0?0:f->nav_x10000));w_cat(m,256,L" estimate_x10000=");w_cat_u64(m,256,(u64)(f->estimate_x10000<0?0:f->estimate_x10000));w_cat(m,256,L" change_x100=");if(f->estimate_change_x100<0)w_cat(m,256,L"-");w_cat_u64(m,256,(u64)(f->estimate_change_x100<0?-f->estimate_change_x100:f->estimate_change_x100));log_msg(st,L"INFO",L"FUND_CURRENT",f->code,m);net_free(&r);return 1;
}


static int fetch_current_batch(const StorageContext* st,FundStore* store,int* current_ok){
    WCHAR path[1024];NetResponse r;int i,ok=0;
    if(!st||!store||store->count<=0)return 0;
    w_copy(path,1024,L"/FundMNewApi/FundMNFInfo?pageIndex=1&pageSize=200&plat=Android&appType=ttjj&product=EFund&Version=1&deviceid=AI_Fund_Predictor&Fcodes=");
    for(i=0;i<store->count;i++){if(i)w_cat(path,1024,L",");w_cat_u16(path,1024,store->funds[i].code);if(current_ok)current_ok[i]=0;}
    if(!fetch(st,L"FUND_BATCH",NULL,L"fundmobapi.eastmoney.com",path,L"Referer: https://fund.eastmoney.com/\r\nUser-Agent: Mozilla/5.0\r\nAccept: application/json,text/plain,*/*\r\nCache-Control: no-cache\r\n",MAX_HTTP_SMALL,&r))return 0;
    storage_write_named_cache(st->market_cache_dir,L"fund_current.json",r.data,r.len);
    for(i=0;i<store->count;i++){
        char code[16];FundCurrentParsed p;ascii_from_u16(store->funds[i].code,code,sizeof(code));
        if(parser_mnfinfo_find(r.data,code,&p)){
            FundRecord* f=&store->funds[i];
            utf8_to_u16(p.name,f->name,FUND_NAME_CAP);
            f->nav_x10000=p.nav_x10000;
            if(p.estimate_x10000>0)f->estimate_x10000=p.estimate_x10000;
            f->estimate_change_x100=p.estimate_change_x100;
            if(p.nav_date[0])date_ascii_to_u16(p.nav_date,f->nav_date,FUND_DATE_CAP);
            if(p.estimate_time[0])date_ascii_to_u16(p.estimate_time,f->estimate_time,FUND_TIME_CAP);
            if(current_ok)current_ok[i]=1;
            {WCHAR m[256];w_copy(m,256,L"批量净值命中 nav_x10000=");w_cat_u64(m,256,(u64)(f->nav_x10000<0?0:f->nav_x10000));w_cat(m,256,L" estimate_x10000=");w_cat_u64(m,256,(u64)(f->estimate_x10000<0?0:f->estimate_x10000));log_msg(st,L"INFO",L"FUND_BATCH_ITEM",f->code,m);}
            ok++;
        }
    }
    log_count(st,L"INFO",L"FUND_BATCH",NULL,L"批量净值解析成功基金数=",ok);net_free(&r);return ok;
}

static int nav_compare_date(const void* a0,const void* b0){const NavPoint* a=(const NavPoint*)a0;const NavPoint* b=(const NavPoint*)b0;return a->yyyymmdd<b->yyyymmdd?-1:(a->yyyymmdd>b->yyyymmdd?1:0);}
static void sort_nav(NavPoint* a,int n){int i,j;for(i=1;i<n;i++){NavPoint key=a[i];j=i-1;while(j>=0&&nav_compare_date(&a[j],&key)>0){a[j+1]=a[j];j--;}a[j+1]=key;}}
static int find_nav_date(const NavPoint* a,int n,int date){int i;for(i=n-1;i>=0;i--)if(a[i].yyyymmdd==date)return i;return -1;}

static int fetch_initial_history(const StorageContext* st,FundRecord* f,NavPoint* points,int max_points){
    WCHAR path[256];NetResponse r;ParsedNavPoint* parsed;int n,i;u64 tick=GetTickCount64();
    w_copy(path,256,L"/pingzhongdata/");w_cat_u16(path,256,f->code);w_cat(path,256,L".js?v=");w_cat_u64(path,256,tick);
    if(!fetch(st,L"NAV_HISTORY_INIT",f->code,L"fund.eastmoney.com",path,L"Referer: https://fund.eastmoney.com/\r\nAccept: */*\r\nCache-Control: no-cache\r\n",MAX_HTTP_HISTORY,&r))return 0;
    storage_write_raw_cache(st,f->code,L".history.js",r.data,r.len);
    parsed=(ParsedNavPoint*)HeapAlloc(GetProcessHeap(),0,sizeof(ParsedNavPoint)*max_points);if(!parsed){net_free(&r);return 0;}
    n=parser_ping_nav(r.data,parsed,max_points);
    if(n>0){log_count(st,L"INFO",L"NAV_HISTORY_INIT",f->code,L"首次历史净值点数=",n);char nm[PARSED_NAME_CAP];if(parser_ping_name(r.data,nm,sizeof(nm)))utf8_to_u16(nm,f->name,FUND_NAME_CAP);for(i=0;i<n;i++){points[i].yyyymmdd=parsed[i].yyyymmdd;points[i].nav_x10000=parsed[i].nav_x10000;points[i].return_x100=parsed[i].return_x100;}sort_nav(points,n);storage_save_nav_points(st,f->code,points,n);}
    if(n<=0)log_msg(st,L"WARN",L"NAV_HISTORY_INIT",f->code,L"历史净值响应解析结果为空");HeapFree(GetProcessHeap(),0,parsed);net_free(&r);return n;
}

static int fetch_incremental_history(const StorageContext* st,FundRecord* f,NavPoint* points,int count,int max_points){
    WCHAR path[320];NetResponse r;ParsedNavPoint parsed[32];int n,i,added=0;
    w_copy(path,320,L"/f10/lsjz?fundCode=");w_cat_u16(path,320,f->code);w_cat(path,320,L"&pageIndex=1&pageSize=20");
    if(!fetch(st,L"NAV_HISTORY_INC",f->code,L"api.fund.eastmoney.com",path,L"Referer: https://fund.eastmoney.com/\r\nUser-Agent: Mozilla/5.0\r\nAccept: application/json,text/plain,*/*\r\n",MAX_HTTP_SMALL,&r))return count;
    storage_write_raw_cache(st,f->code,L".latest_nav.json",r.data,r.len);
    n=parser_f10_latest_nav(r.data,parsed,32);
    for(i=n-1;i>=0;i--){int at=find_nav_date(points,count,parsed[i].yyyymmdd);if(at>=0){points[at].nav_x10000=parsed[i].nav_x10000;points[at].return_x100=parsed[i].return_x100;}else if(count<max_points){points[count].yyyymmdd=parsed[i].yyyymmdd;points[count].nav_x10000=parsed[i].nav_x10000;points[count].return_x100=parsed[i].return_x100;count++;added++;}}
    if(added){sort_nav(points,count);storage_save_nav_points(st,f->code,points,count);log_count(st,L"INFO",L"NAV_HISTORY_INC",f->code,L"增量新增净值点数=",added);}else log_msg(st,L"INFO",L"NAV_HISTORY_INC",f->code,L"增量检查完成，无新增净值点");net_free(&r);return count;
}

static int pct_between(int now,int old){if(old<=0)return 0;return (int)(((long long)(now-old)*10000LL)/old);}
static void compute_nav_stats(FundRecord* f,const NavPoint* p,int n){int last;if(!f)return;f->history_points=n;if(n<=0)return;last=n-1;if(f->nav_x10000<=0)f->nav_x10000=p[last].nav_x10000;if(!f->nav_date[0])date_int_to_u16(p[last].yyyymmdd,f->nav_date,FUND_DATE_CAP);f->return_1d_x100=(n>=2)?pct_between(p[last].nav_x10000,p[last-1].nav_x10000):0;f->return_5d_x100=(n>=6)?pct_between(p[last].nav_x10000,p[last-5].nav_x10000):0;f->return_20d_x100=(n>=21)?pct_between(p[last].nav_x10000,p[last-20].nav_x10000):0;f->return_60d_x100=(n>=61)?pct_between(p[last].nav_x10000,p[last-60].nav_x10000):0;}

static int fetch_history(const StorageContext* st,FundRecord* f){NavPoint* points;int n,local_n;points=(NavPoint*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(NavPoint)*NAV_MAX_POINTS);if(!points)return 0;n=storage_load_nav_points(st,f->code,points,NAV_MAX_POINTS);local_n=n;if(n<=0){log_msg(st,L"INFO",L"NAV_HISTORY",f->code,L"CACHE MISS 本地无历史净值，执行首次建立");n=fetch_initial_history(st,f,points,NAV_MAX_POINTS);if(n>0){log_msg(st,L"INFO",L"NAV_HISTORY_INIT",f->code,L"首次历史建立完成，立即执行增量补齐");n=fetch_incremental_history(st,f,points,n,NAV_MAX_POINTS);}}else{log_count(st,L"INFO",L"NAV_HISTORY",f->code,L"CACHE HIT 本地历史点数=",n);n=fetch_incremental_history(st,f,points,n,NAV_MAX_POINTS);}if(n>0)compute_nav_stats(f,points,n);if(n<=0)log_msg(st,L"ERROR",L"NAV_HISTORY",f->code,L"历史净值不可用");else if(local_n>0)log_msg(st,L"INFO",L"NAV_HISTORY",f->code,L"历史净值增量同步完成");else log_msg(st,L"INFO",L"NAV_HISTORY",f->code,L"首次历史净值建立并增量补齐完成");HeapFree(GetProcessHeap(),0,points);return n>0;}

static int fetch_holdings(const StorageContext* st,FundRecord* f,int force){
    u64 now=provider_now_filetime();WCHAR path[320];NetResponse r;ParsedHolding h[HOLDING_MAX];char cutoff[16];int n,i;
    if(!force&&f->holding_count>0&&f->holdings_sync_filetime>0&&now>f->holdings_sync_filetime&&now-f->holdings_sync_filetime<HOLDINGS_TTL_100NS){log_count(st,L"INFO",L"HOLDINGS",f->code,L"CACHE HIT 持仓条数=",f->holding_count);return 1;}
    w_copy(path,320,L"/FundArchivesDatas.aspx?type=jjcc&code=");w_cat_u16(path,320,f->code);w_cat(path,320,L"&topline=10&year=&month=&_=");w_cat_u64(path,320,GetTickCount64());
    if(!fetch(st,L"HOLDINGS",f->code,L"fundf10.eastmoney.com",path,L"Referer: https://fundf10.eastmoney.com/\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\n",MAX_HTTP_SMALL,&r))return f->holding_count>0;
    storage_write_raw_cache(st,f->code,L".holdings.txt",r.data,r.len);n=parser_holdings(r.data,h,HOLDING_MAX,cutoff,sizeof(cutoff));
    if(n>0){f->holding_count=n;for(i=0;i<n;i++){date_ascii_to_u16(h[i].code,f->holdings[i].code,HOLDING_CODE_CAP);utf8_to_u16(h[i].name,f->holdings[i].name,HOLDING_NAME_CAP);f->holdings[i].weight_x100=h[i].weight_x100;f->holdings[i].quote_ok=0;f->holdings[i].change_x100=0;}for(;i<HOLDING_MAX;i++){f->holdings[i].code[0]=0;f->holdings[i].name[0]=0;f->holdings[i].weight_x100=0;f->holdings[i].quote_ok=0;f->holdings[i].change_x100=0;}if(cutoff[0])date_ascii_to_u16(cutoff,f->holdings_date,FUND_DATE_CAP);f->holdings_sync_filetime=now;}
    if(n>0){WCHAR m[256];w_copy(m,256,L"持仓解析成功 count=");w_cat_u64(m,256,(u64)n);w_cat(m,256,L" report_date=");if(f->holdings_date[0])w_cat_u16(m,256,f->holdings_date);else w_cat(m,256,L"--");log_msg(st,L"INFO",L"HOLDINGS",f->code,m);}else log_msg(st,L"WARN",L"HOLDINGS",f->code,L"持仓响应未解析到有效记录，保留已有持仓");net_free(&r);return n>0||f->holding_count>0;
}

static void quote_symbol(const u16* code,char* symbol,int cap,int* full){char c[16];ascii_from_u16(code,c,sizeof(c));symbol[0]=0;*full=0;if(c_strlen(c)==5){c_copy(symbol,cap,"hk");c_cat(symbol,cap,c);*full=1;}else if(c[0]=='6'||c[0]=='9'){c_copy(symbol,cap,"sh");c_cat(symbol,cap,c);}else if(c[0]=='0'||c[0]=='3'){c_copy(symbol,cap,"sz");c_cat(symbol,cap,c);}else if(c[0]=='4'||c[0]=='8'){c_copy(symbol,cap,"bj");c_cat(symbol,cap,c);}else{c_copy(symbol,cap,"sz");c_cat(symbol,cap,c);}}
static int quote_find(QuoteEntry* q,int n,const char* code){int i;for(i=0;i<n;i++)if(c_streq(q[i].code,code))return i;return -1;}

static int collect_quotes(FundStore* store,QuoteEntry* q,int maxq){int i,j,n=0;for(i=0;i<store->count;i++)for(j=0;j<store->funds[i].holding_count;j++){char code[16],sym[24];int full;ascii_from_u16(store->funds[i].holdings[j].code,code,sizeof(code));if(!code[0]||quote_find(q,n,code)>=0)continue;if(n>=maxq)continue;quote_symbol(store->funds[i].holdings[j].code,sym,sizeof(sym),&full);c_copy(q[n].code,sizeof(q[n].code),code);c_copy(q[n].symbol,sizeof(q[n].symbol),sym);q[n].is_full=full;q[n].ok=0;n++;}return n;}

static void apply_quotes(FundStore* store,QuoteEntry* q,int n){int i,j,k;for(i=0;i<store->count;i++)for(j=0;j<store->funds[i].holding_count;j++){char code[16];ascii_from_u16(store->funds[i].holdings[j].code,code,sizeof(code));k=quote_find(q,n,code);if(k>=0&&q[k].ok){store->funds[i].holdings[j].change_x100=q[k].change_x100;store->funds[i].holdings[j].quote_ok=1;}}}

static void fetch_quotes(const StorageContext* st,FundStore* store){
    QuoteEntry* q;int n,start=0;
    q=(QuoteEntry*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(QuoteEntry)*QUOTE_MAX);
    if(!q)return;
    n=collect_quotes(store,q,QUOTE_MAX);log_count(st,L"INFO",L"STOCK_QUOTES",NULL,L"去重后需请求重仓股票数=",n);
    while(start<n){
        int end=start+40,i;WCHAR path[1024];NetResponse r;
        if(end>n)end=n;
        w_copy(path,1024,L"/q=");
        for(i=start;i<end;i++){
            int k=0;
            if(i>start)w_cat(path,1024,L",");
            if(!q[i].is_full)w_cat(path,1024,L"s_");
            while(q[i].symbol[k]){WCHAR one[2]={(WCHAR)(unsigned char)q[i].symbol[k++],0};w_cat(path,1024,one);}
        }
        if(fetch(st,L"STOCK_QUOTES",NULL,L"qt.gtimg.cn",path,L"User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",MAX_HTTP_SMALL,&r)){
            for(i=start;i<end;i++){
                if(q[i].is_full)q[i].ok=parser_tencent_full_percent(r.data,q[i].symbol,&q[i].change_x100,&q[i].price_x10000);
                else q[i].ok=parser_tencent_simple_percent(r.data,q[i].symbol,&q[i].change_x100,&q[i].price_x10000);
            }
            net_free(&r);
        }
        start=end;
    }
    {int good=0,i;for(i=0;i<n;i++){if(q[i].ok)good++;else{WCHAR m[128];int k=0;w_copy(m,128,L"行情缺失 symbol=");while(q[i].symbol[k]){WCHAR one[2]={(WCHAR)(unsigned char)q[i].symbol[k++],0};w_cat(m,128,one);}log_msg(st,L"WARN",L"STOCK_QUOTES",NULL,m);}}log_count(st,good==n?L"INFO":L"WARN",L"STOCK_QUOTES",NULL,L"成功获取股票行情数=",good);}apply_quotes(store,q,n);
    HeapFree(GetProcessHeap(),0,q);
}

static void fetch_market(const StorageContext* st,MarketSnapshot* m){WCHAR path[512];NetResponse r;const char* simple[4]={"sh000001","sz399001","sz399006","sh000300"};const char* full[3]={"hkHSI","hkHSTECH","usIXIC"};int i;if(!m)return;for(i=0;i<MARKET_COUNT;i++){m->items[i].ok=0;m->items[i].price_x10000=0;m->items[i].change_x100=0;}m->ok_count=0;w_copy(path,512,L"/q=s_sh000001,s_sz399001,s_sz399006,s_sh000300,hkHSI,hkHSTECH,usIXIC");if(!fetch(st,L"MARKET_QUOTES",NULL,L"qt.gtimg.cn",path,L"User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",MAX_HTTP_SMALL,&r))return;if(st)storage_write_named_cache(st->market_cache_dir,L"market_quotes.txt",r.data,r.len);for(i=0;i<4;i++){m->items[i].ok=parser_tencent_simple_percent(r.data,simple[i],&m->items[i].change_x100,&m->items[i].price_x10000);if(m->items[i].ok)m->ok_count++;}for(i=0;i<3;i++){m->items[4+i].ok=parser_tencent_full_percent(r.data,full[i],&m->items[4+i].change_x100,&m->items[4+i].price_x10000);if(m->items[4+i].ok)m->ok_count++;}m->synced_filetime=provider_now_filetime();log_count(st,m->ok_count==MARKET_COUNT?L"INFO":L"WARN",L"MARKET_QUOTES",NULL,L"公共市场行情成功数=",m->ok_count);net_free(&r);}

static int sync_one(const StorageContext* st,FundRecord* f,int current_ok,int force_holdings){int ok_hist,ok_hold,ok_basic;WCHAR msg[256];log_msg(st,L"INFO",L"FUND_SYNC",f->code,L"开始同步基金真实数据");f->data_status=DATA_SYNCING;f->last_error=0;ok_basic=fetch_basic_info(st,f,force_holdings);if(!current_ok)current_ok=fetch_fundgz(st,f);ok_hist=fetch_history(st,f);ok_hold=fetch_holdings(st,f,force_holdings);if(current_ok&&ok_hist){f->data_status=DATA_FRESH;if(f->prediction_status!=PRED_STATUS_OK)core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"真实净值、历史走势、持仓链路已同步；等待证据校验与AI预测");}else if(ok_hist||f->nav_x10000>0){f->data_status=DATA_STALE;f->last_error=1;if(f->prediction_status!=PRED_STATUS_OK)core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"部分在线数据暂时不可用，已保留D盘本地历史数据");}else{f->data_status=DATA_ERROR;f->last_error=2;if(f->prediction_status!=PRED_STATUS_OK)core_wcopy(f->summary,FUND_SUMMARY_CAP,(const u16*)L"真实数据同步失败，请检查网络后刷新");}if(!ok_hold&&f->holding_count==0){/* holdings are not a hard gate for V0.2 */}if(!ok_basic){/* basic metadata is not a hard gate either */}f->last_sync_filetime=provider_now_filetime();w_copy(msg,256,L"结束 status=");w_cat(msg,256,f->data_status==DATA_FRESH?L"FRESH":(f->data_status==DATA_STALE?L"PARTIAL":L"ERROR"));w_cat(msg,256,L" basic=");w_cat(msg,256,ok_basic?L"OK":L"MISS");w_cat(msg,256,L" current=");w_cat(msg,256,current_ok?L"OK":L"MISS");w_cat(msg,256,L" history=");w_cat(msg,256,ok_hist?L"OK":L"MISS");w_cat(msg,256,L" holdings=");w_cat(msg,256,ok_hold?L"OK":L"MISS");log_msg(st,f->data_status==DATA_ERROR?L"ERROR":(f->data_status==DATA_STALE?L"WARN":L"INFO"),L"FUND_SYNC",f->code,msg);return f->data_status==DATA_FRESH;}

int provider_sync_all(const StorageContext* storage,FundStore* store,MarketSnapshot* market,int force_holdings){int i,ok=0,current_ok[MAX_FUNDS];if(!storage||!store)return 0;log_count(storage,L"INFO",L"SYNC",NULL,L"同步任务开始，基金数=",store->count);for(i=0;i<MAX_FUNDS;i++)current_ok[i]=0;fetch_current_batch(storage,store,current_ok);for(i=0;i<store->count;i++)if(sync_one(storage,&store->funds[i],current_ok[i],force_holdings))ok++;fetch_quotes(storage,store);fetch_market(storage,market);log_count(storage,L"INFO",L"SYNC",NULL,L"同步任务结束，完整基金数=",ok);return ok;}
