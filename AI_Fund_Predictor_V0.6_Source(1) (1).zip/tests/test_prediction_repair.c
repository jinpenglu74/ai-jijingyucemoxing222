#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "../src/prediction_repair.h"

static PredictionHorizon base(void){PredictionHorizon p;memset(&p,0,sizeof(p));p.valid=1;p.direction=PRED_DIR_UP;p.p_up=50;p.p_flat=30;p.p_down=20;p.return_low_x100=-50;p.return_high_x100=120;p.confidence=70;p.summary[0]='x';return p;}
int main(void){
    PredictionHorizon p;int f=0;
    p=base();p.p_up=46;p.p_flat=31;p.p_down=24;assert(prediction_repair_horizon(&p,&f));assert((f&PRED_REPAIR_PROB_NORMALIZED)!=0);assert(p.p_up+p.p_flat+p.p_down==100);
    p=base();p.direction=PRED_DIR_DOWN;assert(prediction_repair_horizon(&p,&f));assert((f&PRED_REPAIR_DIRECTION_FIXED)!=0);assert(p.direction==PRED_DIR_UP);
    p=base();p.return_low_x100=200;p.return_high_x100=-100;assert(prediction_repair_horizon(&p,&f));assert((f&PRED_REPAIR_RANGE_SWAPPED)!=0);assert(p.return_low_x100==-100&&p.return_high_x100==200);
    p=base();p.confidence=103;assert(prediction_repair_horizon(&p,&f));assert((f&PRED_REPAIR_CONFIDENCE_CLAMPED)!=0);assert(p.confidence==100);
    p=base();p.p_up=60;p.p_flat=60;p.p_down=10;assert(!prediction_repair_horizon(&p,&f));
    p=base();p.p_up=90;p.p_flat=60;p.p_down=20;assert(!prediction_repair_horizon(&p,&f));
    puts("prediction repair tests: PASS");return 0;
}
