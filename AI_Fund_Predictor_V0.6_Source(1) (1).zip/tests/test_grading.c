#include <assert.h>
#include "../src/grading.h"
int main(void){
    int s[6],e[6];
    assert(grading_weekday(20260929)==2);
    assert(grading_next_weekday(20261002)==20261005);
    assert(grading_last_weekday_of_month(20260929)==20260930);
    grading_compute_windows(20260929,s,e);
    assert(s[0]==20260929 && e[0]==20260929);
    assert(s[1]==20260930 && e[1]==20260930);
    assert(e[2]==20261002);
    assert(s[3]==20261005 && e[3]==20261009);
    assert(e[4]==20260930);
    assert(s[5]==20261001 && e[5]==20261030);
    assert(grading_return_x100(10000,10100)==100);
    assert(grading_actual_direction(10)==PRED_DIR_UP);
    assert(grading_actual_direction(-10)==PRED_DIR_DOWN);
    assert(grading_actual_direction(9)==PRED_DIR_FLAT);
    assert(grading_brier_x10000(100,0,0,PRED_DIR_UP)==0);
    assert(grading_confidence_error(80,1)==20);
    return 0;
}
