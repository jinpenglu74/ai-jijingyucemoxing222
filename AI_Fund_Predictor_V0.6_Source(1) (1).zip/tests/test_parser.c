#include <stdio.h>
#include <string.h>
#include "../src/parser.h"

static int fail=0;
#define CHECK(x,msg) do{if(!(x)){printf("FAIL: %s\n",msg);fail++;}}while(0)

int main(void){
    FundGzParsed g;ParsedNavPoint pts[8];ParsedHolding h[10];char cutoff[16];int n,v,p;
    const char* gz="jsonpgz({\"fundcode\":\"001186\",\"name\":\"富国文体健康股票\",\"jzrq\":\"2026-09-28\",\"dwjz\":\"0.7420\",\"gsz\":\"0.7251\",\"gszzl\":\"-2.28\",\"gztime\":\"2026-09-29 14:31\"});";
    CHECK(parser_fundgz(gz,&g),"fundgz parse");CHECK(g.nav_x10000==7420,"nav scaled");CHECK(g.estimate_x10000==7251,"estimate scaled");CHECK(g.estimate_change_x100==-228,"change scaled");
    {
        FundCurrentParsed cur;
        const char* batch="{\"Datas\":[{\"FCODE\":\"005827\",\"SHORTNAME\":\"易方达蓝筹精选混合\",\"PDATE\":\"2026-09-28\",\"NAV\":\"2.1187\",\"NAVCHGRT\":\"0.66\",\"GSZ\":\"2.1450\",\"GSZZL\":\"1.24\",\"GZTIME\":\"2026-09-29 14:30\"}],\"ErrCode\":0,\"Success\":true}";
        CHECK(parser_mnfinfo_find(batch,"005827",&cur),"mnfinfo parse");
        CHECK(cur.nav_x10000==21187,"mnf nav");
        CHECK(cur.estimate_x10000==21450,"mnf estimate");
        CHECK(cur.nav_change_x100==66,"mnf nav change");
        CHECK(cur.estimate_change_x100==124,"mnf estimate change");
    }
    {
        FundBasicParsed basic;
        const char* js="{\"Datas\":{\"FCODE\":\"005827\",\"SHORTNAME\":\"易方达蓝筹精选混合\",\"FTYPE\":\"混合型-偏股\",\"JJGS\":\"易方达基金\",\"JJJL\":\"张三\",\"ESTABDATE\":\"2018-09-05\",\"BENCH\":\"沪深300指数收益率*70%+中债指数*30%\"}}";
        CHECK(parser_basic_info(js,&basic),"basic info parse");
        CHECK(strcmp(basic.code,"005827")==0,"basic code");
        CHECK(strcmp(basic.established_date,"2018-09-05")==0,"basic date");
        CHECK(strstr(basic.fund_type,"混合型")!=0,"basic type");
        CHECK(strstr(basic.fund_company,"易方达")!=0,"basic company");
        CHECK(strstr(basic.benchmark,"沪深300")!=0,"basic benchmark");
    }
    const char* ping="var fS_name = \"测试基金\"; var Data_netWorthTrend = [{\"x\":1603987200000,\"y\":1.7885,\"equityReturn\":0,\"unitMoney\":\"\"},{\"x\":1604246400000,\"y\":1.7867,\"equityReturn\":-0.1,\"unitMoney\":\"\"}];";
    n=parser_ping_nav(ping,pts,8);CHECK(n==2,"ping count");CHECK(pts[0].nav_x10000==17885,"ping nav1");CHECK(pts[1].return_x100==-10,"ping return");
    const char* f10="{\"Data\":{\"LSJZList\":[{\"FSRQ\":\"2026-09-28\",\"DWJZ\":\"1.2345\",\"JZZZL\":\"0.62\"},{\"FSRQ\":\"2026-09-27\",\"DWJZ\":\"1.2269\",\"JZZZL\":\"-0.11\"}]}}";
    n=parser_f10_latest_nav(f10,pts,8);CHECK(n==2,"f10 count");CHECK(pts[0].yyyymmdd==20260928,"date parse");CHECK(pts[0].return_x100==62,"f10 ret");
    const char* hold="var apidata={ content:\"<div class='box'><h4><font class='px12'>2026-06-30</font></h4><table><tbody><tr><th>序号</th></tr><tr><td>1</td><td><a>600519</a></td><td class='tol'><a>贵州茅台</a></td><td>1300.00</td><td>+1.20%</td><td>资讯</td><td>8.12%</td><td>10</td><td>1000</td></tr><tr><td>2</td><td><a>00700</a></td><td class='tol'><a>腾讯控股</a></td><td>600.00</td><td>-0.40%</td><td>资讯</td><td>7.55%</td><td>10</td><td>900</td></tr></tbody></table></div>\",arryear:[2026]};";
    n=parser_holdings(hold,h,10,cutoff,16);CHECK(n==2,"hold count");CHECK(strcmp(h[0].code,"600519")==0,"hold code");CHECK(h[0].weight_x100==812,"hold weight");CHECK(strcmp(cutoff,"2026-06-30")==0,"cutoff");
    const char* tq="v_s_sh600519=\"1~贵州茅台~600519~1356.10~13.10~0.98~16355~220680~~16952.36~GP-A~\";";
    CHECK(parser_tencent_simple_percent(tq,"sh600519",&v,&p),"tencent");CHECK(v==98,"tencent percent");CHECK(p==13561000,"tencent price");
    const char* fq="v_hkHSI=\"100~恒生指数~HSI~24805.630~24954.470~24718.150~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~0~2026/09/11 18:30:53~-148.840~-0.60~24851.180~24570.240~\";";
    CHECK(parser_tencent_full_percent(fq,"hkHSI",&v,&p),"tencent full");CHECK(v==-60,"tencent full pct");
    if(fail){printf("%d failures\n",fail);return 1;}printf("parser tests passed\n");return 0;
}
