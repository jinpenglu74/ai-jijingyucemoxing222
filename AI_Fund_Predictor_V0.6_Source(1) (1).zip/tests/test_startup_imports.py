from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parents[1]
exe=root/'AI基金预测_V0.6_AI复盘基础版_免安装.exe'
out=subprocess.check_output(['/usr/local/swift/usr/bin/llvm-objdump','-p',str(exe)],text=True,stderr=subprocess.STDOUT)
low=out.lower()
assert 'interlockedcompareexchange' not in low
assert 'interlockedexchange' not in low
for s in ('createmutexw','waitforsingleobject','releasemutex','cryptprotectdata','cryptunprotectdata'):
    assert s in low, s
print('startup import regression: PASS')
