from pathlib import Path
import subprocess, struct, hashlib
root=Path(__file__).resolve().parents[1]
(root/'build_tests').mkdir(exist_ok=True)
subprocess.check_call(['cc','-std=c99','-Wall','-Wextra','-Werror',str(root/'tests/test_parser.c'),str(root/'src/parser.c'),'-o',str(root/'build_tests/test_parser')])
subprocess.check_call([str(root/'build_tests/test_parser')])
subprocess.check_call(['cc','-std=c99','-Wall','-Wextra','-Werror',str(root/'tests/test_core.c'),str(root/'src/core.c'),'-o',str(root/'build_tests/test_core')])
subprocess.check_call([str(root/'build_tests/test_core')])
subprocess.check_call(['cc','-std=c99','-Wall','-Wextra','-Werror',str(root/'tests/test_prediction_repair.c'),str(root/'src/prediction_repair.c'),'-o',str(root/'build_tests/test_prediction_repair')])
subprocess.check_call([str(root/'build_tests/test_prediction_repair')])
subprocess.check_call(['cc','-std=c99','-Wall','-Wextra','-Werror',str(root/'tests/test_grading.c'),str(root/'src/grading.c'),'-o',str(root/'build_tests/test_grading')])
subprocess.check_call([str(root/'build_tests/test_grading')])
subprocess.check_call(['cc','-std=c99','-Wall','-Wextra','-Werror',str(root/'tests/test_review_logic.c'),str(root/'src/review_logic.c'),'-I'+str(root/'src'),'-o',str(root/'build_tests/test_review_logic')])
subprocess.check_call([str(root/'build_tests/test_review_logic')])
exe=root/'AI基金预测_V0.6_AI复盘基础版_免安装.exe'
assert exe.exists(), 'V0.6 EXE missing'
data=exe.read_bytes(); assert data[:2]==b'MZ'
peoff=struct.unpack_from('<I',data,0x3c)[0]; assert data[peoff:peoff+4]==b'PE\0\0'; assert struct.unpack_from('<H',data,peoff+4)[0]==0x8664
out=subprocess.check_output(['/usr/local/swift/usr/bin/llvm-objdump','-p',str(exe)],text=True,stderr=subprocess.STDOUT).lower()
for dll in ('kernel32.dll','user32.dll','gdi32.dll','winhttp.dll','crypt32.dll'): assert dll in out
for sym in ('createmutexw','waitforsingleobject','releasemutex','createthread','cryptprotectdata','cryptunprotectdata'): assert sym in out
assert 'interlockedcompareexchange' not in out and 'interlockedexchange' not in out
main=(root/'src/main.c').read_text(encoding='utf-8'); storage=(root/'src/storage.c').read_text(encoding='utf-8'); archive=(root/'src/archive.c').read_text(encoding='utf-8'); grading=(root/'src/grading.c').read_text(encoding='utf-8'); ds=(root/'src/deepseek.c').read_text(encoding='utf-8'); review=(root/'src/review.c').read_text(encoding='utf-8'); snapshot=(root/'src/snapshot.c').read_text(encoding='utf-8')
for marker in ('预测档案','自动判卷','AI复盘','PRED_ARCHIVE','AUTO_GRADE','AI_REVIEW','prediction_archive_v1.bin','judgments_v1.bin','reviews_v1.bin'):
    assert marker in (main+storage+archive+review)
assert 'prediction_exists' in archive and 'judgment_exists' in archive
assert 'append_record' in archive and 'PredictionArchiveRecord' in archive and 'JudgmentRecord' in archive
assert 'prediction_baseline.nav_x10000' in archive, 'archive must freeze prediction-time base NAV'
assert 'grading_compute_windows' in archive and 'grading_brier_x10000' in archive
assert 'today<=r->target_end[hidx]' in archive, 'week/month must not grade before target window ends'
assert 'archive_sync_predictions' in main and 'archive_auto_grade' in main and 'review_run' in main
assert '#define DEEPSEEK_MAX_CONCURRENCY 3' in ds and 'PREDICTION_CACHE' in ds and 'JSON_REPAIR' in ds
assert 'deepseek_call_json_object' in ds and 'reasoning_content' in review, 'review must explicitly reject hidden chain-of-thought output'
assert 'snapshot_load_frozen' in review and 'snapshot_load_frozen' in snapshot, 'review must use frozen prediction-time snapshot'
assert 'review_compute_grade' in review and 'reviews_v1.bin' in storage
assert 'Never invent news' in review and 'frozen_prediction_snapshot_plus_actual_nav_only' in review
assert 'APP_SCHEMA_VERSION 6' in (root/'src/core.h').read_text(encoding='utf-8'), 'fund store schema must remain compatible'
print('PE/import/archive/grading/review guards: PASS')
print('size:',len(data))
print('sha256:',hashlib.sha256(data).hexdigest())
