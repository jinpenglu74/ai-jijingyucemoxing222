#include <stdio.h>
#include <assert.h>
#include "../src/core.h"
static void ascii_to_u16(u16* out,int cap,const char* s){int i=0;while(s[i]&&i<cap-1){out[i]=(u16)(unsigned char)s[i];i++;}out[i]=0;}
int main(void){
    FundStore st;LayoutInfo L;u16 code[16],name[64];FundRecord f;NavPoint nav[80];int mc[7],mo[7],i;
    core_init_default(&st);assert(st.count==0);assert(st.selected==-1);
    ascii_to_u16(code,16,"005827");ascii_to_u16(name,64,"Test Fund");assert(core_add_fund(&st,code,name)==0);assert(st.count==1);assert(core_find_fund(&st,code)==0);assert(core_add_fund(&st,code,name)==-3);assert(core_delete_fund(&st,0)==1);assert(st.count==0);
    ascii_to_u16(code,16,"12345");assert(core_code_is_valid(code)==0);
    core_compute_layout(1920,1080,96,1,&L);assert(L.sidebar_w==150);assert(L.right_panel_w==400);assert(L.overlay_detail==0);
    core_compute_layout(1000,700,96,1,&L);assert(L.sidebar_w==62);assert(L.overlay_detail==1);
    core_compute_layout(1500,1000,144,1,&L);assert(L.dpi==144);assert(L.sidebar_w==93);assert(L.header_h==78);

    core_init_default(&st);ascii_to_u16(code,16,"010415");ascii_to_u16(name,64,"Fund");assert(core_add_fund(&st,code,name)==0);f=st.funds[0];f.data_status=DATA_FRESH;f.nav_x10000=16900;ascii_to_u16(f.nav_date,FUND_DATE_CAP,"2026-09-28");ascii_to_u16(f.holdings_date,FUND_DATE_CAP,"2026-06-30");ascii_to_u16(f.fund_type,FUND_META_CAP,"Mixed");f.holding_count=2;f.holdings[0].weight_x100=5000;f.holdings[0].change_x100=100;f.holdings[0].quote_ok=1;f.holdings[1].weight_x100=3000;f.holdings[1].change_x100=-100;f.holdings[1].quote_ok=1;
    for(i=0;i<70;i++){nav[i].yyyymmdd=20260101+i;nav[i].nav_x10000=10000+i*100;nav[i].return_x100=0;}
    for(i=0;i<7;i++){mc[i]=50;mo[i]=1;}
    core_compute_analysis(&f,nav,70,mc,mo,7);
    assert(f.gate_status==GATE_READY);assert(f.data_completeness>=90);assert(f.data_confidence>=90);assert(f.factor_count>=10);assert(f.holdings_quoted_count==2);assert(f.holdings_concentration_x100==8000);assert(f.holdings_weighted_change_x100==20);assert(f.market_avg_change_x100==50);assert(f.max_drawdown_60d_x100==0);assert(f.short_trend==TREND_UP);assert(f.medium_trend==TREND_UP);
    core_compute_analysis(&f,nav,10,mc,mo,7);assert(f.gate_status==GATE_BLOCKED);
    {
        PredictionHorizon ph={0};
        ph.valid=1;ph.direction=PRED_DIR_UP;ph.p_up=60;ph.p_flat=25;ph.p_down=15;ph.return_low_x100=-50;ph.return_high_x100=120;ph.confidence=70;ascii_to_u16(ph.summary,PRED_REASON_CAP,"summary");
        assert(core_validate_prediction_horizon(&ph)==1);
        ph.p_down=16;assert(core_validate_prediction_horizon(&ph)==0);
        ph.p_down=15;ph.direction=PRED_DIR_DOWN;assert(core_validate_prediction_horizon(&ph)==0);
        ph.direction=PRED_DIR_UP;ph.return_low_x100=200;ph.return_high_x100=100;assert(core_validate_prediction_horizon(&ph)==0);
        ph.return_low_x100=-50;ph.return_high_x100=120;ph.summary[0]=0;assert(core_validate_prediction_horizon(&ph)==0);
    }
    {
        int ch[7]={10,20,30,40,50,60,70}, ok[7]={1,1,1,1,1,1,1};
        u64 h1,h2;
        h1=core_compute_evidence_hash(&f,ch,ok,7);
        assert(h1!=0);
        /* Metadata not sent to DeepSeek must not invalidate prediction cache. */
        ascii_to_u16(f.estimate_time,FUND_TIME_CAP,"2026-09-29 12:00");
        f.estimate_x10000=99999;
        ascii_to_u16(f.latest_snapshot_id,SNAPSHOT_ID_CAP,"WS-CHANGED-METADATA");
        h2=core_compute_evidence_hash(&f,ch,ok,7);
        assert(h1==h2);
        /* A real model input change must invalidate the evidence fingerprint. */
        ch[0]++;
        h2=core_compute_evidence_hash(&f,ch,ok,7);
        assert(h1!=h2);
        ch[0]--;
        f.holdings[0].change_x100++;
        h2=core_compute_evidence_hash(&f,ch,ok,7);
        assert(h1!=h2);
        f.holdings[0].change_x100--;

        /* V0.4.2.1: tiny live ticks do not invalidate the reusable prediction. */
        core_capture_prediction_baseline(&f,ch,ok,7,123456789ULL);
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_NONE);
        ch[0]+=CACHE_MARKET_CHANGE_THRESHOLD_X100-1;
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_NONE);
        ch[0]++;
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_PUBLIC_MARKET);
        ch[0]-=CACHE_MARKET_CHANGE_THRESHOLD_X100;
        f.holdings[0].change_x100+=CACHE_HOLDING_CHANGE_THRESHOLD_X100-1;
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_NONE);
        f.holdings[0].change_x100++;
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_HOLDINGS_MARKET);
        f.holdings[0].change_x100-=CACHE_HOLDING_CHANGE_THRESHOLD_X100;
        f.nav_x10000++;
        assert(core_prediction_change_reason(&f,ch,ok,7)==CACHE_CHANGE_NAV);
    }
    puts("core/analysis/prediction/material-cache tests: PASS");return 0;
}
