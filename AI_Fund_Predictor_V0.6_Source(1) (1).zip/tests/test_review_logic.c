#include <stdio.h>
#include "review_logic.h"
static int fail=0;
#define CHECK(x) do{if(!(x)){printf("FAIL:%d: %s\n",__LINE__,#x);fail=1;}}while(0)
int main(void){
    CHECK(review_quality_from_ascii("SUPPORTED")==REVIEW_QUALITY_SUPPORTED);
    CHECK(review_quality_from_ascii("partial")==REVIEW_QUALITY_PARTIAL);
    CHECK(review_quality_from_ascii("WRONG")==REVIEW_QUALITY_UNSUPPORTED);
    CHECK(review_quality_from_ascii("unknown")==-1);
    CHECK(review_compute_grade(1,REVIEW_QUALITY_SUPPORTED)==REVIEW_GRADE_A);
    CHECK(review_compute_grade(1,REVIEW_QUALITY_PARTIAL)==REVIEW_GRADE_B);
    CHECK(review_compute_grade(1,REVIEW_QUALITY_UNSUPPORTED)==REVIEW_GRADE_B);
    CHECK(review_compute_grade(0,REVIEW_QUALITY_SUPPORTED)==REVIEW_GRADE_C);
    CHECK(review_compute_grade(0,REVIEW_QUALITY_PARTIAL)==REVIEW_GRADE_C);
    CHECK(review_compute_grade(0,REVIEW_QUALITY_UNSUPPORTED)==REVIEW_GRADE_D);
    CHECK(review_is_lucky_hit(1,REVIEW_QUALITY_UNSUPPORTED)==1);
    CHECK(review_is_lucky_hit(1,REVIEW_QUALITY_PARTIAL)==0);
    CHECK(review_is_lucky_hit(0,REVIEW_QUALITY_UNSUPPORTED)==0);
    if(fail) return 1;
    printf("review_logic: PASS\n");
    return 0;
}
